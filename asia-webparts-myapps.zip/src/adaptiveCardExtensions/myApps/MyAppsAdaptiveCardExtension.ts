import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseAdaptiveCardExtension } from '@microsoft/sp-adaptive-card-extension-base';
import { CardView } from './cardView/CardView';
import { QuickView } from './quickView/QuickView';
import { MyAppsPropertyPane } from './MyAppsPropertyPane';
import { AsiaConfigService } from '@asia/asia-lib/lib';
import { AllAppsLinks, MyApplications } from '../../Services/MyApplications';


export interface IMyAppsAdaptiveCardExtensionProps {
  title: string;
  buttonText: string;
  buttonStyle: string;
  primaryText: string;
}

export interface IMyAppsAdaptiveCardExtensionState {
  companyLinks: AllAppsLinks[];
  userLinks: AllAppsLinks[];
  loaded: boolean;
}

const CARD_VIEW_REGISTRY_ID: string = 'MyApps_CARD_VIEW';
export const QUICK_VIEW_REGISTRY_ID: string = 'MyApps_QUICK_VIEW';

export default class MyAppsAdaptiveCardExtension extends BaseAdaptiveCardExtension<
  IMyAppsAdaptiveCardExtensionProps,
  IMyAppsAdaptiveCardExtensionState
> {
  private _deferredPropertyPane: MyAppsPropertyPane | undefined;
  protected configService: AsiaConfigService;
  private companyLinksListUrl: string;
  private companyListTitle: string;
  public context: any;
  public userProfilePropertyName : string;

  public async onInit(): Promise<void> {
    this.state = {
      companyLinks: [],
      userLinks: [],
      loaded: false
    };
    await this.getDataFromServiceClass();
    this.cardNavigator.register(CARD_VIEW_REGISTRY_ID, () => new CardView());
    this.quickViewNavigator.register(QUICK_VIEW_REGISTRY_ID, () => new QuickView());
    return Promise.resolve();
  }

  // Get data from company link list and user profile property
  private async getDataFromServiceClass() {
    await this.getListFromASIAConfig();
    let myAppsClassObject = new MyApplications(this.context, this.companyLinksListUrl, this.companyListTitle ,this.userProfilePropertyName);
    let data: any = await myAppsClassObject.companylinks();
    let userLinks: any = await myAppsClassObject.getMyLinks(data);
    this.setState({
      companyLinks: data,
      userLinks: userLinks,
      loaded: true
    });
  }

  // Get company links list url and Title from Asia config 
  private getListFromASIAConfig(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.context.serviceScope.whenFinished(() => {
        this.configService = new AsiaConfigService(this.context.serviceScope);
        this.configService.load().then(() => {
          this.companyLinksListUrl = this.configService.settings().services.myapps.companyLinksSiteUrl;
          this.companyListTitle = this.configService.settings().services.myapps.listTitle;
          this.userProfilePropertyName = this.configService.settings().services.myapps.userProfilePropertyName;
          resolve();
        });
      });
    });
  }

 get iconProperty(): string {
    return "apps";
  }

  protected loadPropertyPaneResources(): Promise<void> {
    return import(
      './MyAppsPropertyPane'
    )
      .then(
        (component) => {
          this._deferredPropertyPane = new component.MyAppsPropertyPane();
        }
      );
  }

  protected renderCard(): string | undefined {
    return CARD_VIEW_REGISTRY_ID;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return this._deferredPropertyPane!.getPropertyPaneConfiguration();
  }
}

import { IPropertyPaneConfiguration, PropertyPaneTextField ,PropertyPaneDropdown} from '@microsoft/sp-property-pane';
import * as strings from 'MyAppsAdaptiveCardExtensionStrings';

export class MyAppsPropertyPane {
  public getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: { description: strings.PropertyPaneDescription },
          groups: [
            {
              groupFields: [
                PropertyPaneTextField('title', {
                  label: strings.TitleFieldLabel
                }),
                PropertyPaneTextField('primaryText', {
                  label: strings.PrimaryTextLabel
                }),
                PropertyPaneTextField('buttonText', {
                  label: strings.ButtonText
                }),
                PropertyPaneDropdown('buttonStyle', {
                  label: strings.ButtonStyle,
                  selectedKey: 'Basic',
                  options: [
                    { key: "Primary", text: "Primary" },
                    { key: "Standard", text: "Standard" },
                  ],
                }),
              ]
            }
          ]
        }
      ]
    };
  }
}

import { ISPFxAdaptiveCard, BaseAdaptiveCardQuickView } from '@microsoft/sp-adaptive-card-extension-base';
import * as strings from 'MyAppsAdaptiveCardExtensionStrings';
import { IMyAppsAdaptiveCardExtensionProps, IMyAppsAdaptiveCardExtensionState } from '../MyAppsAdaptiveCardExtension';
import { AllAppsLinks } from '../../../Services/MyApplications';

export interface IQuickViewData {
  subTitle: string;
  title: string;
  items: AllAppsLinks[];
  companyLinks: AllAppsLinks[];
}

export class QuickView extends BaseAdaptiveCardQuickView<
  IMyAppsAdaptiveCardExtensionProps,
  IMyAppsAdaptiveCardExtensionState,
  IQuickViewData
> {
  public get data(): IQuickViewData {
    return {
      subTitle: strings.SubTitle,
      title: strings.Title,
      items: this.state.userLinks,
      companyLinks: this.state.companyLinks,
    };
  }

  public get template(): ISPFxAdaptiveCard {
    return require('./template/QuickViewTemplate.json');
  }
}
define([], function () {
    return {
        
        "MyLinks": "My Links",
        "CompanyLinks": "Company Links",
        "AddFromGallery": "Add from gallery",
        "AddCustomLink": "Add custom link",
        "DragTheLinksToReorder" : "Drag the links to reorder",
        "CustomLinkTitle": "Link Title",
        "CustomLinkUrl": "Link URL",
        "AddCustomLinkbutton": "Add Link",
        "RemoveLink" : "Remove Link?",
        "Areyousureyouwanttoremovethislink" : "Are you sure you want to remove this link?",
        "RemoveLinkButton" : "Remove",
        "CancelLinkButton" : "Cancel",
        "SearchLink" : "Search for a link",      
        "MaxLimitMessage" : "You have reached the maximum number of links.",
        "CustomLinkLimitMessage" : "It's not possible to add more than 10 custom links.",
        "ManageLinks" : "Manage links",
        "ViewLinks" : "View Links",
        "InvalidLinkMessage" : "Invalid Link Title",
        "DuplicateLinkMessage": "A link with this title already exists",
        "InvalidURL": "Invalid URL",
        "AllLinksCategory": "All Links",

        //ACE Card strings
        
        "ACECardPrimaryText" : "Click here to access your personal links",
        "ACECardButtonText" : "links",
    }
});

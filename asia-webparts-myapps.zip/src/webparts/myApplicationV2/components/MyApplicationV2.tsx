import * as React from 'react';
import { IMyApplicationV2Props } from './IMyApplicationV2Props';
import { Panel } from 'office-ui-fabric-react/lib/Panel';
import { AllAppsLinks, MyApplications } from '../../../Services/MyApplications';
import { MyAppsPanel } from '../../../MyAppsPanel/MyAppsPanel';
import { IHandlebarsService, HandlebarsService, SecureMarkupService } from '@asia/asia-lib/lib';
import { indexOf } from 'lodash';
import { MessageBar, MessageBarType } from 'office-ui-fabric-react';

export interface IApplicationsProps {
  title: string;
  count: number;
  designChoice: string;
  handlebarTemplate: string;
  handlebarCustomTemplate: string;
  enableCodeEditor: boolean;
  callback: Function;
  dynamichtml: any;
  transformTemplate: any;
  templateFolderName: string;
  context: any;
  defaultImageLink: string;
  companyLinksListUrl: string;
  companyListTitle: string;
  userProfilePropertyName: string;
  errorStatus: boolean;
  userProfilePropertyStatus: boolean;
  linkColor: string;
  linkHoverColor: string;
  language: string;
}

export interface IMyApplicationsV2State {
  showpanel: boolean;
  userLinks: AllAppsLinks[];
  loadIconVisible: boolean;
}



export class MyApplicationV2 extends React.Component<IApplicationsProps, IMyApplicationsV2State> {
  private mandatoryLinks: AllAppsLinks[] = [];
  private splitArray: any[] = [];
  private finalArray: AllAppsLinks[] = [];
  private getMyLinksFromUserProfile: any = '';
  private hbs: IHandlebarsService;
  private myAppsClassObject : MyApplications;
  private myAppsPanel: MyAppsPanel;
  companyLinks: AllAppsLinks[];

  constructor(props) {
    super(props);

    this.myAppsClassObject = new MyApplications(this.props.context, this.props.companyLinksListUrl, this.props.companyListTitle, this.props.userProfilePropertyName);
    this.state = {
      showpanel: false,
      userLinks: [],
      loadIconVisible: false,
    };
  }


  public async componentWillMount() {
    await this.myAppsClassObject.setDefaultImageLink(this.props.defaultImageLink);
    this.ensureDefaultUserLinks().then(() => {
      this.getLinksFromServiceClass();
    });
  }
  private async getCompanyLinksOnLoad() {
    this.companyLinks = await this.myAppsClassObject.companylinks();
  }

  /**
    * Private Method to add mandatory links in user profile property
    * propertity referring - AvaPersonalQuickLinks
    */
  private async ensureDefaultUserLinks() {
    this.loadingStart();
    //set default image
    await this.myAppsClassObject.setDefaultImageLink(this.props.defaultImageLink);
    //get user profile property column value
    this.getMyLinksFromUserProfile = await this.myAppsClassObject.getUserProfilePropertyValue();
    //get all company links
    await this.getCompanyLinksOnLoad();
    let cData: any = await this.myAppsClassObject.comapnyLinksForHeartFill(this.companyLinks);
    //update useprofileproperty with only mandatory links when user configuring webpart first time
    if (this.getMyLinksFromUserProfile == null || this.getMyLinksFromUserProfile == '') {
      cData.map(item => {
        if (item.mandatory == true) {
          this.mandatoryLinks.push(item);
        }
      });
      this.setState({
        userLinks: this.mandatoryLinks
      });
    }
    //update user profile when additional mandatory links are added in the already configured webpart
    else {
      cData.map(item => {
        if (item.mandatory == true) {
          this.mandatoryLinks.push(item);
        }
      });
      this.splitArray = this.getMyLinksFromUserProfile.split("||");
      this.mandatoryLinks.forEach(
        item => {
          if (this.splitArray.indexOf(item.ID.toString()) == -1) {
            this.splitArray.push(item.ID);
          }
        }
      );
      this.splitArray.forEach(custom => {
        if (custom.toString().includes("|")) {
          let item = {
            ID: null, title: custom.split("|")[0],
            url: { Description: null, Url: custom.split("|")[1] },
            image: null, sequence: null, mandatory: null,
            priority: null, category: null, description: null, addtoMyLinks: true
          };
          this.finalArray.push(item);
        }
        else {
          cData.map(data => {
            if (data.ID == Number(custom)) {
              this.finalArray.push(data);
            }

          });
        }
      });
      this.updateFav(this.finalArray);
    }
  }

  /**
    * Private Method to return user's favourited links from service class
    */
  private async getLinksFromServiceClass(): Promise<AllAppsLinks[]> {
    let data = await this.myAppsClassObject.getMyLinks(this.companyLinks);
    if (data.length != 0) {
      this.setState({
        userLinks: data,
      });
    }
    this.loadingEnd();
    return this.state.userLinks;
  }

  // Update links in user profile properties based on user actions
  private async updateFav(favCompLink: AllAppsLinks[]) {
    await this.myAppsClassObject.updateUserProfileProperty(favCompLink);
    this.getLinksFromServiceClass();
  }

  // handle handlebar events
  public handleClick = (clickEvent) => {
    this.myAppsPanel = new MyAppsPanel(this.props);
    let targetElement = clickEvent.target as Element;
    if (targetElement.classList.contains('asiamyappsopenpanel')) {
      this.openPanel();
    }
  }

  // loading events
  private loadingStart() {
    this.setState({
      loadIconVisible: true
    });
  }
  private loadingEnd() {
    this.setState({
      loadIconVisible: false,
    });
  }

  public async showUpdatedUserLinksInWebpart() {
    let data = await this.myAppsClassObject.getMyLinks(this.companyLinks);
    if (data.length >= 0) {
      this.setState({
        userLinks: data,
      });
    }
  }

  public render(): React.ReactElement<IMyApplicationV2Props> {
    if (!(this.props.designChoice == undefined || (this.props.designChoice == "templatekey" && (this.props.handlebarTemplate == undefined || this.props.handlebarTemplate == "" || this.props.handlebarTemplate == "SelectTemplate")) || (this.props.designChoice == "handlebar" && (this.props.handlebarCustomTemplate == undefined || this.props.handlebarCustomTemplate == "")))) {
      this.generateHtml(this.state.userLinks);
    }
    return (
      <div>
        {this.props.errorStatus == true ? <MessageBar messageBarType={MessageBarType.error}>
          Unable to resolve company links list. Please ensure that the listTitle, companyLinksSiteUrl and userProfilePropertyName properties are set in the configuration.
        </MessageBar> :
          this.props.userProfilePropertyStatus == false ?
            <MessageBar messageBarType={MessageBarType.error}>
              User profile property {this.props.userProfilePropertyName} is missing
            </MessageBar>
            :
            <div>
              <div id="renderUserLinks" onClick={this.handleClick}></div>
              {this.state.showpanel &&
                <Panel isOpen={this.state.showpanel}
                  onDismiss={() => this.closePanel()}
                  closeButtonAriaLabel="Close"
                  isLightDismiss>
                  <MyAppsPanel
                    type="Webpart"
                    count={this.props.count}
                    defaultImageLink={this.props.defaultImageLink}
                    userProfilePropertyName={this.props.userProfilePropertyName}
                    companyLinksListUrl={this.props.companyLinksListUrl}
                    companyListTitle={this.props.companyListTitle}
                    callback={this.props.callback}
                    context={this.props.context}
                    companyLinks={this.companyLinks}
                    OnPreferencesChanged={() => this.showUpdatedUserLinksInWebpart()}>
                    
                  </MyAppsPanel>
                </Panel>}
            </div>}
      </div>

    );
  }

  // panel operations
  private openPanel() {
    this.setState({
      showpanel: true,
    });
  }

  private closePanel() {
    this.setState({
      showpanel: false
    });
  }

  /* handlebar operation begin */
  public async generateHtml(items: any): Promise<void> {
    let managedData = { Results: items, LinkColor: this.props.linkColor, LinkHoverColor: this.props.linkHoverColor , Language: this.props.language};
    switch (this.props.designChoice) {
      case 'templatekey':
        if (!(this.props.handlebarTemplate == "Select Template" || this.props.handlebarTemplate == "" || this.props.handlebarTemplate == undefined)) {
          this.renderData(managedData);
        }
        break;
      case 'handlebar':
        if (this.props.enableCodeEditor != false) {
          if (!this.hbs) {
            this.hbs = new HandlebarsService(this.context.serviceScope);
          }
          try {
            let html = await this.hbs.transformString(
              `${this.props.handlebarCustomTemplate}`,
              managedData);
            if (html == undefined) {
              html = "";
            }
            else {
              html = SecureMarkupService.GetSecureOutputUsingDOMPurify(html);

            }
            (document.getElementById('renderUserLinks') as Element).innerHTML = html;
          } catch (err) {
            console.log(err);
          }
        }
        break;
      default:
        this.renderData(items);
    }
  }

  private renderData(items: any) {
    if (!(this.props.handlebarTemplate == undefined || this.props.handlebarTemplate == "" || this.props.handlebarTemplate == "SelectTemplate")) {
      this.renderTemplateData(items);
    }
  }

  private renderTemplateData(items: any) {
    let self = this;
    this.props.transformTemplate("/" + this.props.templateFolderName + "/" + this.props.handlebarTemplate, items).then(html => {
      let secureHTML = SecureMarkupService.GetSecureOutputUsingDOMPurify(html);
      (document.getElementById('renderUserLinks') as Element).innerHTML = secureHTML;
    });
  }
  /* handlebar operation end */
}



export interface IMyApplicationV2Props {
  description: string;
} 

declare interface IMyApplicationV2WebPartStrings {
  SelectTemplate: string;
  SelectTemplateLabel: string;
  SelectTemplateKey: string;
  PropertyPaneDescription: string;
  Settings: string;
  DescriptionFieldLabel: string;
  TemplateFieldLabel: string;
  GenericHTML: string;
  Description: string;
  Configure: string;
  LoadingMessage: string;
  TitleFieldLabel: string;
  SizeFieldlabel: string;
  SmallSizeLabel: string;
  MediumSizeLabel: string;
  LargeSizeLabel: string;
  MaxCompanyLinks: string;
  Layout: string;
  HandleBarLabel: string;
  HandleBarButtonLabelandHeader: string;
  FieldName: string;
  ComboBoxValidationLabel: string;
  FieldValue: string;
}

declare module 'MyApplicationV2WebPartStrings' {
  const strings: IMyApplicationV2WebPartStrings;
  export = strings;
}

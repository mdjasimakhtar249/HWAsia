define([], function () {
  return {
    "PropertyPaneDescription": "",
    "Settings": "Title",
    "DescriptionFieldLabel": "Description Field",
    "LoadingMessage": "Templates",
    "MaxCompanyLinks": "Maximum Company Links to show",
    "SelectTemplateLabel": "Select template",
    "SelectTemplateKey": "SelectTemplate"
  }
});
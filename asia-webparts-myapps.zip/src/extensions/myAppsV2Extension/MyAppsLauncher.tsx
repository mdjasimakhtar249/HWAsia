import { AsiaConfigService, SecureMarkupService } from '@asia/asia-lib/lib';
import { ServiceScope } from '@microsoft/sp-core-library';
import { Panel } from 'office-ui-fabric-react';
import * as React from 'react';
import { MyAppsPanel } from '../../MyAppsPanel/MyAppsPanel';
import { AllAppsLinks, MyApplications } from '../../Services/MyApplications';

export interface IMyAppsLauncherProps {
  serviceScope: ServiceScope;
  count: any;
  callback: Function;
  context: any;
  defaultImageLink: string;
  companyLinksListUrl: string;
  companyListTitle: string;
  userProfilePropertyName: string;
  companyLinks: AllAppsLinks[];
}

export interface IMyAppsLauncherState {
  launcherElementHTML: string;
  showpanel: boolean;
}

export default class MyAppsLauncher extends React.Component<IMyAppsLauncherProps, IMyAppsLauncherState> {

  protected configService: AsiaConfigService;
  private myAppsPanel: MyAppsPanel;
  private companyLinks = [];
  myAppsClassObject: MyApplications;

  public constructor(props: IMyAppsLauncherProps) {
    super(props);
    this.myAppsClassObject = new MyApplications(this.props.context, this.props.companyLinksListUrl, this.props.companyListTitle, this.props.userProfilePropertyName);
    this.state = {
      launcherElementHTML: "",
      showpanel: false,
    };
  }

   private async getCompanyLinksOnLoad() {
    await this.myAppsClassObject.setDefaultImageLink(this.props.defaultImageLink);
    this.companyLinks = await this.myAppsClassObject.companylinks();
    }
    
  public componentWillMount() {
    this.props.serviceScope.whenFinished(() => {
      this.configService = new AsiaConfigService(this.props.serviceScope);
      this.configService.load().then(() => {
        let launcherElementHTML = this.configService.settings().services.myapps.extensionHTML;
        launcherElementHTML = SecureMarkupService.GetSecureOutputUsingDOMPurify(launcherElementHTML);
        this.getCompanyLinksOnLoad();
      this.setState({
          launcherElementHTML: launcherElementHTML
        });
      });
    });
 // });
  }

  // handle handlebar events
  public handleClick = (clickEvent) => {
    this.myAppsPanel = new MyAppsPanel(this.props);
    this.openPanel();
  }

  private openPanel() {
    this.setState({
      showpanel: true,
    });
  }

  private closePanel() {
    this.setState({
      showpanel: false
    });
  }

  public render() {
    return (
      <div>
        <div dangerouslySetInnerHTML={{ __html: this.state.launcherElementHTML }} onClick={this.handleClick}></div>
        <div>
          {this.state.showpanel &&
            <Panel isOpen={this.state.showpanel}
              onDismiss={() => this.closePanel()}
              closeButtonAriaLabel="Close"
              isLightDismiss
            >
              <MyAppsPanel
                type="Extension"
                count={this.props.count}
                defaultImageLink={this.props.defaultImageLink}
                userProfilePropertyName={this.props.userProfilePropertyName}
                companyLinksListUrl={this.props.companyLinksListUrl}
                companyListTitle={this.props.companyListTitle}
                callback={this.props.callback}
                context={this.props.context}
                companyLinks = {this.companyLinks}
                OnPreferencesChanged={() => { }}>
              </MyAppsPanel>
            </Panel>}
        </div>
      </div>
    );
  }
}
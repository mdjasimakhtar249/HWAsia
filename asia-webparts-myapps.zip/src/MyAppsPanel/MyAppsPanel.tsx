import * as React from 'react';
import styles from '../webparts/myApplicationV2/components/MyApplicationV2.module.scss';
import { IMyApplicationV2Props } from '../webparts/myApplicationV2/components/IMyApplicationV2Props';
import { AllAppsLinks, MyApplications } from '../Services/MyApplications';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { IPivotStyles, IStyleSet, MessageBar, MessageBarType, Pivot, PivotItem, PrimaryButton, DefaultButton, SearchBox, DialogType, DialogFooter, Dialog} from 'office-ui-fabric-react';
import { Accordion, AccordionItem, AccordionItemHeading, AccordionItemButton, AccordionItemPanel } from "@pnp/spfx-controls-react/lib/AccessibleAccordion";
import { DragDropContext, Droppable, Draggable,useKeyboardSensor, useMouseSensor} from 'react-beautiful-dnd';
import * as strings from 'myAppsV2WebpartStrings';
import useTouchSensor from '../MyAppsPanel/use-touch-sensor';

// style for Mylinks and Company links pivots
const pivotStyles: Partial<IStyleSet<IPivotStyles>> = {
    link: {
        fontSize: "20px",
    },
    linkIsSelected: {
        fontSize: "19px",
    },
};

export interface IApplicationsProps {
    type: string;
    count: number;
    callback: Function;
    context: any;
    OnPreferencesChanged(): void;
    defaultImageLink: string;
    companyLinksListUrl: string;
    companyListTitle: string;
    userProfilePropertyName: string;
    companyLinks: AllAppsLinks[];
}

export interface IMyApplicationsV2State {
    showpanel: boolean;
    searchQuery: boolean;
    userLinks: AllAppsLinks[];
    companyLinks: AllAppsLinks[];
    toggleHeartClicked: any;
    loadIconVisible: boolean;
    showMyLinksComp: Boolean;
    newItemTitle: string;
    newItemUrl: string;
    addCustomLinkCallout: boolean;
    checkDuplicateTitle: boolean;
    checkifNewTitleContaisPipe: boolean;
    checkifNewUrlConatinsPipe: boolean;
    checkInvalidUrl: boolean;
    checkCompanyLinkLength: boolean;
    selectedTabKey: string;
    searchItem: string;
    hideDialog: boolean;
    manageLink: boolean;
    itemToBeDeleted: AllAppsLinks;
}

export class MyAppsPanel extends React.Component<IApplicationsProps, IMyApplicationsV2State> {
    private companyLinksUniqueCategory = [];
    private mandatoryLinks: any[] = [];
    private searchQueryData: AllAppsLinks[] = [];
    private getMyLinksFromUserProfile: any = '';
    private myAppsClassObject = new MyApplications(this.props.context, this.props.companyLinksListUrl, this.props.companyListTitle, this.props.userProfilePropertyName);
    private preExpand: string[] = [];
    private AllItemsuuid: any = 'AllItemsuuid';
    companyLinks: AllAppsLinks[];
    constructor(props) {
        super(props);
        this.state = {
            showpanel: true,
            searchQuery: false,
            userLinks: [],
            companyLinks: [],
            toggleHeartClicked: {},
            loadIconVisible: false,
            showMyLinksComp: false,
            newItemTitle: "",
            newItemUrl: "",
            addCustomLinkCallout: false,
            checkDuplicateTitle: false,
            checkifNewTitleContaisPipe: false,
            checkifNewUrlConatinsPipe: false,
            checkInvalidUrl: false,
            checkCompanyLinkLength: false,
            selectedTabKey: strings.MyLinks,
            searchItem: "",
            hideDialog: true,
            manageLink: false,
            itemToBeDeleted: null
        };
        //Bind 'this' Object to Methods
        this.titleUpdated = this.titleUpdated.bind(this);
        this.urlUpdated = this.urlUpdated.bind(this);
        this.addCustomizableLink = this.addCustomizableLink.bind(this);
        this.handleShowCallout = this.handleShowCallout.bind(this);
        this.handleHideCallout = this.handleHideCallout.bind(this);
        //Drag N drop Functions
        this.onDragEnd = this.onDragEnd.bind(this);
    }

    private async getCompanyLinksOnLoad() { 
    this.setState({
        companyLinks:this.props.companyLinks
    });
    }

    public componentWillMount() {
        this.getCompanyLinksOnLoad().then(() => {
        this.ensureDefaultUserLinks().then(() => {
            this.setState({
                searchItem: localStorage.getItem("inputValue")
            });
            this.getLinksFromServiceClass();
        });
      });
    }

    /**
    * Private Method to add mandatory links in user profile property
    * propertity referring - AvaPersonalQuickLinks
    */
    private async ensureDefaultUserLinks() {
        this.loadingStart();
        //set default image
        await this.myAppsClassObject.setDefaultImageLink(this.props.defaultImageLink);
        //get user profile property column value
        this.getMyLinksFromUserProfile = await this.myAppsClassObject.getUserProfilePropertyValue();
        //get all company links
        let cData: any = await this.myAppsClassObject.comapnyLinksForHeartFill(this.state.companyLinks);
        cData.map(item => {
            if (item.mandatory == true) {
                this.mandatoryLinks.push(item);
            }
        });
        if (this.getMyLinksFromUserProfile == null || this.getMyLinksFromUserProfile == '') {
            this.setState({
                userLinks: this.mandatoryLinks
            });
        }
    }

    /**
    * Private Method to return user's favourited links and company links from service class
    */
    private async getLinksFromServiceClass(): Promise<AllAppsLinks[]> {
        let data = await this.myAppsClassObject.getMyLinks(this.state.companyLinks);
        let userLinksData = data;
        this.setState({
            userLinks: userLinksData,
        }, () => {
            this.props.OnPreferencesChanged();
        }
        );
        if (this.state.searchItem != "" && this.state.searchItem != null) {
            this.searchComapnyLinks(this.state.searchItem);
        }
        this.loadingEnd();
        return this.state.userLinks;
    }

    // Update links in user profile properties based on user actions
    private async updateFav(favCompLink: any[]) {
        await this.myAppsClassObject.updateUserProfileProperty(favCompLink);
        this.getLinksFromServiceClass();
    }

    /*Drag N Drop Functions - BEGIN */
    private reorder = (list: any, startIndex: any, endIndex: any) => {
        let result = list;
        let [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        this.updateFav(result);
        return result;
    }

    private onDragEnd(result: any) {
        // dropped outside the list
        if (!result.destination) {
            return;
        }
        const items = this.reorder(
            this.state.userLinks,
            result.source.index,
            result.destination.index
        );
        this.setState({
            userLinks: items,
        });
    }
    /*Drag N Drop Functions - END */

    //function to show favourite marked links in My Links Tab
    private getMyLinksComp() {
       // this.setCheckCompanyLength();
        const isMaxLinksExceeded = this.setCheckCompanyLength();
        return <div className={styles.mylinksComp}>
            {this.state.addCustomLinkCallout ?
                <div>
                    <label>{strings.AddCustomLink} </label>
                    {(this.state.userLinks.length >= this.props.count || this.state.userLinks.filter((link) => link.ID == null).length >= 10) ?
                    <div style={{ maxWidth: "200px", paddingBottom: "10px" }}>
                    <MessageBar messageBarType={MessageBarType.warning}>{strings.CustomLinkLimitMessage}</MessageBar></div> : ""}
                    <div className={styles.LinkURL}><TextField placeholder={strings.CustomLinkTitle} maxLength={50} ariaLabel={strings.CustomLinkTitle} onChange={this.titleUpdated} errorMessage={(this.state.checkDuplicateTitle ? strings.DuplicateLinkMessage : this.state.checkifNewTitleContaisPipe ? strings.InvalidLinkMessage : null)} disabled={(this.state.userLinks.filter((link) => link.ID == null).length >= 10)} /></div>
                    <div className={styles.LinkURL}><TextField placeholder={strings.CustomLinkUrl} maxLength={255} ariaLabel={strings.CustomLinkUrl} onChange={this.urlUpdated} errorMessage={(this.state.newItemUrl && this.state.checkInvalidUrl || this.state.checkifNewUrlConatinsPipe ? strings.InvalidURL : null)} disabled={(this.state.userLinks.filter((link) => link.ID == null).length >= 10)} /></div>
                    <div>
                    <DefaultButton  className={styles.marginButton1} onClick={this.handleHideCallout} title="Cancel">{strings.CancelLinkButton}</DefaultButton>
                    <PrimaryButton className={styles.marginButton2}  onClick={() => this.addCustomizableLink()} title={strings.AddCustomLinkbutton} disabled={this.state.checkDuplicateTitle || this.state.checkifNewTitleContaisPipe || this.state.checkifNewUrlConatinsPipe || this.state.newItemTitle.length < 1 || this.state.newItemUrl.length < 1 || this.state.checkInvalidUrl || this.state.userLinks.filter((link) => link.ID == null).length >= 10}>{strings.AddCustomLinkbutton}</PrimaryButton> 
                    </div>
                </div>
                : 
                <div>
            <div>
                {this.props.type == "Extension" ?
                    this.state.manageLink == true ?
                        isMaxLinksExceeded ?
                            <MessageBar messageBarType={MessageBarType.warning} dismissButtonAriaLabel="Close" isMultiline={true} className={styles.errorMessage}> {strings.MaxLimitMessage}</MessageBar>
                            : ""
                        : ""
                    : isMaxLinksExceeded ? <MessageBar messageBarType={MessageBarType.warning} dismissButtonAriaLabel="Close" isMultiline={true} className={styles.errorMessage}> {strings.MaxLimitMessage}</MessageBar> : ""
                }
                {this.props.type == "Extension" ?
                    this.state.manageLink == true ?
                        (this.state.userLinks.filter((link) => link.ID == null).length >= 10) ?
                            <div style={{ paddingBottom: "10px" }}>
                                <MessageBar messageBarType={MessageBarType.warning}>{strings.CustomLinkLimitMessage}</MessageBar></div>
                            : "" : "" : (this.state.userLinks.filter((link) => link.ID == null).length >= 10) ?
                        <div style={{ paddingBottom: "10px" }}>
                            <MessageBar messageBarType={MessageBarType.warning}>{strings.CustomLinkLimitMessage}</MessageBar></div> : ""
                }
                {this.props.type == "Extension" && this.state.manageLink == false ?
                    <PrimaryButton className={styles.manageLinkButton} text={strings.ManageLinks} onClick={() => this.manageLinkButtonClick()} /> :
                    this.state.manageLink == true || this.props.type == "Webpart" ?
                
                <div> <PrimaryButton className={styles.addFromGalleryButton} disabled={isMaxLinksExceeded} text={strings.AddFromGallery} onClick={() => this.changeSelectedTabkey()} />
                <PrimaryButton id='addcustomLink' className={styles.addCustomLinkbutton} disabled={(this.state.userLinks.length >= this.props.count || this.state.userLinks.filter((link) => link.ID == null).length >= 10)} text={strings.AddCustomLink} onClick={this.handleShowCallout.bind(this)} /> </div> : <></>
                       }
                </div>
                <div className={styles.mylinksdragtext}>
                    {this.state.manageLink == true || this.props.type == "Webpart" ? <span>{strings.DragTheLinksToReorder}</span> : <></>}
                    
                    {this.state.manageLink ?
                        <DefaultButton className={styles.viewLinksButton} text={strings.ViewLinks} onClick={() => this.manageLinkButtonClick()} /> : ""}
                </div>
            
                {this.state.manageLink == true || this.props.type == "Webpart" ?
                    <DragDropContext
                    options={{ enableMouseEvents: true }}
                    enableDefaultSensors={false}
                    sensors={[useMouseSensor, useKeyboardSensor, useTouchSensor]}
                    onDragEnd={this.onDragEnd} >
                        <Droppable droppableId="droppable">
                            {(provided) => (
                                <div {...provided.droppableProps}
                                    ref={provided.innerRef}>
                                    {this.state.userLinks.map((items, index) => (
                                        <Draggable key={"" + index} draggableId={"" + index} index={index}>
                                            {(providedExtension) => (
                                                <div className={styles.myLinks}
                                                    ref={providedExtension.innerRef}
                                                    {...providedExtension.draggableProps}
                                                    {...providedExtension.dragHandleProps}
                                                    style={{ ...providedExtension.draggableProps.style, left:"0px !important" }}>
                                                    {<div > <img className={styles.linkImage} src={items.image}></img>
                                                        <div className={styles.title}> <span>{items.title}</span></div>
                                                        {items.mandatory ? <></> : <div className={styles.linkCancelIcon}> <IconButton iconProps={{ iconName: 'Cancel' }} onClick={() => this.openRemoveDialog(items)} /></div>}
                                                    </div>
                                                    }
                                                </div>
                                            )}
                                        </Draggable>
                                    ))}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </DragDropContext> :
                    <div>
                    {this.state.userLinks.map((items) => (
                       <a className={styles.titleLink} data-interception="off" target="_blank" href={items.url.Url} >
                       <div className={styles.myLinks}><img className={styles.linkImage} src={items.image}></img>
                      
                       <div className={styles.title}> <span>{items.title}</span> </div>
                       </div>
                   </a>
                    ))}
                </div>
                }
            </div>
    }
            <Dialog
                hidden={this.state.hideDialog}
                onDismiss={() => this.closeRemoveDialog()}
                dialogContentProps={{
                    type: DialogType.normal,
                    title: strings.RemoveLink,
                    closeButtonAriaLabel: 'Close',
                    subText: strings.Areyousureyouwanttoremovethislink,
                }}
                modalProps={{
                    titleAriaId: "labelId",
                    subtitleAriaId: "subTextId",
                    isBlocking: false,
                    styles: { main: { maxWidth: 450 } },
                }}>
                <DialogFooter>
                    <div>
                        <PrimaryButton onClick={() => this.getFavouriteCompanyLinks(this.state.itemToBeDeleted)} style={{ marginRight: "10px" }} text={strings.RemoveLinkButton}/>
                        <DefaultButton onClick={() => this.closeRemoveDialog()} text={strings.CancelLinkButton} />
                    </div>
                </DialogFooter>
            </Dialog>
        </div >;
    }

    // Updating Manage Link button state in extension 
    private manageLinkButtonClick() {
        this.setState({
            manageLink: !this.state.manageLink
        });
    }

    // Update link removal dialogue state 
    private openRemoveDialog(item: AllAppsLinks) {
        this.setState({
            hideDialog: false,
            itemToBeDeleted: item
        });
    }

    // Update link removal dialogue state 
    private closeRemoveDialog() {
        this.setState({
            hideDialog: true,
            itemToBeDeleted: null
        });
    }

    // update what is selected from pivot items
    private changeSelectedTabkey() {
        this.setState({
            selectedTabKey: strings.CompanyLinks
        });
    }

    // loading state update
    private loadingStart() {
        this.setState({
            loadIconVisible: true
        });
    }

    private loadingEnd() {
        this.setState({
            loadIconVisible: false,
            searchQuery: false,
        });
    }

    //search query state update
    private searchQuery() {
        this.setState({
            searchQuery: true,
        });
    }

    /// <summary>
    /// Method to Handle favourites Of Company Links on heart click
    /// <summary>
    private async getFavouriteCompanyLinks(item: any) {
        this.loadingStart();
        if (item.ID != null) {
            if (item.addtoMyLinks == false) {
                let companyLinkcount = this.companyLinkCount();

                if (companyLinkcount < this.props.count) {
                    item.addtoMyLinks = true;
                    this.state.userLinks.push(item);
                    this.updateFav(this.state.userLinks);
                }
            }
            else {
                item.addtoMyLinks = false;
                let data = this.state.userLinks.filter(items => items.ID != item.ID);
                this.setState({
                    userLinks: data
                }, () => {
                    this.updateFav(this.state.userLinks);
                });
                this.closeRemoveDialog();
            }
        }
        else {
            let data = this.state.userLinks.filter(items => {
                if (items.title == item.title) {
                    return false;
                }
                else return true;
            });
            this.setState({
                userLinks: data
            }, () => {
                this.updateFav(this.state.userLinks);
                this.setCheckCompanyLength();
            });
            this.closeRemoveDialog();
        }
    }

    /// <summary>
    /// Method To perform search on search box based on the values in the text field
    /// <summary>
    private async searchComapnyLinks(searchKey: string) {
        await this.setSearchKey(searchKey);
        localStorage.setItem("InputValue", searchKey);
        try {
            if (this.state.searchItem != "" && this.state.searchItem != null) {
                this.searchQueryData = this.state.companyLinks.filter(item => {
                    if (item.title.toLowerCase().indexOf(this.state.searchItem.toLowerCase()) !== -1) {
                        return true;
                    }
                    else {
                        return null;
                    }
                });
                this.searchQuery();
            }
            else {
                this.setState({
                    searchQuery: false,
                });
            }
        }
        catch (error) {
            throw error;
        }
    }

    //Update searchitem value
    private async setSearchKey(searchkey: string) {
        this.setState({
            searchItem: searchkey,
        });
    }

    private setCheckCompanyLength():boolean {
        return this.state.userLinks.length > 0 && this.state.userLinks.length >= this.props.count;
    }

    // Function to show company Links
    private allCompanyLinksComp() {
        const isMaxLinksExceeded = this.setCheckCompanyLength();
        return (
            <div>
                <div className={styles.companylinksmainDiv}>
                {isMaxLinksExceeded ?  
                <MessageBar messageBarType={MessageBarType.warning} dismissButtonAriaLabel="Close" isMultiline={true} className={styles.errorMessage}> {strings.MaxLimitMessage}</MessageBar> : ""}
                    {/* //Search Box */}
                    <SearchBox value={this.state.searchItem} className={styles.searchBar} placeholder={strings.SearchLink} onChange={e => this.searchComapnyLinks(e.target.value)} onClear={e => this.searchComapnyLinks("")} />
                </div>
                {this.state.searchQuery ?
                    <div>
                        {/* //Show search results */}
                        {this.searchQueryData.map((items) => {
                            return (
                                <div>
                                {this.state.manageLink == true || this.props.type == "Webpart" ? items.mandatory ?
                                <div className={styles.companyLinks}  >
                                    <div className={"itemResponse"}>
                                    <a className={styles.titleLink} data-interception="off" target="_blank" href={items.url.Url} >
                                        <div className={styles.myLinks}>
                                            <img className={styles.linkImage} src={items.image}></img>
                                            <span>{items.title}</span>
                                                                        </div>
                                                                    </a>
                                                                    </div>
                                                                   
                                </div>
                                 :
                                <div className={styles.companyLinks}  >
                                                                        <div className={"itemResponse"}>
                                                                        <div className={styles.myLinks}>
                                                                            <img className={styles.linkImage} src={items.image}></img>
                                            <a className={styles.titleLink} data-interception="off" target="_blank" href={items.url.Url} ><span>{items.title}</span></a>
                                            <IconButton disabled={this.state.loadIconVisible || isMaxLinksExceeded} className={styles.icon} key={items.ID.toString()} iconProps={{ iconName: items.addtoMyLinks ? 'HeartFill' : 'Heart' }} onClick={() => this.getFavouriteCompanyLinks(items)} />
                                                                        </div>
                                                                        
                                                                    </div>
                                                                    </div>
                                :
                                <div className={styles.companyLinks}  >
                                                                    <div className={"itemResponse"}>
                                                                    <a className={styles.titleLink} data-interception="off" target="_blank" href={items.url.Url} >
                                                                        <div className={styles.myLinks}>
                                                                            <img className={styles.linkImage} src={items.image}></img>
                                                                            <span>{items.title}</span>
                                                                        </div>
                                                                    </a>
                                        </div>
                                    </div>
                        }
                                </div>
                            );
                        })}
                    </div>
                    :
                    <div>
                        {/* //All Items Accordion */}
                        <Accordion allowZeroExpanded preExpanded={this.preExpand} >
                            <AccordionItem uuid={this.AllItemsuuid}>
                                <AccordionItemButton>
                                    {strings.AllLinksCategory}
                                </AccordionItemButton>
                                <AccordionItemPanel>
                                    {this.state.companyLinks.map((items) => {
                                        return (
                                            <div>
                                                {this.state.manageLink == true || this.props.type == "Webpart" ? items.mandatory ?        
                                                <div>
                                                <div className={styles.companyLinks} >
                                                <a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  >
                                                    <div className={"itemResponse"}>  
                                                        <div className={styles.myLinks}>
                                                            <div> <img className={styles.linkImage} src={items.image}></img>
                                                                <div className={styles.title}> <span>{items.title}</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                                </div>
                                                </div> :
                                                <div>
                                                    <div className={styles.companyLinks} >
                                                        <div className={"itemResponse"}>  
                                                            <div className={styles.myLinks}>
                                                                <div> <img className={styles.linkImage} src={items.image}></img>
                                                                    <div className={styles.title}><a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  > <span>{items.title}</span></a></div>
                                                                    <div className={styles.HeartIcon}> <IconButton disabled={this.state.loadIconVisible || isMaxLinksExceeded} className={styles.icon} key={items.ID.toString()} iconProps={{ iconName: items.addtoMyLinks ? 'HeartFill' : 'Heart' }} onClick={() => this.getFavouriteCompanyLinks(items)} /> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            : 
					                        <div>
                                                <div className={styles.companyLinks} >
                                                <a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  >
                                                    <div className={"itemResponse"}>
                                                        <div className={styles.myLinks}>
                                                            <div> <img className={styles.linkImage} src={items.image}></img>
                                                                <div className={styles.title}><a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  > <span>{items.title}</span></a></div>
                                                            </div>
                                                        </div>
                                                        </div>
                                                </a>

                                                </div>
                                                </div>
                                                   } 
                                                
                                            </div>
                                        );
                                    })}
                                </AccordionItemPanel>
                            </AccordionItem>
                        </Accordion>
                        {/* //Accordion as per category */}
                        {this.state.companyLinks.map(item => {
                            if (this.companyLinksUniqueCategory.indexOf(item.category) === -1) {
                                this.companyLinksUniqueCategory.push(item.category);
                            }
                        })}
                        {this.companyLinksUniqueCategory.map((item, index) => {
                            return (
                                <div>
                                    <Accordion allowZeroExpanded preExpanded={this.preExpand} >
                                        <AccordionItem uuid={index.toString()}>
                                            <AccordionItemHeading  >
                                                <AccordionItemButton>
                                                    {item}
                                                </AccordionItemButton>
                                            </AccordionItemHeading>
                                            <AccordionItemPanel >
                                                {this.state.companyLinks.map((items) => {
                                                    if (items.category == item) {
                                                        return (
                                                            <div>
                                                               {this.state.manageLink == true || this.props.type == "Webpart" ? items.mandatory ?        
                                                <div>
                                                <div className={styles.companyLinks} >
                                                <a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  >
                                                    <div className={"itemResponse"}>  
                                                        <div className={styles.myLinks}>
                                                            <div> <img className={styles.linkImage} src={items.image}></img>
                                                                <div className={styles.title}><a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  > <span>{items.title}</span></a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                                </div>
                                                </div> :
                                                <div>
                                                    <div className={styles.companyLinks} >
                                                        <div className={"itemResponse"}>  
                                                            <div className={styles.myLinks}>
                                                                <div> <img className={styles.linkImage} src={items.image}></img>
                                                                    <div className={styles.title}><a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  > <span>{items.title}</span></a></div>
                                                                    <div className={styles.HeartIcon}> <IconButton disabled={this.state.loadIconVisible || isMaxLinksExceeded} className={styles.icon} key={items.ID.toString()} iconProps={{ iconName: items.addtoMyLinks ? 'HeartFill' : 'Heart' }} onClick={() => this.getFavouriteCompanyLinks(items)} /> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            : 
					                        <div>
                                                <div className={styles.companyLinks} >
                                                <a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  >
                                                                    <div className={"itemResponse"}>
                                                                        <div className={styles.myLinks}>
                                                                        <div> <img className={styles.linkImage} src={items.image}></img>
                                                                <div className={styles.title}><a className={styles.linksTitle} data-interception="off" target="_blank" href={items.url.Url}  > <span>{items.title}</span></a></div>
                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    </a>
                                                                </div>
                                                                </div>}
                                                            </div>
                                                        );
                                                    }
                                                })}
                                            </AccordionItemPanel>
                                        </AccordionItem>
                                    </Accordion>
                                </div>
                            );
                        })}
                    </div>
                }
            </div>
        );
    }

    // render panel
    public render(): React.ReactElement<IMyApplicationV2Props> {
        return (
            <div>
                {this.panelUI()}
            </div>
        );
    }

    // handle custom link callout state
    private handleShowCallout(event) {
        if (!this.state.addCustomLinkCallout) {
            this.setState({
                addCustomLinkCallout: true
            });
        }
    }

    private handleHideCallout() {
        if (this.state.addCustomLinkCallout) {
            this.setState({
                addCustomLinkCallout: false,
                checkDuplicateTitle: false,
                checkifNewTitleContaisPipe: false,
                checkifNewUrlConatinsPipe: false,
                checkInvalidUrl: false,
                newItemTitle: "",
                newItemUrl: "",
            });
        }
    }

    /// <summary>
    /// Method to detect New Custom Link Title
    /// </summary>
    private titleUpdated(event) {
        let newTitle = event.target.value;
        let linkTitleExists = this.checkIfLinkTitleAlreadyExists(newTitle);
        let containsPipe = this.checkIfLinkTitleContainsPipe(newTitle);
        this.setState({
            newItemTitle: event.target.value,
            checkDuplicateTitle: linkTitleExists,
            checkifNewTitleContaisPipe: containsPipe

        });
    }

    /// <summary>
    /// Method to detect New Custom Link Url
    /// </summary>
    private urlUpdated(event) {
        var urlVal = event.target.value.toLowerCase();
        let containsPipe = this.checkIfLinkUrlContainsPipe(urlVal);
        let isInValidUrl = this.isValidHttpUrl(urlVal);
        this.setState({
            newItemUrl: urlVal,
            checkInvalidUrl: isInValidUrl,
            checkifNewUrlConatinsPipe: containsPipe,
        });
    }

    private isValidHttpUrl(userInput) {
        var regexp = /^http(s)?:\/\/(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
        try {
            if (regexp.test(userInput)) {
                this.setState({
                    checkInvalidUrl: false
                });
                return false;
            }
            else {
                this.setState({
                    checkInvalidUrl: true
                });
                return true;
            }
        }
        catch (error) {
            throw error;
        }
    }

    /// <summary>
    ///  Method To add new links in user profile property
    /// <summary>
    private addCustomizableLink() {
        let item = { ID: null, title: this.state.newItemTitle, url: { Description: null, Url: this.state.newItemUrl }, image: null, sequence: null, mandatory: null, priority: null, category: null, description: null, addtoMyLinks: true };
        this.state.userLinks.push(item);
        this.updateFav(this.state.userLinks).then(() => {
            this.handleHideCallout();
        });
    }

    /// <summary>
    /// Method to Check if New Custom Link Title is not Duplicate
    /// <summary>
    public checkIfLinkTitleAlreadyExists(userInput) {
        let duplicateArr = this.state.userLinks.map(a => a.title.toLowerCase());
        if (duplicateArr.indexOf(userInput.toLowerCase()) != -1) {
            return true;
        }
        else {
            return false;
        }
    }

    /// <summary>
    /// Method to Check if New Custom Link Title does not contain "|"
    /// <summary>
    public checkIfLinkTitleContainsPipe(userInput) {
        if (userInput.includes("|")) {
            return true;
        }
        else {
            return false;
        }
    }

    /// <summary>
    /// Method to Check if New Custom Link url does not contain "|"
    /// <summary>
    public checkIfLinkUrlContainsPipe(userInput) {
        if (userInput.includes("|")) {
            return true;
        }
        else {
            return false;
        }
    }

    /// <summary>
    /// Method to Check if exceeding limit
    /// <summary>
    public companyLinkCount() {
        let count = 0;
        this.state.userLinks.map(Item => {
            if (Item.ID != null) {
                count = count + 1;
            }
        });
        return count;
    }

    /// <summary>
    /// Method To Render Modal Pop-Up On Click of Personalize Button
    /// <summary>
    private panelUI() {
        return (
            <div>
                <Pivot styles={pivotStyles} selectedKey={this.state.selectedTabKey} onLinkClick={this._onLinkClick}>
                    <PivotItem headerText={strings.MyLinks} itemKey={strings.MyLinks}  >
                        {this.getMyLinksComp()}
                    </PivotItem>
                    <PivotItem headerText={strings.CompanyLinks} itemKey={strings.CompanyLinks} >
                        {this.allCompanyLinksComp()}
                    </PivotItem>
                </Pivot>
            </div>
        );
    }

    /// <summary>
    /// Function to handle links navigation events between My Links and Company Links tab
    /// <summary>
    private _onLinkClick = item => {
        this.setState({
            selectedTabKey: item.itemKey,
            searchQuery: false,
            searchItem: "",
            hideDialog: true
        });
        this.preExpand = [];
    }
}



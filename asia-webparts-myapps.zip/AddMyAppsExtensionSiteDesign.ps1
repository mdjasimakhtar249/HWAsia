Param(
   [Parameter(Mandatory=$true)]
   [string]$adminUrl
) 

$ErrorActionPreference = "Stop"

Connect-SPOService -Url $adminUrl
$c = Get-Content .\MyAppsExtensionSiteScript.json -Raw
$s = Add-SPOSiteScript -Title "My Applications Extension" -Content $c
Add-SPOSiteDesign -Title "My Applications Extension" -WebTemplate "68" -SiteScripts $s.Id -Description "Enable the My Applications extension on this site"
Disconnect-SPOService
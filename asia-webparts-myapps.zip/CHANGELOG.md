# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [1.0.3] - 2024-12-17

### Changes
* SPFx Upgraded to version 1.20.0 as per [Release Notes](https://learn.microsoft.com/en-us/sharepoint/dev/spfx/release-1.20)
* Node version upgraded from 16.13.x to 18.18.x

## [1.0.2] - 2024-11-14
### Fixed
* Updated asia-lib version to 10.0.2 and sppkg version to 1.0.2.0

## [1.0.1] - 2024-10-18
### Fixed
* Updated asia-lib version to 10.0.1 and sppkg version to 1.0.1.0

## [10.0.0] - 2023-11-27
* asia-lib version updated to 10.0.0

## [1.0.0] - 2023-09-21
 SPFx Upgraded to version 1.17.4 as per [Release Notes](https://learn.microsoft.com/en-us/sharepoint/dev/spfx/release-1.17.4)
* Node version upgraded from 12.x to 16.13.x
* asia-lib version updated to 10.0.0-dev11


## [1.0.0] - 2023-05-16
* SPFX 1.17.3 upgrade as per [Release Notes](https://docs.microsoft.com/en-us/sharepoint/dev/spfx/release-1.17.3). 
* Node 16.13.x.
* React and ReactDOM v17.0.1, office-ui-fabric v7.199.1.
* @types/react v 17.0.45 and @types/react-dom v17.0.17 installed.

## [9.0.0] - 2023-05-09
* responsiveness issue fixed
* updated My Information functionality
* My information errors fixed 
* Functionality added to adjust height of the webpart
* Functionality added to change Progress bar color
* handled errors
* Fixed my files loading issue

### changes
* SPFX 1.14.0 upgrade as per [Release Notes](https://docs.microsoft.com/en-us/sharepoint/dev/spfx/release-1.14). 
* Updated asia-lib version as 9.0.0
* css issue fixed
* alignment issue fixed
* Modify .yml build pipeline to create Independant package only
* added toggle control for my Information, my Day, my Actions and apps

### Changes
* SPFX 1.12.1 upgrade as per [Release Notes](https://docs.microsoft.com/en-us/sharepoint/dev/spfx/release-1.12.1). 
    * Node 14.x, Gulp v4.0.2, yo v4.0.2 upgraded with @microsoft/generator v1.12.1
    * React and ReactDOM v16.9.36, office-ui-fabric v7.156.0, Typescript v3.7 upgraded.
    * @types/react v 16.9.36 and @types/react-dom v16.9.8 installed to fix build issues.
    * Updated gulpfile.js.
    * Update ImagePicker.tsx file based on the latest pnp file picker control.
* Remove fi.js and sv-se.js localization files from all webparts.

### Fixes
* Welcome webpart vertical section css fix.
* Welcome webpart - Upcoming Events timezone fix. Time will now be displayed in current user timezone settings instead of UTC format.
* Welcome webpart - Fixed build issue related to office-ui-fabric-react

## [8.0.1] - 2021-02-23

### Fixed

* Bug related to WelcomeCardWebPart Calendar section not showing all events.
* Bug related to WelcomeCardWebPart not displaying correct temparature while changing unit from C to F and vice versa after page reloading.

### Changes

* Added method in SecureMarkupService file to convert input HTML to secure HTML using DOMPurify

## [8.0.0] - 2020-10-08

### Changes

* SPFx 1.11 Upgrade
* Updated asia-lib reference after merging asia-lib-core and asia-lib-ui into asia-lib.
* Modify .yml build pipeline to create 2 packages i.e. Independent(doesn't require asia-lib in appCatalog to load webparts) and Dependent package(require asia-lib in appCatalog) from same solution.
* Added 0BSD package under allowed in license-check.json to remove build error.

## [7.0.1] - 2020-06-12

### Changes

* Welcome webpart enhancements:
    -> Added ImagePicker and ColorPicker pnp control in propertypane.
    -> Combined first two profile and weather sections.
    -> Profile Complete percentage with profile tooltip added in the first section.
    -> Added pnp PropertyFieldCollectionData to calculate priority and weightage based on selected user profie propetry fields. 

## [7.0.0] - 2020-04-13

### Changes

* Removed webApiPermissionRequests related to Microsoft Graph.
* Added cli-table package under ignore in license-check.json.
* Upgraded SPFx from 1.9.1 to 1.10.0

## [6.0.0] - 2020-03-26

### Changes

* Updated .yml pipeline to new Microsoft hosted agent as old agents(vs2015-win2012r2) removed by Azure.

## [6.0.0] - 2020-02-27

### Changes

* Update asia-lib reference for bug fix -> remove unnecessary calls to local config if only global config present.

## [6.0.0] - 2019-08-11

### Changes

* Updated version
* SPFx 1.9.1 upgrade with spfx library component.
* Added code changes for enable or disable code editor from Global Config. Code editor will be visible after making enableCodeEditor property to true in Global Config and vice versa.
* Bug fix for security issue related to enable or disable code editor from Global Config using enableCodeEditor value in Config. 

## [5.0.3] - 2019-23-07

### Added

* Added code changes for welcomeCard Web Part for rendering issue Section Layout.
* Updated asia-lib and asia-lib-ui version.

## [5.0.2] - 2019-31-05

### Modified

* updated asia-lib version
* Searchable property names code changes.

## [5.0.1] - 2019-14-5

### Added

* Added code changes for supporting theme variants for web parts when added in section with different backgrounds

## [5.0.0] - 2019-17-04

### Modified

* SPFX 1.8 upgrade and tslint changes related to unused variables and interfaces,typecast and         ms-styles.
* updated version

## [4.1.0] - 2019-22-03

### Fixed

* App Insights Logging Bug

### Modified

* Updated version

## [4.1.0] - 2019-19-02

### Modified

* added license-check.json
* added WebPart Title control
* added Config control
* Updated version

## [4.0.0] - 2019-18-01

### Modified

* Changed version

## [4.0.0-preview] - 2019-18-01

### Modified

* Upgraded SPFx to 1.7
* Changed version number

## [Released]

## [3.0.0] - 2018-11-06

### Added

* Added this CHANGELOG.md file
* Added the asia-welcome-card solution
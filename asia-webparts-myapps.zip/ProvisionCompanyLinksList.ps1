Param
(
    [Parameter(Mandatory=$true)]
    [string]$siteUrl
)
$ErrorActionPreference = "Stop"
Connect-PnPOnline -Url $siteUrl -Interactive
$listName = "Company Links"
Write-Host "Creating Company Links list..."
$l = New-PnPList -Title $listName -Template GenericList 
Write-Host "Adding fields to Company Links list..."
$f = Add-PnPField -List $listName -InternalName "AvaAppUrl" -DisplayName "App Url" -Type URL -AddToDefaultView -Required
$f = Add-PnPField -List $listName -InternalName "AvaAppDescription" -DisplayName "Description" -Type Text -AddToDefaultView
$f = Add-PnPField -List $listName -InternalName "AvaAppCategory" -DisplayName "Category" -Type Text -AddToDefaultView -Required
$f = Add-PnPField -List $listName -InternalName "AvaAppImage" -DisplayName "Image" -Type Thumbnail -AddToDefaultView
$f = Add-PnPField -List $listName -InternalName "AvaAppPriority" -DisplayName "Priority" -Type Number -AddToDefaultView
$f = Add-PnPField -List $listName -InternalName "AvaAppMandatory" -DisplayName "Mandatory" -Type Boolean -AddToDefaultView
$ff = Get-PnPField -List $listName -Identity "AvaAppMandatory"
$ff.DefaultValue = "0"
$ff.Update()
Invoke-PnPQuery
Write-Host "Company Links List set up successful!" -ForegroundColor Green
Disconnect-PnPOnline
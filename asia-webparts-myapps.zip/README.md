# my-application-v-2

## Summary

Short summary on functionality and used technologies.

---
title: My Applications V2
draft: true

---

## How to use the My Applications Webpart

My Application V2 has three sctions -
    1. My Application V2 Webpart
    2. My Application V2 Extenstion
    3. My Application v2 Ace Card

The My Applications V2 Webpart displays application which are marked favourite by the user along with aplication which are marked mandatory by admin. These apps uses one SharePoint list and a user profile property, the user can choose to mark or unmark favourite apps that he would like to show on his My Applications view by using the personalize button. 

The My Application V2 Extenstion shows the same panel of application as in webpart in view mode initially, which can be managed(personalized) by clicking on "Manage" button.

The My Application Ve Ace card shows the favourite and mandatory applictions in the read only mode.

## Limitations

- Maximum 50 company managed, and 10 custom links can be marked as favourite.

## Searching

-	Users can search company managed applications using a search bar provided in the company links section.

## Provision the lists for the webpart

The list **All Apps** is managed by the company and
Both list apps and custom added apps is being saved in a user profile property **AvaPersonalQuickLinks** 

You need to provision a list to add Apps data, which can be done by executing "ProvisionAllApps.ps1" script present in the webpart:
The **All Apps** list will contain all company managed apps. When a user adds an app using add button, it goes to the company links section of the webpart in given category.

## Deploying the package

To configure the all three webpart, extension and ace card, you will need to:

    1. Create an entry for myapps under services in your config.json file or globally present config object like given below - 
    **"myapps": {
                                "extensionHTML" : "<div class=\"avaQuickLinksExtension\">Quick Links</div><style>.avaQuickLinksExtension{ position:fixed;top:13px;right:200px;cursor:pointer;z-index:100;font-size:12px;padding:2px 8px 2px 8px;font-weight:600;border-radius:3px;color:white;border:1px solid white;display:inline;}@media screen and (max-width: 1023px){ .avaQuickLinksExtension{ display:none; }}</style>",
                                "companyLinksSiteUrl": "https://TenantName.sharepoint.com/sites/SiteName",
                                "listTitle" : "Company Links",
                                "maxSelectedCompanyLinks": "50",
                                "defaultImageLink":"https://TenantName.sharepoint.com/sites/SiteName/SiteAssets/QuickLinkImages/defaultImageFileName.png",
                                "userProfilePropertyName":"(Enter the profilepropertyname you created)"
                                "extensionHTML":  "<style>.tutorialPlayButton {   position: fixed;   top: 13px;   right: 400px;   cursor: pointer;   z-index: 100;   font-size: 12px;   padding: 2px 8px 2px 8px;   font-weight: 600;   border-radius: 3px;   color: white;   border: 1px solid white;   display: inline; }  .tutorialPlayMobileButton {   display: none; } @media screen and (max-width: 912px) { .tutorialPlayButton {     display: none !important;   }  .tutorialPlayMobileButton {     position: fixed;     bottom: 100px;     right: 3px;     z-index: 999;     background: #ffffff;     display: flex !important;     height: 40px;     width: 40px;     justify-content: center;     align-items: center;     border-radius: 50%;     box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 1px 2px rgba(0, 0, 0, 0.23);   }  .tutorialPlayMobileButton img {     width: 20px;     height: 20px;   } } </style><div id='tutorialPlayButton' class='tutorialPlayButton'>Quick Links</div><div id='tutorialPlayMobileButton' class='tutorialPlayMobileButton'><img src='https://4d7bpl.sharepoint.com/SiteAssets/QuickLinks.svg'/></div>",
                                },**

    2. Create a user profile property –
        1. Go to SharePoint Admin Centre (classic)
        2. Go to User Profiles
        3. Go to Manage User Properties
        4. Click on New Property
        5. Create the following user profile properties and populate the form as per the entries in the below table.
        Also, here user can enter any name based on their need for the profileproperty.
        [we have  given AvaPersonalQuickLinks below as example]
        *(keep default values for all the other properties not mentioned in the table) * :
        | User Profile Property - ** AvaPersonalQuickLinks ** |
        | Name - AvaPersonalQuickLinks |
        | Display Name - AvaPersonalQuickLinks |
        | Type - String(Single Value) |
        | Length - 3600 |
        | Policy Setting - Optional |
        | Default Privacy Setting - Only Me |
        | Allow users to edit values for this property - Check |
        | Indexed - Uncheck |

    3. For extension, run AddMyAppsExtensionSiteDesign.ps1 script and it will show the ‘quick links’ button on the top right on the site where it’s activated.

    4. For Handlebar files, create a "MyAppsV2" folder inside your template folder and upload sample handlebar files present in the this repo.

## Mandatory Applications Information

Admin can make the applications as mandatory at any point of time from the sharepoint list and those applications will be vsible for all the users, users will not be able to remove it from the webpart, however if admin decides to make any application as "non-mandatory", users will still be able to see the application but it will be removable with a cross icon.

##  webpart properties from propertypane

    1.	**Title**: This is a textbox control that lets you enter a title for the webpart.
    2.	**Handlebar**: This control lets you design the application visible in the webpart as per your requirement, a few sample handlebar files hae also been created for reference present in "SampleHandlebar" folder.

## Updates to the My Applications webpart
'use strict';

const gulp = require('gulp');
const build = require('@microsoft/sp-build-web');
const path = require('path');
const webpack = require('webpack');
const log = require('fancy-log');
const fs = require('fs');
const colors = require('colors');
build.addSuppression(`Warning - [sass] The local CSS class 'ms-Grid' is not camelCase and will not be type-safe.`);
build.addSuppression(`Warning - [configure-webpack] Unable to resolve project "mocha". Ensure it has been linked.`);
build.addSuppression(/Warning - \[sass\] The local CSS class/gi);
const readJson = (path, cb) => {
  fs.readFile(require.resolve(path), (err, data) => {
      if (err)
          log.error(err)
      else
          cb(null, JSON.parse(data))
  });
}

build.addSuppression(/^Warning - \[sass\].*$/);

// Retrieve the current build config and check if there is a `warnoff` flag set
const crntConfig = build.getConfig();
const warningLevel = crntConfig.args["warnoff"];

// Extend the SPFx build rig, and overwrite the `shouldWarningsFailBuild` property
if (warningLevel) {
  class CustomSPWebBuildRig extends build.SPWebBuildRig {
      setupSharedConfig() {
          build.log("IMPORTANT: Warnings will not fail the build.")
          build.mergeConfig({
              shouldWarningsFailBuild: false
          });
          super.setupSharedConfig();
      }
  }

  build.rig = new CustomSPWebBuildRig();
}

const envCheck = build.subTask('environmentCheck', (gulp, config, done) => {

  if (!config.production) {
      //https://spblog.net/post/2019/09/18/spfx-overclockers-or-how-to-significantly-improve-your-sharepoint-framework-build-performance#h_296972879501568737888136
      log(`[${colors.cyan('configure-webpack')}] Turning off ${colors.cyan('tslint')}...`);
      build.tslintCmd.enabled = false;
  }
  done();
});

build.rig.addPreBuildTask(envCheck);

var getTasks = build.rig.getTasks;
build.rig.getTasks = function () {
  var result = getTasks.call(build.rig);

  result.set('serve', result.get('serve-deprecated'));

  return result;
};
build.initialize(gulp);

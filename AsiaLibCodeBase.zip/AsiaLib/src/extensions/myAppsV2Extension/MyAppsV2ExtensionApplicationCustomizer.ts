import { Log } from "@microsoft/sp-core-library";
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName,
} from "@microsoft/sp-application-base";
import * as React from "react";
import {
  HWConfigServiceKey,
  IHWConfiguration,
  IStorageEntityBaseService,
} from "../../library";
import MyAppsLauncher, { IMyAppsLauncherProps } from "./MyAppsLauncher";
import * as ReactDOM from "react-dom";
import { ReactElement } from "react";
import { AllAppsLinks } from "../../Services/MyApplications";

const LOG_SOURCE: string = "MyAppsV2ExtensionApplicationCustomizer";

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IMyAppsV2ExtensionApplicationCustomizerProperties {
  count: any;
  defaultImageLink: string;
  companyLinksListUrl: string;
  companyListTitle: string;
  userProfilePropertyName: string;
  comapanyLinks: AllAppsLinks[];
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class MyAppsV2ExtensionApplicationCustomizer extends BaseApplicationCustomizer<IMyAppsV2ExtensionApplicationCustomizerProperties> {
  private _topPlaceholder: PlaceholderContent | undefined;
  protected configService: IStorageEntityBaseService<IHWConfiguration>;
  protected myAppsLauncherElement: ReactElement<IMyAppsLauncherProps>;

  public onInit(): Promise<void> {
    let serviceScopeParent = this.context.serviceScope.getParent();
    if (serviceScopeParent != undefined) {
      serviceScopeParent.whenFinished(() => {
        if (serviceScopeParent != undefined)
          this.configService = serviceScopeParent.consume(HWConfigServiceKey);
      });
    }
    return this.configService.load().then(() => {
      if (this.configService.settings().services.myapps == undefined) {
        this.properties.count = 50;
      } else {
        this.properties.count =
          this.configService.settings().services.myapps.maxSelectedCompanyLinks;
      }
      this.properties.defaultImageLink =
        this.configService.settings().services.myapps.defaultImageLink;
      this.properties.userProfilePropertyName =
        this.configService.settings().services.myapps.userProfilePropertyName;
      this.properties.companyLinksListUrl =
        this.configService.settings().services.myapps.companyLinksSiteUrl;
      this.properties.companyListTitle =
        this.configService.settings().services.myapps.listTitle;
      this.context.placeholderProvider.changedEvent.add(
        this,
        this._renderPlaceHolders
      );
    });
  }

  private _renderPlaceHolders(): void {
    // Handling the top placeholder
    if (!this._topPlaceholder) {
      this._topPlaceholder = this.context.placeholderProvider.tryCreateContent(
        PlaceholderName.Top,
        { onDispose: this._onDispose }
      );

      // The extension should not assume that the expected placeholder is available.
      if (!this._topPlaceholder) {
        console.error("The expected placeholder (Top) was not found.");
        return;
      }

      if (this._topPlaceholder.domElement) {
        this.myAppsLauncherElement = React.createElement<IMyAppsLauncherProps>(
          MyAppsLauncher,
          {
            serviceScope: this.context.serviceScope,
            count: this.properties.count,
            callback: Function,
            context: this.context,
            defaultImageLink: this.properties.defaultImageLink,
            companyLinksListUrl: this.properties.companyLinksListUrl,
            companyListTitle: this.properties.companyListTitle,
            userProfilePropertyName: this.properties.userProfilePropertyName,
            companyLinks: this.properties.comapanyLinks,
          }
        );
        ReactDOM.render(
          this.myAppsLauncherElement,
          this._topPlaceholder.domElement
        );
      }
    }
  }

  private _onDispose(): void {
    console.log(
      "[HelloWorldApplicationCustomizer._onDispose] Disposed custom top and bottom placeholders."
    );
  }
}

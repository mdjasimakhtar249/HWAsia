declare interface IMyAppsV2ExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'MyAppsV2ExtensionApplicationCustomizerStrings' {
  const strings: IMyAppsV2ExtensionApplicationCustomizerStrings;
  export = strings;
}

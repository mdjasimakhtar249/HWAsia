define([], function() {
  return {
    "Title": "MyAppsV2ExtensionApplicationCustomizer"
  }
});
import { IDesignChoiceSettings } from "../IDesignChoiceSettings";
import { IChoiceGroupOption } from "office-ui-fabric-react/lib/ChoiceGroup";
import { IPropertyPaneDropdownOption } from "@microsoft/sp-property-pane";
import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IDesignChoiceProps {
    label: string;
    value: IDesignChoiceSettings;
    options: IChoiceGroupOption[];
    customTemplateOptionKey: string;
    templateSelectionOptionKey: string;
    uploadSelectionOptionKey: string;
    enableCustomTemplates: boolean;
    enableTemplateSelection: boolean;
    enableUploadSelection: boolean;
    filePickerResult: IDesignChoiceSettings;
    templates: IPropertyPaneDropdownOption[];
    disabled: boolean;
    stateKey: string;
    sharedStrings: any;
    sampleData?: any;
    libraries: IPropertyPaneDropdownOption[];
    onChanged: (setting: IDesignChoiceSettings) => void;
    componentId: string;
    context: WebPartContext;
}
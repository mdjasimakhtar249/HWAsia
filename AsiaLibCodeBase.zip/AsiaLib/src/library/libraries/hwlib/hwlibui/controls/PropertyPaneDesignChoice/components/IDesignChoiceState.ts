export interface IDesignChoiceState {
  customTemplate: string;
  template: string;
  key: string;
  showEditor: boolean;
  filePickerResult: any;
  handlebarUploadDefaultLibrary: string;
  selectedLibrary: string | string[] | number;
}
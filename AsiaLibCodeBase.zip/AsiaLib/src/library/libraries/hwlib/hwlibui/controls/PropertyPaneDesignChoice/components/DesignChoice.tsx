import * as React from 'react';
import { Dropdown } from 'office-ui-fabric-react/lib/Dropdown';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react/lib/ChoiceGroup';
import { IDesignChoiceProps } from './IDesignChoiceProps';
import { IDesignChoiceState } from './IDesignChoiceState';
import { PrimaryButton, CompoundButton } from 'office-ui-fabric-react/lib/Button';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { FilePicker, IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';
import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions } from '@microsoft/sp-http';
import { createTheme, ITheme } from 'office-ui-fabric-react';

const ThemeColorsFromWindow: any = (window as any).__themeState__.theme;
const siteTheme: ITheme = createTheme({ palette: ThemeColorsFromWindow });
let registeredCompletionItems: boolean = false;

export default class DesignChoice extends React.Component<IDesignChoiceProps, IDesignChoiceState> {

    constructor(props: IDesignChoiceProps, state: IDesignChoiceState) {
        super(props);
        this.state = {
            key: this.props.value ? this.props.value.designChoice : '',
            customTemplate: this.props.value.customTemplate ? this.props.value.customTemplate : '',
            template: this.props.value.template ? this.props.value.template : '',
            showEditor: false,
            filePickerResult: this.props.value.filePickerResult ? this.props.value.filePickerResult : '',
            handlebarUploadDefaultLibrary: this.props.value.handlebarUploadDefaultLibrary,
            selectedLibrary: this.props.value.handlebarUploadDefaultLibraryKey!
        };
    }

    private monacoContainer: HTMLDivElement;
    private editor: any;

    public updateDimensions() {
        this.editor.layout();
    }

    public render(): JSX.Element {
        let url: string;
        const styles: React.CSSProperties = {
            width: '100%',
            height: '600px',
            border: '1px solid grey',
            margin: '5px'
        };
        return (
            <div>
                <Label>{this.props.label}</Label>
                <ChoiceGroup
                    options={this.props.options}
                    selectedKey={this.state.key}
                    onChange={(e, o) => { this.setState({ key: (o as IChoiceGroupOption).key }, () => { this._updateSetting(); }); }} />
                {this.props.enableUploadSelection &&
                    <div>
                        <Dropdown
                            label={this.props.sharedStrings.SelectLibrary}
                            options={this.props.libraries}
                            disabled={false}
                            defaultSelectedKey={this.props.value.handlebarUploadDefaultLibraryKey}
                            selectedKey={this.state.selectedLibrary}
                            onChanged={(val) => {
                                this.setState({ selectedLibrary: val.key.toString() }, () => { this._updateSetting(); });
                            }}
                        />
                        <Label>{this.props.sharedStrings.UploadTemplate}</Label>
                        <FilePicker
                            accepts={[".hbs"]}
                            storeLastActiveTab={false}
                            buttonLabel={this.props.sharedStrings.UploadButtonLabel}
                            onSave={(filePickerResult: IFilePickerResult[]) => {
                                //if upload tab is clicked
                                if (filePickerResult && filePickerResult.length > 0) {
                                    for (var i = 0; i < filePickerResult.length; i++) {
                                        const item = filePickerResult[i];
                                        if (item.fileAbsoluteUrl == null) {
                                            item.downloadFileContent().then((File) => {
                                                //post call to save file in the SP document library
                                                let spOpts: ISPHttpClientOptions = {
                                                    headers: {
                                                        "Accept": "application/json",
                                                        "Content-Type": "application/json"
                                                    },
                                                    body: File
                                                };
                                                url = this.props.context.pageContext.web.absoluteUrl + `/_api/Web/Lists(guid'${this.state.selectedLibrary}')/RootFolder/Files/Add(url='${item.fileName}', overwrite=true)`;
                                                this.props.context.spHttpClient.post(url, SPHttpClient.configurations.v1, spOpts).then((response: SPHttpClientResponse) => {
                                                    response.json().then((responseJSON: any) => {
                                                        item.fileAbsoluteUrl = encodeURI(window.location.origin + responseJSON.ServerRelativeUrl);
                                                        this.setState({ filePickerResult: item }, () => { this._updateSetting(); });
                                                    });
                                                });
                                                //post call ends                        
                                            });
                                        }
                                        else {
                                            this.setState({ filePickerResult: item }, () => { this._updateSetting(); });
                                        }
                                    }
                                }
                            }}                            
                            context={this.props.context as any}
                            disabled={this.state.key != this.props.uploadSelectionOptionKey}
                        />
                        {this.props.value.filePickerResult!.fileName &&
                            <Label style={{ fontWeight: 600, fontStyle: 'italic', color: siteTheme.palette.themePrimary }}>{this.props.value.filePickerResult!.fileName}</Label>}
                    </div>
                }
                {this.props.enableTemplateSelection &&
                    <Dropdown
                        label={this.props.sharedStrings.SelectCustomTemplate}
                        options={this.props.templates}
                        disabled={this.state.key != this.props.templateSelectionOptionKey}
                        selectedKey={this.state.template}
                        onChanged={(val) => {
                            this.setState({ template: val.key.toString() }, () => { this._updateSetting(); });
                        }}
                    />
                }
                {this.props.enableCustomTemplates &&
                    <div>
                        <Label>{this.props.sharedStrings.CustomTemplate}</Label>
                        <CompoundButton
                            primary={true}
                            secondaryText={this.props.sharedStrings.LaunchEditor}
                            disabled={this.state.key != this.props.customTemplateOptionKey}
                            onClick={this._onEditorClick}>{this.props.sharedStrings.Edit}</CompoundButton>
                        <Panel
                            isOpen={this.state.showEditor}
                            onDismiss={this._onClosePanel}
                            type={PanelType.medium}
                            headerText={this.props.sharedStrings.CodeEditor}
                            onRenderFooterContent={this._onRenderFooterContent}
                        >
                            <div ref={ref => { this.monacoContainer = ref as HTMLDivElement; }} style={styles}></div>
                        </Panel>
                    </div>}
            </div>
        );
    }

    private _onClosePanel = () => {
        if (this.editor) {
            this.editor.dispose();
            this.editor = undefined;
        }
        this.setState({ showEditor: false });
    }

    private _onRenderFooterContent = (): JSX.Element => {
        return (
            <div>
                <PrimaryButton onClick={this._onClosePanel} style={{ marginRight: '8px' }}>
                    Close
                </PrimaryButton>
            </div>
        );
    }

    private _updateSetting = () => {
        this.props.onChanged({
            designChoice: this.state.key,
            customTemplate: this.state.customTemplate,
            template: this.state.template,
            filePickerResult: this.state.filePickerResult,
            handlebarUploadDefaultLibrary: this.state.handlebarUploadDefaultLibrary,
            selectedLibrary: this.state.selectedLibrary
        });
    }

    private _onEditorClick = () => {
        this.setState({
            showEditor: true
        }, async () => {
            if (!this.editor) {
                const w: any = window;
                const Monaco = await import(
                    /* webpackChunkName: 'monaco' */
                    'monaco-editor/esm/vs/editor/editor.api'
                );
                // INFO: we need to set the monaco environment to use the location of the actual SPFx component
                const manifests = (SPComponentLoader as any).getManifests().filter(m => { return m.id == this.props.componentId; });
                if (manifests.length == 0) {
                    console.error('HW: Invalid component id');
                    return null;
                }
                const manifest = manifests[0];
                let url: string = manifest.loaderConfig.internalModuleBaseUrls[0];
                w.MonacoEnvironment = {
                    baseUrl: url,
                    getWorker: (workerId, label) => {
                        // NOTE: This will not work in the online workbench, due to that the workers are hosted on localhost
                        // More information: https://github.com/Microsoft/monaco-editor/blob/master/docs/integrate-amd-cross.md
                        let stringPosition = url.indexOf('localhost');
                        if (stringPosition != -1) {
                            url = url + 'dist/'; // For the Workbench example
                            console.warn('RUNNING CODE EDITOR IN THE WORKBENCH IS NOT SUPPORTED');
                        } else {
                            // INFO: these are loaded in JS worker threads and we get a 404 if on a public cdn (due to that we don't have a referrer)
                            url = url.replace('publiccdn.sharepointonline.com/', '');
                        }
                        let bundle = 'editor.worker.js';
                        if (label === 'html' || label === 'handlebars') {
                            bundle = 'html.worker.js';
                        }
                        let isSlashFound: boolean = (url.indexOf("/", url.length - 1) != -1);
                        if (isSlashFound === true) {
                            return new Worker(`${url}${bundle}`);
                        }
                        else if (isSlashFound === false) {
                            return new Worker(`${url}/${bundle}`);
                        }

                    }
                };

                if (!registeredCompletionItems) {
                    Monaco.languages.registerCompletionItemProvider('handlebars', {
                        triggerCharacters: ['/'],
                        provideCompletionItems: (model, position, cancelToken, context):any => {
                            var textUntilPosition = model.getValueInRange({ startLineNumber: 1, startColumn: 1, endLineNumber: position.lineNumber, endColumn: position.column });
                            var tokens = Monaco.editor.tokenize(textUntilPosition, 'handlebars');
                            var token = tokens[tokens.length - 1][tokens[tokens.length - 1].length - 1];
                            var prevToken: any;
                            var prevText: any;
                            if (tokens[tokens.length - 1].length > 1) {
                                prevToken = tokens[tokens.length - 1][tokens[tokens.length - 1].length - 2];
                                prevText = model.getValueInRange({
                                    startLineNumber: position.lineNumber,
                                    startColumn: token.offset + 1,
                                    endLineNumber: position.lineNumber,
                                    endColumn: position.column
                                });
                            }
                            var completionItems: any[] = [];

                            // Add all the properties from sampledata
                            if (token.type == 'delimiter.handlebars' ||
                                (prevToken && prevToken.type == 'keyword.helper.handlebars' && token.type == '')) {
                                // insert tokens
                                if (this.props.sampleData) {
                                    Object.getOwnPropertyNames(this.props.sampleData).forEach(p => {
                                        var prop = typeof this.props.sampleData[p];
                                        completionItems.push(
                                            {
                                                label: p,
                                                kind: Monaco.languages.CompletionItemKind.Variable,
                                                detail: prop
                                            });

                                    });
                                }
                                // Insert HW built-in helpers
                                ['log', 'toJSON', 'dateformat', 'imgrendition', 'encode',
                                    'equal', 'repeat', 'timeformat', 'iconclass', 'delvePropertyValue',
                                    'userpicture', 'userProfileUrl', 'carouselClass', 'userPresence', 'trimContent',
                                    'convertToNumber', 'equalValue', 'loaderImage', 'uri', 'name', 'style'].forEach(z => {
                                        completionItems.push({
                                            label: z,
                                            kind: Monaco.languages.CompletionItemKind.Method,
                                            insertText: z + ' '
                                        });
                                    });
                            }
                            if ((token.type == '' && (prevToken && prevToken.type == 'variable.parameter.handlebars')) || (prevToken && token.type == 'variable.parameter.handlebars' && prevToken.type == 'delimiter.handlebars' && prevText != "#" && prevText != "/")) {
                                // Insert properties of the sameple object
                                if (this.props.sampleData) {
                                    Object.getOwnPropertyNames(this.props.sampleData).forEach(p => {
                                        var prop = typeof this.props.sampleData[p];
                                        completionItems.push(
                                            {
                                                label: p,
                                                kind: Monaco.languages.CompletionItemKind.Variable,
                                                detail: prop
                                            });
                                    });
                                }
                            }
                            // insert default Handlebars blocks
                            if (token.type == 'delimiter.handlebars') {
                                ['each', 'if', 'unless', 'with'].forEach(x => {
                                    completionItems.push({
                                        label: '#' + x,
                                        kind: Monaco.languages.CompletionItemKind.Keyword
                                    });
                                });
                            }
                            // insert default handlebars blocks
                            if (token.type == 'variable.parameter.handlebars' && prevText == '#') {
                                ['each', 'if', 'unless', 'with'].forEach(x => {
                                    completionItems.push({
                                        label: '#' + x,
                                        kind: Monaco.languages.CompletionItemKind.Keyword
                                    });
                                });
                            }
                            // insert default handlebar end blocks
                            if (token.type == 'variable.parameter.handlebars' && prevText == '/') {
                                ['each', 'if', 'unless', 'with'].forEach(x => {
                                    completionItems.push({
                                        label: x,
                                        kind: Monaco.languages.CompletionItemKind.Keyword
                                    });
                                });
                            }

                            return completionItems;
                        }
                    });
                    registeredCompletionItems = true;
                }

                this.editor = Monaco.editor.create(this.monacoContainer, {
                    value: this.state.customTemplate,
                    minimap: {
                        enabled: false,
                    },
                    language: 'handlebars'
                });

                this.editor.onDidChangeModelContent(e => {
                    this.setState({
                        customTemplate: this.editor.getValue()
                    }, () => {
                        this._updateSetting();
                    });
                });
            }
        });
    }
}

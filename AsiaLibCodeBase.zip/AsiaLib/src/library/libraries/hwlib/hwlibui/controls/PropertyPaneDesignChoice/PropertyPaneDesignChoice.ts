import * as React from 'react';
import * as ReactDom from 'react-dom';
import {
  IPropertyPaneField,
  PropertyPaneFieldType
} from '@microsoft/sp-property-pane';
import { PropertyPaneDesignChoiceInternalProps } from './PropertyPaneDesignChoiceInternalProps';
import { PropertyPaneDesignChoiceProps } from './PropertyPaneDesignChoiceProps';
import { IDesignChoiceProps } from './components/IDesignChoiceProps';
import DesignChoice from './components/DesignChoice';
import { IDesignChoiceSettings } from './IDesignChoiceSettings';

/**
 * Implements a custom property pane property for choosing different designs
 * NOTE: it is important to read the associated documentation with this for the Monaco editor in order to optimize the builds and not bundle the full Monaco editor
 */
export class PropertyPaneDesignChoice implements IPropertyPaneField<PropertyPaneDesignChoiceProps> {
  public type: PropertyPaneFieldType = PropertyPaneFieldType.Custom;
  public targetProperty: string;
  public properties: PropertyPaneDesignChoiceInternalProps;
  private elem: HTMLElement;

  constructor(targetProperty: string, properties: PropertyPaneDesignChoiceProps) {
    this.targetProperty = targetProperty;
    this.properties = {
      label: properties.label,
      onPropertyChange: properties.onPropertyChange,
      value: properties.value,
      disabled: properties.disabled,
      customTemplateOptionKey: properties.customTemplateOptionKey,
      templateSelectionOptionKey: properties.templateSelectionOptionKey,
      uploadSelectionOptionKey: properties.uploadSelectionOptionKey,
      enableCustomTemplates: properties.enableCustomTemplates,
      enableTemplateSelection: properties.enableTemplateSelection,
      enableUploadSelection: properties.enableUploadSelection,
      filePickerResult: properties.filePickerResult,
      templates: properties.templates,
      libraries: properties.libraries,
      options: properties.options,
      onRender: this.onRender.bind(this),
      key: properties.key,
      properties: properties.properties,
      sharedStrings: properties.sharedStrings,
      currentState: properties.value,
      sampleData: properties.sampleData,
      componentId: properties.componentId,
      context: properties.context
    };
  }

  public render(): void {
    if (!this.elem) {
      return;
    }

    this.onRender(this.elem);
  }

  private onRender(elem: HTMLElement): void {
    if (!this.elem) {
      this.elem = elem;
    }

    const element: React.ReactElement<IDesignChoiceProps> = React.createElement(DesignChoice, {
      label: this.properties.label,
      onChanged: this.onChanged.bind(this),
      value: this.properties.value,
      disabled: this.properties.disabled!,
      options: this.properties.options,
      templates: this.properties.templates,
      libraries: this.properties.libraries,
      customTemplateOptionKey: this.properties.customTemplateOptionKey,
      templateSelectionOptionKey: this.properties.templateSelectionOptionKey,
      uploadSelectionOptionKey: this.properties.uploadSelectionOptionKey!,
      enableCustomTemplates: this.properties.enableCustomTemplates!,
      enableTemplateSelection: this.properties.enableTemplateSelection!,
      enableUploadSelection: this.properties.enableUploadSelection!,
      filePickerResult: this.properties.filePickerResult,
      sharedStrings: this.properties.sharedStrings,
      sampleData: this.properties.sampleData,
      // required to allow the component to be re-rendered by calling this.render() externally
      stateKey: new Date().toString(),
      componentId: this.properties.componentId,
      context: this.properties.context!
    });
    ReactDom.render(element, elem);
  }

  private onChanged(provider: IDesignChoiceSettings, index?: number): void {
    this.properties.onPropertyChange(this.targetProperty, this.properties.currentState, provider);
    // if targetProperty is set to null, do not update the target property in the web part
    if (this.targetProperty != null) {
      this.properties.properties[this.targetProperty] = provider;
    }

    this.properties.currentState = provider;
  }
}
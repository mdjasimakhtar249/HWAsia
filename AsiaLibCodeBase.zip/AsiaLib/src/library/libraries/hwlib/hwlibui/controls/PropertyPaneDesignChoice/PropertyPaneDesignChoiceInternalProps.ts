import { IPropertyPaneCustomFieldProps } from '@microsoft/sp-property-pane';
import { PropertyPaneDesignChoiceProps } from './PropertyPaneDesignChoiceProps';
import { IDesignChoiceSettings } from './IDesignChoiceSettings';

export interface PropertyPaneDesignChoiceInternalProps extends PropertyPaneDesignChoiceProps, IPropertyPaneCustomFieldProps {
    currentState: IDesignChoiceSettings;
}
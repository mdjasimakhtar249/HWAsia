import { IDesignChoiceSettings } from "./IDesignChoiceSettings";
import { IChoiceGroupOption } from "office-ui-fabric-react/lib/components/ChoiceGroup";
import { IPropertyPaneDropdownOption } from "@microsoft/sp-property-pane";

export interface PropertyPaneDesignChoiceProps {
  label: string;
  key: string;
  value: IDesignChoiceSettings;
  options: IChoiceGroupOption[];
  customTemplateOptionKey: string;
  templateSelectionOptionKey: string;
  uploadSelectionOptionKey?: string;
  enableCustomTemplates: boolean;
  enableTemplateSelection: boolean;
  enableUploadSelection?: boolean;
  filePickerResult?: IDesignChoiceSettings;
  templates: IPropertyPaneDropdownOption[];
  libraries: IPropertyPaneDropdownOption[];
  sampleData?: any;
  disabled?: boolean;
  properties: any;
  sharedStrings: any;
  onPropertyChange: (propertyPath: string, oldValue: IDesignChoiceSettings, newValue: IDesignChoiceSettings) => void;
  componentId: string;
  context?: any;
}
import { IFilePickerResult } from '@pnp/spfx-controls-react/lib/FilePicker';

export interface IDesignChoiceSettings {
    designChoice: string;
    template?: string;
    customTemplate?: string;
    filePickerResult?: IFilePickerResult;
    handlebarUploadDefaultLibraryKey?: string | number;
    handlebarUploadDefaultLibrary: string;
    selectedLibrary: string | string[] | number;
}
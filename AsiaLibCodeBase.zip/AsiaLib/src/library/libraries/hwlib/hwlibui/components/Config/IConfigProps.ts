import { DisplayMode } from '@microsoft/sp-core-library';

export interface IConfigProps {
    displayMode: DisplayMode;
    iconText: string;
    iconName: string;
    description?: string;
    buttonLabel: string;
    configure: () => void;
}
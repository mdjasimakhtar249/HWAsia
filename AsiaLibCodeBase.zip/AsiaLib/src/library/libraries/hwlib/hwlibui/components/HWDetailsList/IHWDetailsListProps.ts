import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { IColumn, ISelection } from 'office-ui-fabric-react/lib/DetailsList';

export interface IListItem {
    Title?: string;
    Folder?: string;
    Url?: string;
    Created?: string;
    Modified?: string;
    Author?: { Title: string };
    Editor?: { Title: string };
    CreatedBy?: string;
    ModifiedBy?: string;
}
export interface IHWDetailsListProps {    
    items?: IListItem[] | undefined;
    detailsListColumns?: string[] | undefined;
    columns?: IColumn[];
    themeVariant: IReadonlyTheme | undefined;
    setKey?: string;
    layoutMode?: number;
    selection?: ISelection;
    selectionMode?: number;
    isHeaderVisible?: boolean;
    onRenderItemColumn?: (item?: any, index?: number, column?: IColumn) => React.ReactNode;
    onEventSelected?: (event: IEvent | undefined) => void;    
}

export interface IHWDetailsListState {
    items?: IListItem[] | undefined;
}
export interface IEvent {
    title: string | undefined ;
}
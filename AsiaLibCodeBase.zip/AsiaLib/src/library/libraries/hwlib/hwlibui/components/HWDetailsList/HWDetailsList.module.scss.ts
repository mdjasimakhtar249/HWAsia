
require("./HWDetailsList.module.css");
const styles = {
  root: 'root_c7ccf8a8',
  'ms-DetailsRow-cell': 'ms-DetailsRow-cell_c7ccf8a8',
  'ms-List-page': 'ms-List-page_c7ccf8a8'
};

export default styles;

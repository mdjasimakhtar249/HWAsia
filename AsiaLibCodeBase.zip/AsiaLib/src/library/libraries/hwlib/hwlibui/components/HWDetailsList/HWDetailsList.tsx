import * as React from 'react';
import { DetailsRow, IDetailsRowStyles, IDetailsListStyles } from 'office-ui-fabric-react/lib/DetailsList';
import { DetailsHeader } from 'office-ui-fabric-react/lib/components/DetailsList/DetailsHeader';
import { IDetailsHeaderStyles } from 'office-ui-fabric-react/lib/components/DetailsList/DetailsHeader.types';
import { Fabric } from 'office-ui-fabric-react/lib/Fabric';
import { DetailsList, IDetailsRowProps, IDetailsHeaderProps } from 'office-ui-fabric-react/lib/DetailsList';
import { IHWDetailsListProps, IHWDetailsListState } from './IHWDetailsListProps';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import styles from './HWDetailsList.module.scss';

export class HWDetailsList extends React.Component<IHWDetailsListProps, IHWDetailsListState> {
    public render(): JSX.Element {
        const { semanticColors }: IReadonlyTheme = this.props.themeVariant!;
        const detailsListProps: IDetailsListStyles = {
            root: [
            ],
            focusZone: [{
                background: semanticColors.listBackground
            }],
            headerWrapper: [],
            contentWrapper: []
        };
        return (
            <Fabric>
                <DetailsList className={styles["ms-List-page"]}
                    items={this.props.items!}
                    columns={this.props.columns}
                    setKey={this.props.setKey}
                    layoutMode={this.props.layoutMode}
                    selection={this.props.selection}
                    selectionMode={this.props.selectionMode}
                    onRenderDetailsHeader={this._onRenderDetailsHeader}
                    onRenderRow={this._onRenderRow}
                    isHeaderVisible={this.props.isHeaderVisible}
                    onRenderItemColumn={this.props.onRenderItemColumn}
                    styles={detailsListProps}
                />
            </Fabric>
        );
    }

    /**
     * Below code will inherit section theme to header of DetailsList
     */
    private _onRenderDetailsHeader = (props: IDetailsHeaderProps): JSX.Element => {
        const { semanticColors }: IReadonlyTheme = this.props.themeVariant!;
        const headerProps: IDetailsHeaderStyles = {
            root: [
                {
                    color: semanticColors.listText,
                    background: semanticColors.listBackground,
                }
            ],
            check: [],
            cellWrapperPadded: [],
            cellIsCheck: [],
            cellIsActionable: [],
            cellIsEmpty: [],
            cellSizer: [],
            cellSizerStart: [],
            cellSizerEnd: [],
            cellIsResizing: [],
            cellIsGroupExpander: [],
            collapseButton: [],
            checkTooltip: [],
            sizingOverlay: [],
            dropHintCircleStyle: [],
            dropHintCaretStyle: [],
            dropHintLineStyle: [],
            dropHintStyle: [],
            accessibleLabel: []
        };
        return <DetailsHeader {...props} styles={headerProps} />;
    }

    /**
     * Below code will inherit section theme to rows of DetailsList
     */
    private _onRenderRow = (props: IDetailsRowProps): JSX.Element => {
        const { semanticColors }: IReadonlyTheme = this.props.themeVariant!;
        const rowProps: IDetailsRowStyles = {
            root: [
                {
                    color: semanticColors.listText,
                    background: semanticColors.listBackground,
                    selectors: {
                        '&:hover': {
                            background: semanticColors.listBackground,
                            opacity: 1,
                        }
                    }
                }
            ],
            cell: [],
            cellUnpadded: [],
            cellPadded: [],
            checkCell: [],
            isRowHeader: [],
            isMultiline: [],
            fields: [],
            cellMeasurer: [],
            checkCover: [],
            check: [],
            cellAnimation: []
        };
        return <DetailsRow className={styles.root + ' ' + styles["ms-DetailsRow-cell"]} {...props} styles={rowProps} />;
    }
}
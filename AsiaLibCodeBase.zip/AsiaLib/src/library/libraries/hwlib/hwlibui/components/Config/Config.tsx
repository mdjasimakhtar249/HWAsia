import * as React from 'react';
import { Fabric } from 'office-ui-fabric-react';
import { DisplayMode } from '@microsoft/sp-core-library';
import { Placeholder } from '../../../../../index';
import { IConfigProps } from './IConfigProps';

export class Config extends React.Component<IConfigProps, {}> {
    public render(): JSX.Element {
        return (
            <Fabric>
                {this.props.displayMode === DisplayMode.Edit &&
                    <Placeholder
                        iconName={this.props.iconName}
                        iconText={this.props.iconText}
                        description={this.props.description!}
                        buttonLabel={this.props.buttonLabel}
                        onConfigure={this.props.configure} />
                }
                {this.props.displayMode === DisplayMode.Read &&
                    <Placeholder
                        iconName={this.props.iconName}
                        iconText={this.props.iconText}
                        description={this.props.description!}/>
                }
            </Fabric>
        );
    }
}
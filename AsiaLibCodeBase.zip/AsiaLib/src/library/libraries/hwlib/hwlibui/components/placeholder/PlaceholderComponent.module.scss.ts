
require("./PlaceholderComponent.module.css");
const styles = {
  placeholder: 'placeholder_f92fe1da',
  placeholderContainer: 'placeholderContainer_f92fe1da',
  placeholderHead: 'placeholderHead_f92fe1da',
  placeholderHeadContainer: 'placeholderHeadContainer_f92fe1da',
  placeholderIcon: 'placeholderIcon_f92fe1da',
  placeholderText: 'placeholderText_f92fe1da',
  hide: 'hide_f92fe1da',
  placeholderDescription: 'placeholderDescription_f92fe1da',
  placeholderDescriptionText: 'placeholderDescriptionText_f92fe1da',
  placeholderOverlay: 'placeholderOverlay_f92fe1da',
  placeholderSpinnerContainer: 'placeholderSpinnerContainer_f92fe1da'
};

export default styles;

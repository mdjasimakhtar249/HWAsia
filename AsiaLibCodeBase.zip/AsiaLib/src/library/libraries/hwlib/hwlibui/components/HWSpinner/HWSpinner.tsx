import * as React from 'react';
import {
  Spinner,
  SpinnerSize
} from 'office-ui-fabric-react/lib/Spinner';


export interface IHWSpinnerProps {
  label?: string;
  size?: SpinnerSize;
}
export class HWSpinner extends React.Component<IHWSpinnerProps, any> {
  public static defaultProps: Partial<IHWSpinnerProps> = {
    label: "",
    size: SpinnerSize.xSmall
  };

  public render() {
    return (
      <div>
        <Spinner size={this.props.size} label={this.props.label} />
      </div>
    );
  }
}
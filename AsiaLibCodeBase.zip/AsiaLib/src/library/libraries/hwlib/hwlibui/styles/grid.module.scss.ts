
require("./grid.module.css");
const styles = {
  hwGrid: 'hwGrid_c89eb4f3',
  hwGridRow: 'hwGridRow_c89eb4f3',
  hwGridCol: 'hwGridCol_c89eb4f3',
  'ms-Grid': 'ms-Grid_c89eb4f3',
  hwSm1: 'hwSm1_c89eb4f3',
  hwSm4: 'hwSm4_c89eb4f3',
  hwSm6: 'hwSm6_c89eb4f3',
  hwSm12: 'hwSm12_c89eb4f3',
  hwMd1: 'hwMd1_c89eb4f3',
  hwMd2: 'hwMd2_c89eb4f3',
  hwMd4: 'hwMd4_c89eb4f3',
  hwMd6: 'hwMd6_c89eb4f3',
  hwMd10: 'hwMd10_c89eb4f3',
  hwMd12: 'hwMd12_c89eb4f3',
  hwLg1: 'hwLg1_c89eb4f3',
  hwLg2: 'hwLg2_c89eb4f3',
  hwLg4: 'hwLg4_c89eb4f3',
  hwLg3: 'hwLg3_c89eb4f3',
  hwLg12: 'hwLg12_c89eb4f3'
};

export default styles;

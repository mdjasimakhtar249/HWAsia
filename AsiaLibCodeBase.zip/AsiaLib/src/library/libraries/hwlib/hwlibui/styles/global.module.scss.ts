
require("./global.module.css");
const styles = {

};

export default styles;

declare interface IHWLibUiLibraryStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HWLibUiLibraryStrings' {
  const strings: IHWLibUiLibraryStrings;
  export = strings;
}

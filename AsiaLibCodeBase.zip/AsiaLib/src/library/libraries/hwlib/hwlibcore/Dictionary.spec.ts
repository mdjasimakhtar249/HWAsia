import * as assert from 'assert';
import { Dictionary, ITypedHash } from './Dictionary';

describe('Dictionary', () => {
    it('is empty when initialized', () => {
        const dictionary = new Dictionary<any>();
        assert.equal(dictionary.count(), 0);
    });
    it('contains 1 item when 1 item is added', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item', 'value');
        assert.equal(dictionary.count(), 1);
    });
    it('added item exists in keys', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item', 'value');
        assert.equal(dictionary.getKeys().indexOf('item'), 0);
    });
    it('added item already existing ', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item', 'value');
        dictionary.add('item', 'value2');
        assert.equal(dictionary.get('item'), 'value2');
    });
    it('added item exists in dictionary', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item', 'value');
        assert.equal(dictionary.get('item'), 'value');
    });
    it('non existing key returns null', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item', 'value');
        assert.equal(dictionary.get('not-found'), null);
    });
    it('adds two item', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item1', 'value1');
        dictionary.add('item2', 'value2');
        assert.equal(dictionary.count(), 2);
    });
    it('delete item', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item1', 'value1');
        dictionary.remove('item1');
        assert.equal(dictionary.count(), 0);
    });
    it('delete non existing item', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item1', 'value1');
        let val = dictionary.remove('item2');
        assert.equal(val, null);
    });
    it('clear dictionary', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item1', 'value1');
        dictionary.clear();
        assert.equal(dictionary.count(), 0);
    });
    it('added item exists in values', () => {
        const dictionary = new Dictionary<any>();
        dictionary.add('item', 'value');
        assert.equal(dictionary.getValues().indexOf('value'), 0);
    });
    it('merge with array', () => {
        const dictionary = new Dictionary<any>();
        const arr: ITypedHash<any> = { item2: 'value2' };
        dictionary.add('item', 'value');
        dictionary.merge(arr);
        assert.equal(dictionary.count(), 2);
    });
    
});

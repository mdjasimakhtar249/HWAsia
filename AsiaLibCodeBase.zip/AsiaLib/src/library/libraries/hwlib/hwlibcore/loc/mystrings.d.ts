declare interface IHWLibCoreLibraryStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HWLibCoreLibraryStrings' {
  const strings: IHWLibCoreLibraryStrings;
  export = strings;
}

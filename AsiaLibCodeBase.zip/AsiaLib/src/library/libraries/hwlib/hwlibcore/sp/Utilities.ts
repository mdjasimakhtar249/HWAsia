export enum Intervals {
    Year,
    Quarter,
    Month,
    Week,
    Day,
    Hour,
    Minute,
    Second
}
export class Utilities {
    public static loadCss(url: string, id: string, media: string = 'all'): void {
        var found = false;
        for (var i = 0; i < document.styleSheets.length; i++) {
            if (document.styleSheets[i].href === url) {
                found = true;
                break;
            }
        }
        if (!found) {
            if (!document.getElementById(id)) {
                const head = document.getElementsByTagName('head')[0];
                const link = document.createElement('link');
                link.id = id;
                link.rel = 'stylesheet';
                link.type = 'text/css';
                link.href = url;
                link.media = media;
                head.appendChild(link);
            }
        }
    }
    public static loadScript(url: string, id: string) {
        var found = false;
        for (var i = 0; i < document.scripts.length; i++) {
            if (document.scripts[i].src === url) {
                found = true;
                break;
            }
        }
        if (!found) {
            if (!document.getElementById(id)) {
                const head = document.getElementsByTagName('head')[0];
                const script = document.createElement('script');
                script.id = id;
                script.type = 'text/javascript';
                script.src = url;
                head.appendChild(script);
            }
        }
    }
    public static addViewPort(content: string) {
        const head = document.getElementsByTagName('head')[0];
        const viewport = document.createElement('meta');
        viewport.name = 'viewport';
        viewport.content = content;
        head.appendChild(viewport);
    }
    public static ensureOfficeUiFabric(): void {
        this.loadCss('https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/1.2.0/css/fabric.min.css', 'fabric.min.css');
        this.loadCss('https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/1.2.0/css/fabric.components.min.css', 'fabric.components.min.css');
        this.loadScript('https://static2.sharepointonline.com/files/fabric/office-ui-fabric-js/1.2.0/js/fabric.min.js', 'fabric.min.js');
        this.loadCss('https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css', 'owl.carousel.min.css');
    }
    public static dateAdd(date: Date, interval: Intervals, units: number): Date | undefined {
        var ret: Date | undefined = new Date(date.toString()); //don't change original date
        switch (interval) {
            case Intervals.Year: ret.setFullYear(ret.getFullYear() + units); break;
            case Intervals.Quarter: ret.setMonth(ret.getMonth() + 3 * units); break;
            case Intervals.Month: ret.setMonth(ret.getMonth() + units); break;
            case Intervals.Week: ret.setDate(ret.getDate() + 7 * units); break;
            case Intervals.Day: ret.setDate(ret.getDate() + units); break;
            case Intervals.Hour: ret.setTime(ret.getTime() + units * 3600000); break;
            case Intervals.Minute: ret.setTime(ret.getTime() + units * 60000); break;
            case Intervals.Second: ret.setTime(ret.getTime() + units * 1000); break;
            default: ret = undefined; break;
        }
        return ret;
    }
    public static getErrorHtml(errorTitle: string, userMessage: string, adminMessage: string, isAdmin: boolean): any {
        const errorDiv = document.createElement('div');
        errorDiv.classList.add('ms-status-yellow');
        errorDiv.classList.add('ava-error');
        const spanStatus = document.createElement('span');
        errorDiv.appendChild(spanStatus);
        spanStatus.classList.add('ms-status-status');
        spanStatus.innerHTML += '<span class="ms-status-iconSpan"><img class="ms-status-iconImg" src="/_layouts/15/images/spcommon.png"></span>';
        spanStatus.innerHTML += '<span class="ms-bold ms-status-title">' + errorTitle + '</span>';
        spanStatus.innerHTML += '<span class="ms-status-body">' + userMessage + '</span>';
        if (isAdmin) {
            spanStatus.innerHTML += '<span class="ms-status-body ava-admin-message">' + adminMessage + '</span>';
        }
        return errorDiv;
    }

    public static isNumber(num: any): boolean {
        const type = typeof (num);

        if (type === 'string') {
            if (!num.trim()) {
                return false;
            }
        } else if (type !== 'number') {
            return false;
        }

        return (num - num + 1) >= 0;
    }

    public static transformItems(items: any, pagesize: number): any {
        const result: any = []; let temp: any = [];
        items.forEach((elem: any, i: any) => {
            if (i > 0 && i % pagesize === 0) {
                result.push(temp);
                temp = [];
            }
            temp.push(elem);
        });
        if (temp.length > 0) {
            result.push(temp);
        }
        return result;
    }
    public static shuffleItems(items: any): any {
        for (var c = items.length - 1; c > 0; c--) {
            const b = Math.floor(Math.random() * (c + 1));
            const a = items[c];
            items[c] = items[b];
            items[b] = a;
        }
        return items;
    }
}

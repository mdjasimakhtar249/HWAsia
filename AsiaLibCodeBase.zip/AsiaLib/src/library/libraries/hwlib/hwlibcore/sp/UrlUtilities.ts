/**
 * Misc URL utilities
 */
export class UrlUtilites {
  /*
   Returns the current site collection URL
   *"https://yourdomain.sharepoint.com/sites/DigitalHub"
   */
  public static getCurrentSiteCollectionUrl(): string {
    if (window
      && "location" in window
      && "protocol" in window.location
      && "pathname" in window.location
      && "host" in window.location) {
      let siteURL = window.location.protocol + "//" + window.location.host;
      const pathname = window.location.pathname;
      const sitesmanagedPath = "/sites/";
      const teamsmanagedPath = "/teams/";
      if (pathname.indexOf(sitesmanagedPath) >= 0) {
        if (pathname.indexOf("/", sitesmanagedPath.length) > 1) {
          siteURL += pathname.substring(0, pathname.indexOf("/", sitesmanagedPath.length));
        } else {
          siteURL += pathname;
        }
      } else {
        if (pathname.indexOf(teamsmanagedPath) >= 0) {
          if (pathname.indexOf("/", teamsmanagedPath.length) > 1) {
            siteURL += pathname.substring(0, pathname.indexOf("/", teamsmanagedPath.length));
          } else {
            siteURL += pathname;
          }
        }
      }
      return siteURL;
    }
    return '';
  }

  /*
   * Returns the Current Site Url
   *      "https://yourdomain.sharepoint.com/sites/DigitalHub/subsite/Pages/Home.aspx"
   */
  public static getCurrentAbsoluteSiteUrl(): string {
    if (window
      && "location" in window
      && "protocol" in window.location
      && "pathname" in window.location
      && "host" in window.location) {
      return window.location.protocol + "//" + window.location.host + window.location.pathname;
    }
    return '';
  }

  /*
   * Returns the Current Site relative Url
   *      "/sites/DigitalHub/Pages/Home.aspx"
   * Note: 'https://contoso.sharepoint.com/' will return an empty string
   */
  public static getWebServerRelativeUrl(): string {
    if (window
      && "location" in window
      && "pathname" in window.location) {
      return window.location.pathname.replace(/\/$/, "");
    }
    return '';
  }


  /*
   * Returns the Current Domain/root Url
   *      "https://yourdomain.sharepoint.com"
   */
  public static getAbsoluteDomainUrl(): string {
    if (window
      && "location" in window
      && "protocol" in window.location
      && "host" in window.location) {
      return window.location.protocol + "//" + window.location.host;
    }
    return '';
  }

  /*
  * Returns the Site relative Url
  *      "/sites/DigitalHub"
  */
  public static getServerRelativeUrl(): string {
    var a = UrlUtilites.getCurrentSiteCollectionUrl();
    var b = UrlUtilites.getWebServerRelativeUrl();
    if (a == null || b == null) { return ''; }
    var serverRelativeUrl = "";
    for (var i = 0; i < a.length; ++i) {
      for (var j = 0; j < b.length; ++j) {
        if (a[i] === b[j]) {
          var str = a[i];
          var k = 1;
          while (i + k < a.length && j + k < b.length
            && a[i + k] === b[j + k]) {
            str += a[i + k];
            ++k;
          }
          if (str.length > serverRelativeUrl.length) { serverRelativeUrl = str ;}
        }
      }
    }
    return serverRelativeUrl;
  }

  /**
   * Returns the value of a query string parameter, if not found returns null
   * @param name Name of the query string parameter
   * @param url an optional url, default is to use the current browser url
   */
  public static getParameterByName(name: string, url?: string): string {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) return '';
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }

}
export class SPTaxonomyHelpers {
    private isInitialized: boolean;

    constructor() {
        this.isInitialized = false;
    }
    /**
     * Load method that ensures that sp.js, sp.taxonomy.js is loaded properly
     */
    public load(): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            if (this.isInitialized) {
                resolve();
            }
            SP.SOD.executeFunc('sp.js', 'SP.ClientContext', () => {
                SP.SOD.registerSod('sp.taxonomy.js', SP.Utilities.Utility.getLayoutsPageUrl('sp.taxonomy.js'));
                SP.SOD.executeFunc('sp.taxonomy.js', 'SP.Taxonomy.TaxonomySession', () => {
                    this.isInitialized = true;
                    resolve();
                });
            });
        });
    }
}
import { SPComponentLoader } from '@microsoft/sp-loader';
import { Guid } from '@microsoft/sp-core-library';
import { Log } from '@microsoft/sp-core-library';

const LOG_SOURCE: string = "InstanceLoader";

export class InstanceLoader<T> {
    constructor() {
    }

    public getInstance<TInstance>(context: Object, name: string, ...args: any[]): TInstance {
        try {
            const instance = Object.create(context[name].prototype);
            instance.constructor.apply(instance, args);
            Log.info(LOG_SOURCE, "getInstance: " + name);
            return <TInstance>instance;
        } catch (error) {
            Log.error(LOG_SOURCE, error);
            throw new Error(`Unable to load instance '${name}'. ${error}`);
        }
    }

    public loadComponent<TComponent>(alias: string): Promise<TComponent> {
        const manifests = (<any>SPComponentLoader).getManifests().filter(m => m.alias == alias);
        if (manifests.length == 0) {
            throw `Manifest with alias '${alias}' not found`;
        }
        if (manifests.length > 1) {
            throw `Multiple manifest with alias '${alias}' found`;
        }
        return SPComponentLoader.loadComponent<TComponent>(manifests[0]);

    }

    /**
     * Dynamically instantiates a component
     * @param componentAlias This can be either a SPFx Component Alias or an SPFx component Id - using an Alias is more efficient but it assumes the component to be already loaded on the page
     * @param name Name of the instance to be created
     * @param args Arguments
     */
    public getInstanceFromComponent<TInstanceComponent>(componentAlias: string, name: string, ...args: any[]): Promise<TInstanceComponent> {
        if (Guid.isValid(componentAlias)) {
            return new Promise<TInstanceComponent>((resolve, reject) => {
                (<any>SPComponentLoader).loadComponentById(componentAlias).then((component: Object) => {
                    const instance = this.getInstance<TInstanceComponent>(component, name, ...args);
                    resolve(instance);
                }).catch(err => {
                    reject(err);
                });
            });
        } else {
            return new Promise<TInstanceComponent>((resolve, reject) => {
                this.loadComponent(componentAlias).then((context: Object) => {
                    const instance = this.getInstance<TInstanceComponent>(context, name, ...args);
                    resolve(instance);
                }).catch(err => {
                    reject(err);
                });
            });
        }
    }
}
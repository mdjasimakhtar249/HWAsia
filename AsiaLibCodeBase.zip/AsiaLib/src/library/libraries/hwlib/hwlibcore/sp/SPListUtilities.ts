import { PageContext } from "@microsoft/sp-page-context";
import { SPHttpClient } from "@microsoft/sp-http";
import { ServiceScope } from "@microsoft/sp-core-library";

export class SPListUtilities {
    /**
     * Returns the last modified date for a list
     * @param serviceScope service scope
     * @param pageContext page context
     * @param listName name of list
     */
    public static getListLastModifiedTime(serviceScope: ServiceScope, pageContext: PageContext, listName: string): Promise<Date> {
        const client = new SPHttpClient(serviceScope as any);
        return new Promise<Date>((resolve, reject) => {
            client.get(`${pageContext.web.absoluteUrl}/_api/web/lists/GetByTitle('${listName}')/LastModifiedDate`,
                SPHttpClient.configurations.v1).then(response => {
                    response.text().then(data => {
                        resolve(new Date(data));
                    }).catch(err => {
                        reject(err);
                    });
                }).catch(err => {
                    reject(err);
                });
        });
    }
}
import { ServiceKey, ServiceScope } from '@microsoft/sp-core-library';
import { SPHttpClient, HttpClient, IHttpClientOptions, HttpClientResponse, ISPHttpClientConfigurations } from '@microsoft/sp-http';
import { Promise } from 'es6-promise';
import { Log } from '@microsoft/sp-core-library';

interface IMicroserviceDetails {
    token: string;
    tokenExpiry: Date;
    payload: string;
    url: string;
}

export interface IHWSPHomeHttpClient {
    get(url: string): Promise<HttpClientResponse>;
    post(url: string, body: string): Promise<HttpClientResponse>;
}

const LOG_SOURCE: string = "HWSPHomeHttpClient";

export class HWSPHomeHttpClient implements IHWSPHomeHttpClient {

   // static readonly configurations: ISPHttpClientConfigurations;

    //static readonly serviceKey: ServiceKey<HWSPHomeHttpClient>;
    private spHttpClient: SPHttpClient;
    private httpClient: HttpClient;
    private tokenExpiry: Date;
    private microserviceDetails: IMicroserviceDetails;

    constructor(private serviceScope: ServiceScope) {
        this.serviceScope.whenFinished(() => {
            this.spHttpClient = new SPHttpClient(this.serviceScope as any);
            this.httpClient = new HttpClient (this.serviceScope as any);
        });
    }

    // example: sites/feed?start=" + e + "&count=" + t + "&acronyms=" + r
    // sites/recent?start=" + e + "&count=" + t + "&acronyms=" + r
    // sites/hub/feed?departmentId=" + e + "&acronyms=true&start=" + t
    // sites/followed?mostRecentFirst=true&fillSiteData=false&start=" + e + "&count=" + t
    public get(url: string): Promise<HttpClientResponse> {
        return this.fetchTokenIfExpired().then(() => {
            Log.info(LOG_SOURCE, "HWSPHomeHttpClient: get", this.serviceScope);
            return this.httpClient.get(this.generateUrl(url), HttpClient.configurations.v1, this.getRequestOptions());
        }).catch(err => {
            throw err;
        });
    }

    // activities?count=" + t
    // sites/followed/add
    // sites/followed/remove
    public post(url: string, body: string): Promise<HttpClientResponse> {
        return this.fetchTokenIfExpired().then((() => {
            Log.info(LOG_SOURCE, "HWSPHomeHttpClient: post", this.serviceScope);
            return this.httpClient.post(this.generateUrl(url), HttpClient.configurations.v1, this.getRequestOptions({
                body: body
            }));
        }
        ));
    }
    private fetchTokenIfExpired(): Promise<void> {
        return new Promise((resolve, reject) => {
            if (this.isTokenValid()) {
                resolve();
            } else {
                this.getTokenAndMicroserviceDetails().then(x => {
                    resolve();
                });
            }
        });
    }
    private isTokenValid() {
        return this.tokenExpiry && this.tokenExpiry > new Date;
    }

    private getTokenAndMicroserviceDetails(): Promise<IMicroserviceDetails> {
        return new Promise<IMicroserviceDetails>((resolve, reject) => {
            this.spHttpClient.get("/_api/sphomeservice/context?$expand=Token,Payload", SPHttpClient.configurations.v1).then(response => {
                response.json().then((json) => {
                    if (!json.Token || !json.Token.access_token) {
                        throw "Invalid token";
                    }
                    this.microserviceDetails = {
                        token: json.Token.access_token,
                        tokenExpiry: new Date(1e3 * Number(json.Token.expires_on)),
                        payload: json.Payload,
                        url: json.Urls[0]
                    };

                    resolve(this.microserviceDetails);
                });
            });
        });
    }
    private getRequestOptions(options?: IHttpClientOptions): IHttpClientOptions {
        let objOptions: any, headers: any = { headers: new Headers() };
        if (this.microserviceDetails) {
            if (!options) {
                options = {};
            }
            if (!options.headers) {
                options.headers = headers;
            }
            objOptions = options.headers;
            objOptions.headers.append('Authorization', `Bearer ${this.microserviceDetails.token}`);
            objOptions.headers.append('SPHome-ApiContext', this.microserviceDetails.payload);
            objOptions.headers.append('Content-Type', 'application/json');
            objOptions.headers.append('SPHome-ClientType', 'PagesWeb');
            return objOptions;
        } else {
            return {};
        }
    }
    private generateUrl(url: string): string {
        let result = `${this.microserviceDetails.url}/api/v1/${url}`;
        return result;
    }

    public static ServiceKey = ServiceKey.create("HW:HWSPHomeHttpClient", HWSPHomeHttpClient);
}
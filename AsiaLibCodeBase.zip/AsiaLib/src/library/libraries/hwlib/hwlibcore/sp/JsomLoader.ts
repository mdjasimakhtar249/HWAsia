import { SPComponentLoader } from '@microsoft/sp-loader';

export class JsomLoader {
    /**
     * Loads the following default SharePoint scripts
     * - init.js
     * - MicrosoftAjax.js
     * - SP.Runtime.js
     * - SP.js
     */
    public static LoadJsom(): Promise<{}> {
        return SPComponentLoader.loadScript('/_layouts/15/init.js', {
            globalExportsName: '$_global_init'
        })
            .then((): Promise<{}> => {
                return SPComponentLoader.loadScript('/_layouts/15/MicrosoftAjax.js', {
                    globalExportsName: 'Sys'
                });
            })
            .then((): Promise<{}> => {
                return SPComponentLoader.loadScript('/_layouts/15/SP.Runtime.js', {
                    globalExportsName: 'SP'
                });
            })
            .then((): Promise<{}> => {
                return SPComponentLoader.loadScript('/_layouts/15/SP.js', {
                    globalExportsName: 'SP'
                });
            });
    }

    /**
     * Loads additional JSOM scripts. Should be chained after the LoadJsom() method
     * @param script Script in the format of '/_layouts/15/SP.taxonomy.js'
     * @param globalExportsName The global exports name, for instance 'SP'
     */
    public static LoadAdditionalJsomScript(script: string, globalExportsName: string): Promise<{}> {
        return SPComponentLoader.loadScript(script, {
            globalExportsName: globalExportsName
        });
    }
}
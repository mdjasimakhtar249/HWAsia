/// <reference types="node"/>
import { UrlUtilites } from './UrlUtilities';
import { expect } from 'chai';
import jsdom from 'jsdom-global';

describe('UrlUtilities', () => {
    it('create UrlUtilites class', () => {
        expect(new UrlUtilites()).to.be.an.instanceof(UrlUtilites);
    });
    describe('Root site (without slash)', () => {
        before(() => {
            jsdom(undefined, {
                url: "https://contoso.sharepoint.com"
            });
        });

        it('getAbsoluteDomainUrl', () => {
            expect(UrlUtilites.getAbsoluteDomainUrl()).to.be.equal('https://contoso.sharepoint.com');
        });
        it('getWebServerRelativeUrl', () => {
            expect(UrlUtilites.getWebServerRelativeUrl()).to.be.equal('');
        });
        it('getServerRelativeUrl', () => {
            expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('');
        });
        it('getCurrentAbsoluteSiteUrl', () => {
            expect(UrlUtilites.getCurrentAbsoluteSiteUrl()).to.be.equal('https://contoso.sharepoint.com/');
        });
    });
    describe('Root site (with slash)', () => {
        before(() => {
            jsdom(undefined, {
                url: "https://contoso.sharepoint.com/"
            });
        });

        it('getAbsoluteDomainUrl', () => {
            expect(UrlUtilites.getAbsoluteDomainUrl()).to.be.equal('https://contoso.sharepoint.com');
        });
        it('getWebServerRelativeUrl', () => {
            expect(UrlUtilites.getWebServerRelativeUrl()).to.be.equal('');
        });
        it('getServerRelativeUrl', () => {
            expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('');
        });
        it('getCurrentAbsoluteSiteUrl', () => {
            expect(UrlUtilites.getCurrentAbsoluteSiteUrl()).to.be.equal('https://contoso.sharepoint.com/');
        });

    });

    describe('Site Pages (sites)', () => {
        before(() => {
            jsdom(undefined, {
                url: "https://contoso.sharepoint.com/sites/site/SitePages/Home.aspx?param1=value1"
            });
        });
        it('getAbsoluteDomainUrl', () => {
            expect(UrlUtilites.getAbsoluteDomainUrl()).to.be.equal('https://contoso.sharepoint.com');
        });
        it('getWebServerRelativeUrl', () => {
            expect(UrlUtilites.getWebServerRelativeUrl()).to.be.equal('/sites/site/SitePages/Home.aspx');
        });
        it('getServerRelativeUrl', () => {
            expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/sites/site');
        });
        it('getCurrentAbsoluteSiteUrl', () => {
            expect(UrlUtilites.getCurrentAbsoluteSiteUrl()).to.be.equal('https://contoso.sharepoint.com/sites/site/SitePages/Home.aspx');
        });
        describe('Sub site', () => {
            before(() => {
                jsdom(undefined, {
                    url: "https://contoso.sharepoint.com/sites/site/subsite/SitePages/Home.aspx?param1=value1"
                });
            });
            it('getServerRelativeUrl', () => {
                expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/sites/site');
            });
        });
        describe('Site collection root', () => {
            before(() => {
                jsdom(undefined, {
                    url: "https://contoso.sharepoint.com/sites/site"
                });
            });
            it('getServerRelativeUrl', () => {
                expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/sites/site');
            });
        });
    });
    describe('Site Pages (teams)', () => {
        before(() => {
            jsdom(undefined, {
                url: "https://contoso.sharepoint.com/teams/site/SitePages/Home.aspx?param1=value1"
            });
        });
        it('getAbsoluteDomainUrl', () => {
            expect(UrlUtilites.getAbsoluteDomainUrl()).to.be.equal('https://contoso.sharepoint.com');
        });
        it('getWebServerRelativeUrl', () => {
            expect(UrlUtilites.getWebServerRelativeUrl()).to.be.equal('/teams/site/SitePages/Home.aspx');
        });
        it('getServerRelativeUrl', () => {
            expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/teams/site');
        });
        it('getCurrentAbsoluteSiteUrl', () => {
            expect(UrlUtilites.getCurrentAbsoluteSiteUrl()).to.be.equal('https://contoso.sharepoint.com/teams/site/SitePages/Home.aspx');
        });
        describe('Sub site', () => {
            before(() => {
                jsdom(undefined, {
                    url: "https://contoso.sharepoint.com/teams/site/subsite/SitePages/Home.aspx?param1=value1"
                });
            });
            it('getServerRelativeUrl', () => {
                expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/teams/site');
            });
        });
        describe('Site collection root', () => {
            before(() => {
                jsdom(undefined, {
                    url: "https://contoso.sharepoint.com/teams/site"
                });
            });
            it('getServerRelativeUrl', () => {
                expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/teams/site');
            });
        });
    });
    describe('Layouts page', () => {
        before(() => {
            jsdom(undefined, {
                url: "https://contoso.sharepoint.com/sites/site/_layouts/settings.aspx?param1=value1"
            });
        });
        it('getAbsoluteDomainUrl', () => {
            expect(UrlUtilites.getAbsoluteDomainUrl()).to.be.equal('https://contoso.sharepoint.com');
        });
        it('getWebServerRelativeUrl', () => {
            expect(UrlUtilites.getWebServerRelativeUrl()).to.be.equal('/sites/site/_layouts/settings.aspx');
        });
        it('getServerRelativeUrl', () => {
            expect(UrlUtilites.getServerRelativeUrl()).to.be.equal('/sites/site');
        });
        it('getCurrentAbsoluteSiteUrl', () => {
            expect(UrlUtilites.getCurrentAbsoluteSiteUrl()).to.be.equal('https://contoso.sharepoint.com/sites/site/_layouts/settings.aspx');
        });
    });
    describe('window is undefined', () => {
        before(() => {             
            window = <any> undefined  ;          
        });
        it('getAbsoluteDomainUrl', () => {            
            expect(UrlUtilites.getAbsoluteDomainUrl()).to.be.empty('');          
        });
        it('getWebServerRelativeUrl', () => {            
            expect(UrlUtilites.getWebServerRelativeUrl()).to.be.empty('');
        });
        it('getServerRelativeUrl', () => {            
            expect(UrlUtilites.getServerRelativeUrl()).to.be.empty('');
        });
        it('getCurrentAbsoluteSiteUrl', () => {            
            expect(UrlUtilites.getCurrentAbsoluteSiteUrl()).to.be.empty('');
        });
    });
    describe('getParameterByName', () => {
        before(() => {
            jsdom(undefined, {
                url: "https://contoso.sharepoint.com/sites/site/_layouts/settings.aspx?param1=value1&param2"
            });
        });
        it('should return value of the parameter', () => {
            expect(UrlUtilites.getParameterByName('param1')).to.be.equal('value1');
        });
        it('should return empty string of the parameter, if it has no value', () => {
            expect(UrlUtilites.getParameterByName('param2')).to.be.equal('');
        });
        it('should return empty  if the query string parameter does not exist', () => {
            expect(UrlUtilites.getParameterByName('param3')).to.be.empty('');
        });
    });
    describe('getParameterByName, with specific url', () => {
        it('should return value of the parameter', () => {
            expect(UrlUtilites.getParameterByName('param1',"https://contoso.sharepoint.com/sites/site/_layouts/settings.aspx?param1=value1&param2")).to.be.equal('value1');
        });
        it('should return empty string of the parameter, if it has no value', () => {
            expect(UrlUtilites.getParameterByName('param2',"https://contoso.sharepoint.com/sites/site/_layouts/settings.aspx?param1=value1&param2")).to.be.equal('');
        });
        it('should return empty  if the query string parameter does not exist', () => {
            expect(UrlUtilites.getParameterByName('param3',"https://contoso.sharepoint.com/sites/site/_layouts/settings.aspx?param1=value1&param2")).to.be.empty('');
        });
    });

});
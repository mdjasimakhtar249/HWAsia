export enum DeviceName {
    MobilePortrait,
    MobileLandscape,
    TabletPortrait,
    TabletLandscape,
    Desktop
}

/**
 * Misc Browser utilities
 */
export class BrowserUtilities {


    /**
     * Returns true if the web page is hosted in Microsoft Teams
     */
    public static isTeamsWebView(): boolean {
        return /Teams\/((?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+)).* Electron\/((?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+))/.test(navigator.userAgent) ||
            /[?&]env=TeamsWebView/.test(location.search);
    }

    /**
     * Returns true if in mobile view
     */
    public static isMobileWebView(): boolean {
        return /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/.test(navigator.userAgent) ||
            /(Android ).*; wv/.test(navigator.userAgent) ||
            /(Android ).* Version\/((?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+))/.test(navigator.userAgent) ||
            /(Windows ).*; WebView\/((?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+))/.test(navigator.userAgent) ||
            /(Windows ).*; MSAppHost\/((?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+))/.test(navigator.userAgent) ||
            /[?&]env=MobileWebView/.test(location.search);
    }

    /**
     * Returns true if embedded
     */
    public static isEmbedded(): boolean {
        if (BrowserUtilities.isWebViewHosted())
            return true;
        else {
            try {
                return window.parent && window.parent !== window && -1 === navigator.userAgent.indexOf("PhantomJS/") ||
                    /[?&]env=Embedded/.test(location.search);
            } catch (t) {
                return true;
            }
        }
    }

    /**
     * Returns true if it's hosted in another environment
     */
    public static isWebViewHosted(): boolean {
        return BrowserUtilities.isMobileWebView() || BrowserUtilities.isTeamsWebView() || /[?&]env=WebView/.test(location.search);
    }

    /**
     * Returns resolution parameter based on window width.
     */
    public static getResolutionBasedOnDevice(): DeviceName {
        let width = window.innerWidth;
        if (width <= 300)
            return DeviceName.MobilePortrait;
        else if (width > 300 && width <= 480)
            return DeviceName.MobileLandscape;
        else if (width > 480 && width <= 750)
            return DeviceName.TabletPortrait;
        else if (width > 750 && width <= 1024)
            return DeviceName.TabletLandscape;
        else
            return DeviceName.Desktop;
    }
}
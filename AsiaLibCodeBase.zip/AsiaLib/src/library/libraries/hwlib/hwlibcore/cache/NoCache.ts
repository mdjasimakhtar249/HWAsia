import { ICache } from './ICache';
/**
 * Cache that does not do caching :)
 */
export class NoCache implements ICache {
    public add(key: string, item: any, expiration?: Date): void {
        return;
    }
    public delete(key: string): void {
        return;
    }
    public exists(key: string): boolean {
        return false;
    }
    public get(key: string): any {
        return null;
    }
}
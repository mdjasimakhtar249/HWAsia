/// <reference types="node"/>
import * as assert from 'assert';
import { NoCache } from './NoCache';

describe('NoCache', () => {
    it('add item without expiration', () => {
        const c = new NoCache();
        c.add('item', 'value');
        assert.equal(c.exists('item'), false);
    });
    it('add item with expiration', () => {
        const c = new NoCache();
        const d = new Date(Date.now() + 100);
        c.add('item', 'value', d);
        assert.equal(c.exists('item'), false);
    });
    it('add item with expired expiration', () => {
        const c = new NoCache();
        const d = new Date(Date.now() - 100);
        c.add('item', 'value', d);
        assert.equal(c.exists('item'), false);
    });
    it('delete item', () => {
        const c = new NoCache();
        c.delete('item');
        assert.equal(c.exists('item'), false);
    });
    it('get item', () => {
        const c = new NoCache();
        const item = c.get('item');
        assert.equal(item, null);
    });
});

import { ICache } from './ICache';

const noLocalStorageSupport: string = 'LocalStorageCache: no local storage support';
const expirationSuffix: string = '.expire';

/**
 * Base class for browser based Storage cache
 */
export class BrowserStorageCache implements ICache {
    public cache: Storage | undefined;
    public constructor() {
        this.cache = undefined;
    }
    public add(key: string, value: any, expiration?: Date): void {
        if (typeof (Storage) !== 'undefined') {
            if (!this.cache) {
                throw new Error('Cache not defined');
            }
            this.cache.setItem(key, value);
            if (expiration !== undefined) {
                this.cache.setItem(key + expirationSuffix, expiration.toString());
            }
        } else {
            console.log(noLocalStorageSupport);
        }
    }
    public delete(key: string): void {
        if (typeof (Storage) !== 'undefined') {
            if (!this.cache) {
                throw new Error('Cache not defined');
            }
            this.cache.removeItem(key);
            this.cache.removeItem(key + expirationSuffix);
        } else {
            console.log(noLocalStorageSupport);
        }
    }
    public exists(key: string): boolean {
        if (typeof (Storage) !== 'undefined') {
            if (!this.cache) {
                throw new Error('Cache not defined');
            }
            const val = this.cache.getItem(key + expirationSuffix);
            if (val !== null) {
                const expiration = new Date(val);
                if (expiration === null || expiration > new Date()) {
                    if (this.cache.getItem(key) !== null) {
                        return true;
                    }
                } else {
                    this.delete(key);
                }
            } else {
                if (this.cache.getItem(key) !== null) {
                    return true;
                }
            }
        } else {
            console.log(noLocalStorageSupport);
        }
        return false;
    }
    public get(key: string): any {
        if (typeof (Storage) !== 'undefined') {
            if (!this.cache) {
                throw new Error('Cache not defined');
            }
            const val = this.cache.getItem(key + expirationSuffix);
            if (val !== null) {
                const expiration = new Date(val);
                if (expiration === null || expiration > new Date()) {
                    return this.cache.getItem(key);
                } else {
                    this.delete(key);
                }
            } else {
                return this.cache.getItem(key);
            }
        } else {
            console.log(noLocalStorageSupport);
        }
        return null;
    }
}
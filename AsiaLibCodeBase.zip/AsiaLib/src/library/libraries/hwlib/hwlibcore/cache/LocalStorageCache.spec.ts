/// <reference types="node"/>
import * as assert from 'assert';
import { LocalStorageCache } from './LocalStorageCache';

describe('LocalStorageCache', () => {
    it('create cache', () => {
        (<any>window).localStorage = {};
        const cache = new LocalStorageCache();
        assert.notEqual(cache, undefined);
    });
    
});

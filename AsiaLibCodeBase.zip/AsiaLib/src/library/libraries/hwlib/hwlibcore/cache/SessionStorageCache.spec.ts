/// <reference types="node"/>
import * as assert from 'assert';
import { SessionStorageCache } from './SessionStorageCache';

describe('SessionStorageCache', () => {
    it('create cache', () => {
        (<any>window).sessionStorage = {};
        const cache = new SessionStorageCache();
        assert.notEqual(cache, undefined);
    });

});

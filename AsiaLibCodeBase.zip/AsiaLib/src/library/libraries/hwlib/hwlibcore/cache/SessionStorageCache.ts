import { BrowserStorageCache } from './BrowserStorageCache';
/**
 * Cache that uses window.sessionStorage
 */
export class SessionStorageCache extends BrowserStorageCache {
    public cache: Storage;
    constructor() {
        super();
        this.cache = window.sessionStorage;
    }
}
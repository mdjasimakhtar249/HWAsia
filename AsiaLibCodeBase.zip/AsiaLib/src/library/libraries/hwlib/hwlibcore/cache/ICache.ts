
/**
 * Interface for implementing caching
 */
export interface ICache {
    /**
     * add an item to a cache
     * @param {string} key - key of cache item
     * @param {any} item - item to cachep
     * @param {Date} expiration - optional parameter for when the item expires
     * @returns {void}
     */
    add(key: string, item: any, expiration?: Date): void;
    /**
     * delete an item from the cache
     * @param {string} key - key of cache item
     * @return {void}
     */
    delete(key: string): void;
    /**
     * checks if an item exists in the cache
     * @param {string} key - key of cache item
     * @returns {boolean} true if the item with the key exists
     */
    exists(key: string): boolean;
    /**
     * retrieves an item from the cache
     * @param {string} key - key of cache item
     * @returns {any} the item
     */
    get(key: string): any;
}
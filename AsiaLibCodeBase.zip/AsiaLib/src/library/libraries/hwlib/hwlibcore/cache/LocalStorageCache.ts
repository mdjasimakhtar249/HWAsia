import { BrowserStorageCache } from './BrowserStorageCache';
/**
 * Cache that uses window.localStorage
 */
export class LocalStorageCache extends BrowserStorageCache {
    public cache: Storage;
    constructor() {
        super();
        this.cache = window.localStorage;
    }
}
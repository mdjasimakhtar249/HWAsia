/// <reference types="node"/>
import * as assert from 'assert';
import { BrowserStorageCache } from './BrowserStorageCache';

// Storage Mock
function storageMock() {
    var storage = {};

    return {
        setItem: (key: string | number, value: string) => {
            storage[key] = value || '';
        },
        getItem: (key: any) => {
            return key in storage ? storage[key] : null;
        },
        removeItem: (key: any) => {
            delete storage[key];
        },
        get length() {
            return Object.keys(storage).length;
        },
        key: (i: any) => {
            var keys = Object.keys(storage);
            return keys[i] || null;
        },
        clear: () => {
            storage = {};
        }
    };
}
declare var global;
describe('BrowserStorageCache', () => {
    let cache: BrowserStorageCache;
    beforeEach(() => {
        cache = new BrowserStorageCache();
        cache.cache = storageMock();
        (<any>global).Storage = {};
    });
    it('create cache without any storage', () => {
        (<any>global).Storage = undefined;
        cache = new BrowserStorageCache();
    });
    it('add item without expiration', () => {
        cache.add('item', 'value');
        if (cache.cache)
            assert.equal(cache.cache.getItem('item'), 'value');
    });
    it('add item without expiration, and no defined cache', () => {
        cache = new BrowserStorageCache();
        assert.throws(() => { cache.add('item', 'value'); }, Error, 'Cache not defined');
    });
    it('add item without expiration, should not add expiration item', () => {
        cache.add('item', 'value');
        if (cache.cache)
            assert.equal(cache.cache.length, 1);
    });
    it('add item with expiration', () => {
        const exp = new Date(Date.now() + 1000);
        cache.add('item', 'value', exp);
        if (cache.cache)
            assert.equal(cache.cache.getItem('item'), 'value');
    });
    it('add item with expiration, should add expiration item', () => {
        const exp = new Date(Date.now() + 1000);
        cache.add('item', 'value', exp);
        if (cache.cache)
            assert.equal(cache.cache.length, 2);
    });
    it('add item without storage support', () => {
        (<any>global).Storage = undefined;
        cache = new BrowserStorageCache();
        cache.add('item', 'value');
        assert.equal(cache.cache, undefined);
    });
    it('delete item without expiration', () => {
        cache.add('item', 'value');
        cache.delete('item');
        if (cache.cache)
            assert.equal(cache.cache.length, 0);
    });
    it('delete item with expiration', () => {
        const exp = new Date(Date.now() + 1000);
        cache.add('item', 'value', exp);
        cache.delete('item');
        if (cache.cache)
            assert.equal(cache.cache.length, 0);
    });
    it('delete item with expired expiration', () => {
        const exp = new Date(Date.now() - 1000);
        cache.add('item', 'value', exp);
        cache.delete('item');
        if (cache.cache)
            assert.equal(cache.cache.length, 0);
    });
    it('delete cache without any storage support', () => {
        (<any>global).Storage = undefined;
        cache = new BrowserStorageCache();
        cache.delete('item');
    });
    it('delete item, and no defined cache', () => {
        cache = new BrowserStorageCache();
        assert.throws(() => { cache.delete('item'); }, Error, 'Cache not defined');
    });
    it('get item without any storage support', () => {
        (<any>global).Storage = undefined;
        cache = new BrowserStorageCache();
        const i = cache.get('item');
        assert.equal(i, null);
    });
    it('get item without expiration', () => {
        cache.add('item', 'value');
        const i = cache.get('item');
        assert.equal(i, 'value');
    });
    it('get item with expiration', () => {
        const exp = new Date(Date.now() + 1000);
        cache.add('item', 'value', exp);
        const i = cache.get('item');
        assert.equal(i, 'value');
    });
    it('get item with expired expiration', () => {
        const exp = new Date(Date.now() - 1000);
        cache.add('item', 'value', exp);
        const i = cache.get('item');
        assert.equal(i, null);
    });
    it('get item, and no defined cache', () => {
        cache = new BrowserStorageCache();
        assert.throws(() => { cache.get('item'); }, Error, 'Cache not defined');
    });
    it('item exists without expiration', () => {
        cache.add('item', 'value');
        assert.equal(cache.exists('item'), true);
    });
    it('item exists with expiration', () => {
        const exp = new Date(Date.now() + 1000);
        cache.add('item', 'value', exp);
        assert.equal(cache.exists('item'), true);
    });
    it('item exists with expired expiration', () => {
        const exp = new Date(Date.now() - 1000);
        cache.add('item', 'value', exp);
        assert.equal(cache.exists('item'), false);
    });
    it('exists item, and no defined cache', () => {
        cache = new BrowserStorageCache();
        assert.throws(() => { cache.exists('item'); }, Error, 'Cache not defined');
    });
    it('item exists without any storage support', () => {
        (<any>global).Storage = undefined;
        cache = new BrowserStorageCache();
        assert.equal(cache.exists('item'), false);
    });
});

export class HwlibLibrary {
  public name(): string {
    return 'HwlibLibrary';
  }
}

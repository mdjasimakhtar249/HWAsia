declare interface IHwlibLibraryStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HwlibLibraryStrings' {
  const strings: IHwlibLibraryStrings;
  export = strings;
}

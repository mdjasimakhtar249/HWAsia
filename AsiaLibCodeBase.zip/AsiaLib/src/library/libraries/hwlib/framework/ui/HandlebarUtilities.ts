import { Utilities } from "../../hwlibcore/sp/Utilities";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import * as moment from "moment-mini";

// Utility class for Handlebars stuff
export default class HandlebarUtilities {
  public static registerHelpers(handlebars: any): void {
    if (handlebars.deejsHelpersRegistered) {
      return;
    }

    handlebars.registerHelper(
      "dateformat",
      HandlebarUtilities.formatDateHelper
    );
    handlebars.registerHelper(
      "getStringPart",
      HandlebarUtilities.getStringPartHelper
    );
    handlebars.registerHelper("getTags", HandlebarUtilities.getTagsHelper);
    handlebars.registerHelper(
      "imgrendition",
      HandlebarUtilities.imageRenditionHelper
    );
    handlebars.registerHelper("encode", (obj: any) => {
      return encodeURIComponent(obj.get_uri());
    });
    handlebars.registerHelper("equal", HandlebarUtilities.registerEqualHelper);
    handlebars.registerHelper("repeat", HandlebarUtilities.repeatHelper);
    handlebars.registerHelper(
      "timeformat",
      HandlebarUtilities.formatTimeHelper
    );
    handlebars.registerHelper("iconclass", HandlebarUtilities.iconClassHelper);
    handlebars.registerHelper(
      "delvePropertyValue",
      HandlebarUtilities.delvePropertyValueHelper
    );
    handlebars.registerHelper(
      "userpicture",
      HandlebarUtilities.userPictureHelper
    );
    handlebars.registerHelper(
      "userProfileUrl",
      HandlebarUtilities.userProfileUrlHelper
    );
    handlebars.registerHelper(
      "carouselClass",
      HandlebarUtilities.carouselClassHelper
    );
    handlebars.registerHelper(
      "userPresence",
      HandlebarUtilities.userPresenceHelper
    );
    handlebars.registerHelper(
      "trimContent",
      HandlebarUtilities.trimContentHelper
    );
    handlebars.registerHelper(
      "convertToNumber",
      HandlebarUtilities.convertToNumberHelper
    );
    handlebars.registerHelper(
      "equalValue",
      HandlebarUtilities.registerEqualValueHelper
    );
    handlebars.registerHelper(
      "loaderImage",
      HandlebarUtilities.loaderImageHelper
    );
    handlebars.registerHelper("toJSON", HandlebarUtilities.toJSON);
    handlebars.registerHelper(
      "parseJSONString",
      HandlebarUtilities.parseJSONString
    );
    handlebars.registerHelper(
      "isMemberOf",
      HandlebarUtilities.isMemberOfHelper
    );
    handlebars.registerHelper(
      "createArray",
      HandlebarUtilities.createArrayHelper
    );
    handlebars.registerHelper({
      eq: (v1: any, v2: any) => v1 === v2,
      ne: (v1: any, v2: any) => v1 !== v2, // not there
      lt: (v1: any, v2: any) => v1 < v2,
      gt: (v1: any, v2: any) => v1 > v2,
      lte: (v1: any, v2: any) => v1 <= v2,
      gte: (v1: any, v2: any) => v1 >= v2,
      and() {
        return Array.prototype.every.call(arguments, Boolean);
      },
      or() {
        return Array.prototype.slice.call(arguments, 0, -1).some(Boolean);
      },
    });
    handlebars.deejsHelpersRegistered = true;
  }

  public static loaderImageHelper(): string {
    return "data:image/gif;base64,R0lGODlhEAALAPQAAP///8DAwPb29vPz8/r6+sLCwsDAwMzMzODg4NjY2O7u7snJydLS0uLi4tnZ2e/v78rKysHBwdPT0/n5+fX19fz8/M7Ozvb29vz8/O3t7ejo6PLy8vv7+8DAwMDAwMDAwCH5BAkLAAAAIf4aQ3JlYXRlZCB3aXRoIGFqYXhsb2FkLmluZm8AIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAEAALAAAFLSAgjmRpnqSgCuLKAq5AEIM4zDVw03ve27ifDgfkEYe04kDIDC5zrtYKRa2WQgAh+QQJCwAAACwAAAAAEAALAAAFJGBhGAVgnqhpHIeRvsDawqns0qeN5+y967tYLyicBYE7EYkYAgAh+QQJCwAAACwAAAAAEAALAAAFNiAgjothLOOIJAkiGgxjpGKiKMkbz7SN6zIawJcDwIK9W/HISxGBzdHTuBNOmcJVCyoUlk7CEAAh+QQJCwAAACwAAAAAEAALAAAFNSAgjqQIRRFUAo3jNGIkSdHqPI8Tz3V55zuaDacDyIQ+YrBH+hWPzJFzOQQaeavWi7oqnVIhACH5BAkLAAAALAAAAAAQAAsAAAUyICCOZGme1rJY5kRRk7hI0mJSVUXJtF3iOl7tltsBZsNfUegjAY3I5sgFY55KqdX1GgIAIfkECQsAAAAsAAAAABAACwAABTcgII5kaZ4kcV2EqLJipmnZhWGXaOOitm2aXQ4g7P2Ct2ER4AMul00kj5g0Al8tADY2y6C+4FIIACH5BAkLAAAALAAAAAAQAAsAAAUvICCOZGme5ERRk6iy7qpyHCVStA3gNa/7txxwlwv2isSacYUc+l4tADQGQ1mvpBAAIfkECQsAAAAsAAAAABAACwAABS8gII5kaZ7kRFGTqLLuqnIcJVK0DeA1r/u3HHCXC/aKxJpxhRz6Xi0ANAZDWa+kEAA7";
  }

  public static toJSON(data: any, space: number = 3): string {
    return JSON.stringify(
      data,
      (key, value) => {
        if (typeof value == "function" || key == "serviceScope") {
          return undefined;
        }
        return value;
      },
      space
    );
  }

  public static parseJSONString(data: any): any {
    return JSON.parse(data, (key, value) => {
      if (typeof value == "function" || key == "serviceScope") {
        return undefined;
      }
      return value;
    });
  }

  public static registerEqualHelper(
    lvalue: string,
    rvalue: string,
    options: any
  ): string {
    if (arguments.length < 3) {
      throw new Error("Handlebars Helper equal needs 2 parameters");
    }
    if (lvalue !== rvalue) {
      return options.inverse(this);
    } else {
      return options.fn(this);
    }
  }

  public static formatDateHelper(obj: string, dateFormat: string): string {
    if (obj === undefined || obj === null || obj.length === 0) {
      return "";
    }
    if (typeof dateFormat === "object") {
      dateFormat = "MM/dd/yyyy";
    }
    return moment(obj).format(dateFormat);
  }

  public static getStringPartHelper(
    obj: any,
    separator: string,
    index: number
  ): string {
    separator = separator.trim();
    let value = obj.split(separator);
    return value[index];
  }
  public static getTagsHelper(obj: string): [] {
    let value = obj.split(";");
    let tagName: any = [];
    value.map((element) => {
      let tag = element.split("|");
      tagName.push(tag[2]);
    });
    return tagName;
  }
  public static imageRenditionHelper(
    obj: string,
    height: number = 32,
    width: number = 32
  ): string {
    var img: string = "";
    if (obj !== undefined && obj !== null && obj.length > 0) {
      img = obj.replace("RenditionID=1", `Height=${height}&Width=${width}`);
    }
    return encodeURI(img);
  }

  public static formatTimeHelper(obj: string): string {
    var time: string = "";
    if (obj !== undefined && obj !== null && obj.length > 0) {
      const date = new Date(1970, 0, 1);
      date.setSeconds(Number(obj));
      time = date.toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
    }
    return time;
  }
  public static delvePropertyValueHelper(
    props: { Name: string; Value: string }[],
    property: string
  ): string {
    var value: string = "";
    if (
      props === undefined ||
      props === null ||
      props.length === 0 ||
      property === ""
    ) {
      value = "";
    } else {
      for (var iCnt = 0; iCnt < props.length - 1; iCnt++) {
        if (props[iCnt].Name.toLowerCase() === property.toLowerCase()) {
          value = props[iCnt].Value;
        }
      }
    }
    return value;
  }
  public static iconClassHelper(obj: string): string {
    var iconclass: string = "";
    if (obj !== undefined && obj !== null && obj.length > 0) {
      switch (obj.toLowerCase()) {
        case "doc":
        case "docx":
        case "word":
          iconclass = "word";
          break;
        case "powerpoint":
        case "ppt":
        case "pptx":
          iconclass = "powerpoint";
          break;
        case "excel":
        case "xls":
        case "xlsx":
        case "xlsm":
          iconclass = "excel";
          break;
        case "pdf":
          iconclass = "pdf";
          break;
        case "onenote":
          iconclass = "onenote";
          break;
        case "jpg":
        case "png":
          iconclass = "image";
          break;
        default:
          iconclass = "icon";
          break;
      }
    }
    return iconclass;
  }
  public static userProfileUrlHelper(
    context: WebPartContext,
    accountName: string
  ): string {
    if (
      accountName === undefined ||
      accountName === null ||
      accountName.length === 0
    ) {
      return (
        context.pageContext.site.absoluteUrl +
        "/_layouts/15/me.aspx?v=work&p=" +
        context.pageContext.user.loginName
      );
    } else {
      return (
        context.pageContext.site.absoluteUrl +
        "/_layouts/15/me.aspx?v=work&p=" +
        accountName
      );
    }
  }
  public static userPictureHelper(
    context: WebPartContext,
    obj: string
  ): string {
    if (obj === undefined || obj === null || obj.length === 0) {
      return (
        "/_layouts/15/UserPhoto.aspx?size=s&userName=" +
        context.pageContext.user.loginName
      );
    } else {
      return (
        "/_layouts/15/UserPhoto.aspx?size=s&userName=" +
        obj.replace("i:0#.f|membership|", "")
      );
    }
  }
  public static carouselClassHelper(obj: string): string {
    if (obj !== undefined && obj !== null && obj.length > 0) {
      const CarouselConfig = JSON.parse(obj);
      return CarouselConfig["CarouselClass"];
    } else {
      return "";
    }
  }
  public static userPresenceHelper(
    context: WebPartContext,
    obj: string
  ): string {
    if (obj === undefined || obj === null || obj.length === 0) {
      return context.pageContext.user.loginName;
    } else {
      return obj.replace("i:0#.f|membership|", "");
    }
  }

  public static convertToNumberHelper(content: string): number {
    if (content === undefined || content === null || content.length === 0) {
      return 0;
    } else {
      if (Utilities.isNumber(content)) {
        return Math.floor(Number(content));
      } else {
        return 0;
      }
    }
  }
  public static registerEqualValueHelper(lvalue: any, rvalue: any): boolean {
    if (lvalue === rvalue) {
      return true;
    } else {
      return false;
    }
  }
  public static trimContentHelper(content: string, length: number): string {
    if (content === undefined || content === null || content.length === 0) {
      return "";
    } else {
      return content.length > length
        ? content.substr(0, length - 3) + "..."
        : content;
    }
  }
  public static repeatHelper(n: any, options: any) {
    var hasNumber = Utilities.isNumber(n);
    if (typeof n === "undefined") {
      throw "n is not defined";
    }
    if (!hasNumber) {
      options = n;
    }

    if (options && options.count) {
      n = options.count;
      hasNumber = true;
    }

    n = Number(n);

    if (hasNumber) {
      return block(options);
    } else {
      return options.inverse(options);
    }

    function block(opts: any) {
      opts = opts || {};
      var str = "";

      const hash = opts.hash || {};
      hash.start = hash.start || 0;

      for (var i = hash.start; i < n + hash.start; i++) {
        hash.index = i;
        hash.first = i === 0;
        hash.last = i === n + hash.start - 1;

        str += opts.fn(opts, { data: hash });
      }
      return str;
    }
  }

  public static isMemberOfHelper(obj: any, operator: any, value: any, options: any) {
    if (
      obj != undefined &&
      obj != null &&
      obj.length > 0 &&
      value != undefined
    ) {
      if (typeof value == "object") {
        let array =
          value.map((i: any) => {
            return obj.filter((j: any) => {
              return j.displayName == i.toLowerCase();
            });
          }) ||
          value.map((i: any) => {
            return obj.filter((j: any) => {
              return j.mail == i;
            });
          });
        switch (operator) {
          case "!=":
            if (
              array.filter((i: any) => {
                return i.length;
              }).length == 0
            ) {
              return options.fn(this);
            } else {
              return options.inverse(this);
            }
          case "&&":
            if (
              array.filter((i: any) => {
                return i.length;
              }).length == array.length
            ) {
              return options.fn(this);
            } else {
              return options.inverse(this);
            }
          case "||":
            if (
              array.filter((i: any) => {
                return i.length;
              }).length > 0
            ) {
              return options.fn(this);
            } else {
              return options.inverse(this);
            }
        }
      } else {
        switch (operator) {
          case "!=":
            if (
              obj.filter((item: any) => {
                return item.displayName == value.toLowerCase();
              }).length == 0 &&
              obj.filter((item: any) => {
                return item.mail == value;
              }).length == 0
            ) {
              return options.fn(this);
            } else {
              return options.inverse(this);
            }
          case "==":
            if (
              obj.filter((item: any) => {
                return item.displayName == value.toLowerCase();
              }).length > 0 ||
              obj.filter((item: any) => {
                return item.mail == value;
              }).length > 0
            ) {
              return options.fn(this);
            } else {
              return options.inverse(this);
            }
        }
      }
    }
  }
  public static createArrayHelper(varname: any, options: any) {
    let value = Array.prototype.slice.call(arguments, 1, -1);
    arguments[arguments.length - 1].data.root[varname] = value;
  }
}

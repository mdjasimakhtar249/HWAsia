import { ServiceScope } from '@microsoft/sp-core-library';
import { WebPartContext } from '@microsoft/sp-webpart-base';
// import { MSGraphClient } from '@microsoft/sp-http';
import { MSGraphClientV3 } from '@microsoft/sp-http';
import { AppInsightsService } from './AppInsightsService';

export interface IUserGroupProperty {
    displayName: string;
    mail: string;
}
export class UserGroupService {

    //This method used to get M365 groups using Graph API
    public static getSPGroupsOfUser(context: WebPartContext, serviceScope: ServiceScope): Promise<IUserGroupProperty> {
        return new Promise<any>((resolve, reject) => {            
            let webUrl = `me/memberOf?$top=999`;
            AppInsightsService.trackEvent(serviceScope, 'UserGroupService');
            context.msGraphClientFactory.getClient('3').then((client: MSGraphClientV3): void => {
                client.api(webUrl).get((error, response) => {
                    if (error != null)
                        resolve(error);
                    else {
                        if (response["@odata.nextLink"] != undefined) {
                            let userGroupsException = "HW-UserGroupService returns 1000 M365 groups.";
                            AppInsightsService.trackException(serviceScope, { name: 'HW-UserGroupService', message: userGroupsException });
                            console.log(userGroupsException);
                        }
                        resolve(response.value);
                    }
                });
            }).catch(err => {
                AppInsightsService.trackException(serviceScope, err);
                reject(err);
            });
        });
    }
}
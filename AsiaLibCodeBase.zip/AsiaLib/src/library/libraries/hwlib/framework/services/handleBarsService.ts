import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { SPHttpClient, SPHttpClientResponse } from "@microsoft/sp-http";
import { Dictionary } from "../../hwlibcore/Dictionary";
import { AppInsightsService } from "../../framework/services/AppInsightsService";
import HandlebarUtilities from "../ui/HandlebarUtilities";
import { HWStyles } from "../../../../index";
import * as PromiseQueue from "promise-queue";
import { Log } from "@microsoft/sp-core-library";
import { InstanceLoader } from "../../hwlibcore/sp/InstanceLoader";
import { IHandlerbarHandler } from "./IHandlerbarHandler";
import { IHandlerbarHandlerConfig } from "./IHandlebarHandlerConfig";
import { Guid } from "@microsoft/sp-core-library";
import * as Handlebars from "handlebars";

export interface IHandlebarsService {
  transformTemplate(templateUrl: string, data: any): Promise<string>;
  transformString(template: string, data: any): Promise<string>;  
  getTemplatesPath(templateUrl: string, folderName: string): ITemplatesPath;
  registerHelper(name: string, func: (args) => any);
  loadHandlebars(): Promise<{}>;
  loadExtensions(extensionConfig: IHandlerbarHandlerConfig[]): Promise<{}>;
  addExtensionLibrary(templateString: string): any;
}

export interface ITemplatesPath {
  configSite: string;
  templatesFolderPath: string;
}

/**
 * Service for working with handlebars
 */
export class HandlebarsService implements IHandlebarsService {
  private _serviceScope: ServiceScope;
  private _cache: Dictionary<any>;
  private _hbs: any;
  private _loaded: boolean;
  private _queue: PromiseQueue;
  private _handlebars: typeof Handlebars;

  /**
   * A no conflict instance of Handlebars
   */
  get Handlebars(): typeof Handlebars {
    return this._handlebars;
  }

  /**
   * Default constructor
   * @param serviceScope the SPFx ServiceScope
   */
  constructor(serviceScope: ServiceScope) {
    this._serviceScope = serviceScope;
    this._cache = new Dictionary<any>();
    this._hbs = Handlebars.create();
    this._loaded = false;
    this._queue = new PromiseQueue(1);
    if ((<any>window).__ava_dev_mode__ === true) {
      console.warn(
        `[HW]: WARNING. DEV MODE IS CONFIGURED SO CACHING OF HANDLEBARS IS DISABLED`
      );
    }
  }

  /**
   * Loads the Handlebars JavaScript file (from https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.11/handlebars.min.js")
   * Also adds standard HW Handlebars helper functions
   * @returns A promise which resolves when loaded
   */
  public loadHandlebars(): Promise<{}> {
    return new Promise<{}>((resolve, reject) => {
      if (this._loaded) {
        resolve({});
      }
      try {
        HandlebarUtilities.registerHelpers(this._hbs);
        this._hbs.registerHelper("uri", (obj) => {
          return obj.get_uri();
        });
        this._hbs.registerHelper("name", (obj) => {
          return obj.get_name();
        });
        this._hbs.registerHelper("style", (styleName) => {
          return HWStyles.default[styleName];
        });
        this._loaded = true;
        resolve({});
      } catch (error) {
        reject(`HW: Unable to load Handlebars: ${error}`);
      }
    });
  }

  /**
   * Loads the custom handlebars helper library/libraries
   * @param extensionConfig an array with the custom hbs helper libraries
   * @returns A promise which resolves when loaded
   */
  public async loadExtensions(
    extensionConfig: IHandlerbarHandlerConfig[]
  ): Promise<{}> {
    if (this._hbs) {
      for (const configuration of extensionConfig) {
        const loader = new InstanceLoader();
        const libraryinstance = await loader
          .getInstanceFromComponent<IHandlerbarHandler>(
            configuration.componentId,
            configuration.componentName
          )
          .then((p) => {
            p.register(this._hbs);
          })
          .catch((err) => {
            console.error(
              "HW HandleBarService - CustomHandleBar not loaded properly!"
            );
            AppInsightsService.trackException(this._serviceScope, err);
            Log.error(`HW`, err);
          });
      }
    } else {
      Log.warn("HW", "Handlebarservice is not initialized");
    }
    return {};
  }

  /**
   * Adds custom helper function library
   * @param templateString template to check for custom helper reference
   */
  public async addExtensionLibrary(templateString: string): Promise<string> {
    let regex = /<!-- importCustomHandleBar: [\s\S]*?-->/i;
    let importstatement = "";
    const matches = regex.exec(templateString);
    if (matches) {
      importstatement = matches[0]
        .replace("<!-- importCustomHandleBar:", "")
        .replace("-->", "")
        .trim();
      templateString = templateString.replace(regex, "");
    }

    if (importstatement && importstatement.length > 0) {
      let importlib = importstatement.split(",");
      if (importlib && importlib.length === 2 && Guid.isValid(importlib[0])) {
        const loadExtensions = await this.loadExtensions([
          { componentId: importlib[0], componentName: importlib[1] },
        ])
          .then(() => {})
          .catch((err) => {
            console.log("addExtensionLibrary - ERROR [" + err + "]");
            Log.error("HW", err);
          });
      }
    }
    return templateString;
  }
  /**
   * Adds a Handlebars helper function
   * @param name name of the function
   * @param func implementation of the function
   */
  public registerHelper(name: string, func: (args) => any): void {
    if (this._loaded) {
      this._hbs.registerHelper(name, func);
    } else {
      throw "Handlebars not loaded";
    }
  }
  /*public async transformData(
    serviceScope: any,
    template: string,
    data: any
  ): Promise<any> {
    let hbs: IHandlebarsService;
    hbs = new HandlebarsService(serviceScope);
    await hbs.loadHandlebars();
    const helpers = handlebarsHelpers();
    Object.keys(helpers).forEach((helperName) => {
      console.log("helperName", helperName);
      hbs.registerHelper(helperName, helpers[helperName]);
    });
    // hbs.registerHelper('dateDiff', this.dateDiff);
    let transformString = await hbs.transformString(template, data);
    return transformString;
  }*/

  /**
   * Transforms data using a Handlebars template
   * @param templateUrl absolute URL of the template
   * @param data the data to transform
   * @param queue set to true if the transformation should use the built-in queue
   * @returns a Promise with the resulting HTML
   */
  public transformTemplate(
    templateUrl: string,
    data: any,
    queue = true
  ): Promise<string> {
    Log.info(`HW`, `Added ${templateUrl} to handlebars queue`);
    let item = () => {
      return new Promise<string>((resolve, reject) => {
        if (!templateUrl) {
          reject(`Invalid templateUrl: '${templateUrl}`);
        }
        const transformed = this._cache.get(templateUrl.toLowerCase());
        if (transformed != null && (<any>window).__ava_dev_mode__ !== true) {
          AppInsightsService.trackEvent(this._serviceScope, "AVA:HB:CacheHit");
          const result = transformed(data);
          resolve(result);
        } else {
          this.loadHandlebars().then(() => {
            const client = new SPHttpClient(this._serviceScope as any);
            client
              .get(templateUrl, SPHttpClient.configurations.v1)
              .then((response: SPHttpClientResponse) => {
                if (response.status == 200) {
                  response.text().then((text) => {
                    const ares = this.addExtensionLibrary(text)
                      .then((templatetext: string) => {
                        const template = this._hbs.compile(templatetext);
                        this._cache.add(templateUrl.toLowerCase(), template);
                        const result = template(data);
                        AppInsightsService.trackEvent(
                          this._serviceScope,
                          "AVA:HB:CacheMiss"
                        );
                        resolve(result);
                      })
                      .catch((err) => {
                        reject(err);
                      });
                  });
                } else {
                  AppInsightsService.trackEvent(
                    this._serviceScope,
                    "AVA:HB:InvalidTemplate"
                  );
                  reject(
                    `Unable to load template. HTTP status = ${response.status} ${response.statusText}`
                  );
                }
              })
              .catch((err) => {
                reject(err);
              });
          });
        }
      });
    };
    if (queue) {
      return this._queue.add(item);
    }
    return item();
  }

  /**
   * Transforms data using a handlebars template
   * @param templateString the Handlebars template text
   * @param data the data to transform
   * @returns a Promise with the resulting HTML
   */
  public transformString(templateString: string, data: any): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const templateHash = HandlebarsService.hashCode(templateString);
      const transformed = this._cache.get(`hash-${templateHash}`);
      if (transformed != null && (<any>window).__ava_dev_mode__ !== true) {
        AppInsightsService.trackEvent(this._serviceScope, "AVA:HB:CacheHit");
        const result = transformed(data);
        resolve(result);
      } else {
        this.loadHandlebars().then(() => {
          const ares = this.addExtensionLibrary(templateString)
            .then((templatetext: string) => {
              AppInsightsService.trackEvent(
                this._serviceScope,
                "AVA:HB:transformString"
              );
              const template = this._hbs.compile(templatetext);
              try {
                this._cache.add(`hash-${templateHash}`, template);
                let html = template(data);
                resolve(html);
              } catch (error) {
                reject(error);
              }
            })
            .catch((err) => {
              reject(err);
            });
        });
      }
    });
  }

  /**
   * Retrieves template paths
   * @param templateUrl absolute URL of the template
   * @param folderName the folder name
   * @returns an object with the configuration site and the templates folder path
   */
  public getTemplatesPath(
    templateUrl: string,
    folderName: string
  ): { configSite: string; templatesFolderPath: string } {
    const sitesmanagedPath = "/sites/",
      teamsmanagedPath = "/teams/";
    let configSite = "",
      templatesFolderPath = "";

    if (templateUrl.indexOf(sitesmanagedPath) >= 0) {
      configSite = templateUrl.substring(
        0,
        templateUrl.indexOf(
          "/",
          templateUrl.indexOf(sitesmanagedPath) + sitesmanagedPath.length
        )
      );
      templatesFolderPath = templateUrl.substring(
        templateUrl.indexOf(
          "/",
          templateUrl.indexOf(sitesmanagedPath) + sitesmanagedPath.length
        ) + 1,
        templateUrl.length
      );
    } else if (templateUrl.indexOf(teamsmanagedPath) >= 0) {
      configSite = templateUrl.substring(
        0,
        templateUrl.indexOf(
          "/",
          templateUrl.indexOf(teamsmanagedPath) + sitesmanagedPath.length
        )
      );
      templatesFolderPath = templateUrl.substring(
        templateUrl.indexOf(
          "/",
          templateUrl.indexOf(teamsmanagedPath) + sitesmanagedPath.length
        ) + 1,
        templateUrl.length
      );
    } else {
      configSite = templateUrl.substring(
        0,
        templateUrl.indexOf("/", templateUrl.indexOf("//") + 2)
      );
      templatesFolderPath = templateUrl.substring(
        templateUrl.indexOf("/", templateUrl.indexOf("//") + 2) + 1,
        templateUrl.length
      );
    }
    templatesFolderPath += folderName;
    return { configSite, templatesFolderPath };
  }

  public static hashCode(data: string): number {
    let hash = 0;

    if (data.length == 0) return hash;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
  }
}

/**
 * Exported service key
 */
export const handlebarsServiceKey: ServiceKey<IHandlebarsService> = ServiceKey.create<
  IHandlebarsService
>("DEEJS:HandlebarsService", HandlebarsService);

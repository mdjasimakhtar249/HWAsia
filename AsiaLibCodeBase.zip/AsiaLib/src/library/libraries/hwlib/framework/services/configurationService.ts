import { ServiceScope, ServiceKey } from '@microsoft/sp-core-library';
import { IHWConfiguration } from './IHWConfiguration';
import { IStorageEntityBaseService, StorageEntityBaseService } from './storageEntityBaseService';

//const RELOAD_DAYS: number = 8;
const ID_NAME: string = 'AVA:HWConfig';
/**
 * Implementation of the HW Configuration Service
 */
export class HWConfigService extends StorageEntityBaseService<IHWConfiguration> {
    constructor(serviceScope: ServiceScope) {
        super(serviceScope);
    }
    public id() {
        return ID_NAME;
    }
    public nextUpdate(): Date {
        var result = new Date();
        //result.setDate(result.getDate() + RELOAD_DAYS);
        result.setMinutes(result.getMinutes()+10);
        result.setDate(result.getDate());
        return result;
    }    
}

/**
 * The HW Configuration Service key
 */
export const HWConfigServiceKey: ServiceKey<IStorageEntityBaseService<IHWConfiguration>> = ServiceKey.create<IStorageEntityBaseService<IHWConfiguration>>('HW:ConfigService', HWConfigService);
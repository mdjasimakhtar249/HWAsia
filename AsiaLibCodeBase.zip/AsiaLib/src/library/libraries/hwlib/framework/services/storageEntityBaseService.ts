import { ServiceScope } from '@microsoft/sp-core-library';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { SessionStorageCache } from '../../hwlibcore/cache/SessionStorageCache';
import { Log } from '@microsoft/sp-core-library';

/**
 * Definition of the HW Configuration Service
 */
export interface IStorageEntityBaseService<T> {
    load(): Promise<void>;
    settings(): T;
}

const CACHE_RELOAD_INTERVAL: number = 20000;
const LOG_SOURCE: string = "HW: StorageEntityBaseService";


export abstract class StorageEntityBaseService<T> implements IStorageEntityBaseService<T> {
    private _settings: T;
    private _loaded: boolean = false;
    private _serviceScope: ServiceScope;
    private _reloadCount: number;
    private _globalFileNotFound: boolean;
    private _localFileNotFound: boolean;
    //private _cache: SessionStorageCache;
    private _webUrl: string = window.location.protocol + "//" + window.location.host;
    private _serverRelativeUrl: string = "";
    private _alwaysReadGlobalConfigFlagName = "alwaysReadGlobalConfig";
    private siteCollectionCacheId = `${this.id()}_${this._serverRelativeUrl}`;
    private alwaysReadGlobalConfigFlagCache = `${this.id()}_${this._alwaysReadGlobalConfigFlagName}`;
    private doesAlwaysReadGlobalConfigCacheExist: boolean;
    private alwaysReadGlobalConfigStatus: boolean = false;

    constructor(serviceScope: ServiceScope) {
        this._serviceScope = serviceScope;
        //this._cache = new SessionStorageCache();
        this._reloadCount = 1;
        this._globalFileNotFound = false;
        this._localFileNotFound = false;

        //TEMP FIX: Bug 296
        const pathname = window.location.pathname.toLowerCase();
        const sitesmanagedPath = "/sites/";
        const teamsmanagedPath = "/teams/";
        if (pathname.indexOf(sitesmanagedPath) >= 0) {
            if (pathname.indexOf("/", sitesmanagedPath.length) > 1) {
                this._webUrl += pathname.substring(0, pathname.indexOf("/", sitesmanagedPath.length));
            } else {
                this._webUrl += pathname;
            }
        } else {
            if (pathname.indexOf(teamsmanagedPath) >= 0) {
                if (pathname.indexOf("/", teamsmanagedPath.length) > 1) {
                    this._webUrl += pathname.substring(0, pathname.indexOf("/", teamsmanagedPath.length));
                } else {
                    this._webUrl += pathname;
                }
            }
        }
        let a = this._webUrl;
        let b = pathname.replace(/\/$/, "");
        if (b.indexOf(sitesmanagedPath) != -1 || b.indexOf(teamsmanagedPath) != -1) {
            for (var i = 0; i < a.length; ++i) {
                for (var j = 0; j < b.length; ++j) {
                    if (a[i] === b[j]) {
                        var str = a[i];
                        var k = 1;
                        while (i + k < a.length && j + k < b.length
                            && a[i + k] === b[j + k]) {
                            str += a[i + k];
                            ++k;
                        }
                        if (str.length > this._serverRelativeUrl.length) { this._serverRelativeUrl = str.toLowerCase(); }
                    }
                }
            }
        }
        //this.setReload();
    }

    /*private setReload(): void {
        window.setTimeout(() => {
            Log.info(LOG_SOURCE, `Reloading HW configuration (#${this._reloadCount})`);
            this.getFromSPOEntity(() => { }, () => { }, this._cache);
            this._reloadCount++;
            this.setReload();
        }, CACHE_RELOAD_INTERVAL * this._reloadCount); // exponentially reload with longer intervals
    }*/

    public load(): Promise<void> {
        const cache = new SessionStorageCache();
        return new Promise<void>((resolve, reject) => {
            let alwaysReadGlobalConfigFlagCache = `${this.id()}_${this._alwaysReadGlobalConfigFlagName}`;
            let siteCollectionCacheId = `${this.id()}_${this._serverRelativeUrl}`;
            //Check the value of alwaysReadGlobalConfigFlagCache in cache if found in cache and if value is true
            let getFlagCacheValue = (cache.get(alwaysReadGlobalConfigFlagCache) == undefined || cache.get(alwaysReadGlobalConfigFlagCache) == "undefined") ? cache.get(alwaysReadGlobalConfigFlagCache) : JSON.parse(cache.get(alwaysReadGlobalConfigFlagCache));
            if (cache.exists(alwaysReadGlobalConfigFlagCache) && getFlagCacheValue == true && (cache.get(alwaysReadGlobalConfigFlagCache) != undefined && cache.get(alwaysReadGlobalConfigFlagCache) != "undefined")) {
                if (!this.checkForCache(resolve, reject, cache, this.id())) {
                    //If cache for global config doesn't exist, call getFromSPOEntity method
                    this.getFromSPOEntity(resolve, reject, cache);
                }
            } else {
                //Check if config cache for site collection exists
                if (!this.checkForCache(resolve, reject, cache, siteCollectionCacheId)) {
                    //If config cache for site collection doesn't exist, call getFromSPOEntity method
                    this.getFromSPOEntity(resolve, reject, cache);
                }
            }
        });
    }

    //Load local cache data
    private loadLocalConfigData(cache: SessionStorageCache) {
        const siteCollectionData = cache.get(this.id() + "_" + this._serverRelativeUrl);
        let siteCollectionValue = (siteCollectionData == "undefined" || siteCollectionData == undefined || siteCollectionData == null) ? undefined : JSON.parse(siteCollectionData);
        if (siteCollectionValue != undefined) {
            this._settings = siteCollectionValue;
        }
    }

    //Method to check for config cache by id and set if found
    private checkForCache(resolve: Function, reject: Function, cache: SessionStorageCache, cacheId: string): boolean | undefined {
        let cacheFound = false;
        let siteCollectionCacheName = `${this.id()}_${this._serverRelativeUrl}`;
        let alwaysReadGlobalConfigFlagCache = `${this.id()}_${this._alwaysReadGlobalConfigFlagName}`;
        if (cache.exists(this.id())) {
            const val = cache.get(this.id());
            try {
                let json = (val == "undefined" || val == undefined || val == null) ? undefined : JSON.parse(val);
                if (json != undefined) {
                    let alwaysReadGlobalConfigFlag = (json[this._alwaysReadGlobalConfigFlagName] == undefined || json[this._alwaysReadGlobalConfigFlagName] == "undefined" || json[this._alwaysReadGlobalConfigFlagName] == null) ? false : json[this._alwaysReadGlobalConfigFlagName];
                    cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, JSON.stringify(alwaysReadGlobalConfigFlag), this.nextUpdate());
                    if (cache.get(alwaysReadGlobalConfigFlagCache) != undefined && cache.get(alwaysReadGlobalConfigFlagCache) != "undefined") {
                        if (JSON.parse(cache.get(alwaysReadGlobalConfigFlagCache))) {
                            this._settings = json;
                            this._loaded = true;
                            if (resolve) {
                                resolve();
                            }
                        } else if (cache.exists(cacheId)) {
                            try {
                                if (cacheId == siteCollectionCacheName) {
                                    this.loadLocalConfigData(cache);
                                } else {
                                    try {
                                        let alwaysReadGlobalConfigFlagName = (json[this._alwaysReadGlobalConfigFlagName] == undefined || json[this._alwaysReadGlobalConfigFlagName] == "undefined" || json[this._alwaysReadGlobalConfigFlagName] == null) ? false : json[this._alwaysReadGlobalConfigFlagName];
                                        cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, JSON.stringify(alwaysReadGlobalConfigFlagName), this.nextUpdate());
                                        this._settings = json;
                                    } catch (err) {
                                        throw err;
                                    }
                                }
                                this._loaded = true;
                                cacheFound = true;
                                if (resolve) {
                                    resolve();
                                }
                            } catch (err) {
                                throw err;
                            }
                            return cacheFound;
                        }
                    }
                }
            } catch (err) {
                throw err;
            }
        } else if (cache.exists(siteCollectionCacheName)) {
            this.loadLocalConfigData(cache);
            this._loaded = true;
            cacheFound = true;
            if (resolve) {
                resolve();
            }
            return cacheFound;
        }
    }

    //Method to fetch data from global/local config entities depend on "alwaysReadGlobalConfig" value.
    //if value set as true in global config, the method will always first hit the global config and hit local config file only if global config doesn't exist.

    private async getFromSPOEntity(resolve: Function, reject: Function, cache: SessionStorageCache) {
        const client = new SPHttpClient(this._serviceScope as any);
        //set config value alwaysReadGlobalConfig
        this.alwaysReadGlobalConfigFlagCache = `${this.id()}_${this._alwaysReadGlobalConfigFlagName}`;
        this.doesAlwaysReadGlobalConfigCacheExist = cache.exists(this.alwaysReadGlobalConfigFlagCache);

        //first hit the global config if alwaysReadGlobalConfig cache doesn't exist.
        if (!this.doesAlwaysReadGlobalConfigCacheExist) {
            let globalSettings = await this.loadFromStorageEntity(client, this._webUrl, cache, reject);
            this.alwaysReadGlobalConfigStatus = (globalSettings[this._alwaysReadGlobalConfigFlagName] == undefined || globalSettings[this._alwaysReadGlobalConfigFlagName] == "undefined") ? false : globalSettings[this._alwaysReadGlobalConfigFlagName];
        }
        const alwaysReadGlobalConfigFlag: boolean = this.doesAlwaysReadGlobalConfigCacheExist ? ((cache.get(this.alwaysReadGlobalConfigFlagCache) != undefined && cache.get(this.alwaysReadGlobalConfigFlagCache) != "undefined") ? JSON.parse(cache.get(this.alwaysReadGlobalConfigFlagCache)) : false) : false;

        // if local and global config doesn't exist.
        if (this._globalFileNotFound == true && this._localFileNotFound == true) {
            Log.error(LOG_SOURCE + "HW configuration failed to load: ", new Error("HW configuration failed to load"), this._serviceScope);
            console.log("HW configuration failed to load");
            this._loaded = false;
        }
        //if global config exist and alwaysReadGlobalConfig cache set as true
        else if (alwaysReadGlobalConfigFlag) {
            //Get value from cache for first render
            if (this._reloadCount == 1) {
                //check if global value of config is available in cache            
                if (!this.checkForCache(resolve, reject, cache, this.id())) {
                    //Load from storage entity if not available in cache
                    this.loadFromStorageEntity(client, this._webUrl, cache, reject).then(globalSettings => {
                        this._settings = globalSettings;
                        this._loaded = true;
                        if (resolve) {
                            resolve();
                        }
                    }).catch((err) => {
                        this._loaded = false;
                        if (reject) {
                            cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, false, this.nextUpdate());
                            reject(err);
                        }
                    });
                    return;
                } else {
                    this.checkForCache(resolve, reject, cache, this.siteCollectionCacheId);
                }
                return;
            }
            //Load the global config cache in the background on subsequent calls to the method
            else if (this._reloadCount > 1) {
                this.loadFromStorageEntity(client, this._webUrl, cache, reject).then(globalSettings => {
                    this._settings = globalSettings;
                    this._loaded = true;
                    if (resolve) {
                        resolve();
                    }
                }).catch((err) => {
                    this._loaded = false;
                    if (reject) {
                        reject(err);
                    }
                });
                return;
            }
        }
        else {
            // If we already tried to find the local file, don't try it once again
            // This will only be true in subsequent calls to the method
            if (this._localFileNotFound && this._reloadCount == 1) {
                //check if global value of config is available in cache            
                if (!this.checkForCache(resolve, reject, cache, this.id())) {
                    //Load from storage entity if not available in cache
                    this.loadFromStorageEntity(client, this._webUrl, cache, reject).then(globalSettings => {
                        this._settings = globalSettings;
                        this._loaded = true;
                        if (resolve) {
                            resolve();
                        }
                    }).catch((err) => {
                        this._loaded = false;
                        if (reject) {
                            reject(err);
                        }
                    });
                }
            }
            //Load the global config cache in the background on subsequent calls to the method
            else if (this._localFileNotFound && this._reloadCount > 1) {
                this.loadFromStorageEntity(client, this._webUrl, cache, reject).then(globalSettings => {
                    this._settings = globalSettings;
                    this._loaded = true;
                    if (resolve) {
                        resolve();
                    }
                }).catch((err) => {
                    cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, false, this.nextUpdate());
                    this._loaded = false;
                    if (reject) {
                        reject(err);
                    }
                });
            }
            //If _localFileNotFound flag is set to false and config is not available in cache, try to get configuration from file
            else {
                let localConfigData = await this.getLocalConfigData(client);
                if (localConfigData.status == 200) {
                    try {
                        let data = await localConfigData.json();
                        this.setSettings(data, cache, resolve);
                    }
                    catch (err) {
                        Log.error(LOG_SOURCE + "HW configuration failed to load: ", err, this._serviceScope);
                    }
                }
                //if config file not found, set variable to true and check if global config is available in cache
                else {
                    this._localFileNotFound = true;
                    if (cache.exists(this.id())) {
                        const val = cache.get(this.id());
                        try {
                            const json: T = (val != undefined && val != "undefined" && val != null) ? JSON.parse(val) : {};
                            let alwaysReadGlobalConfigFlagName = (json[this._alwaysReadGlobalConfigFlagName] == undefined || json[this._alwaysReadGlobalConfigFlagName] == "undefined") ? false : json[this._alwaysReadGlobalConfigFlagName];
                            cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, JSON.stringify(alwaysReadGlobalConfigFlagName), this.nextUpdate());
                            this._settings = json;
                            this._loaded = true;
                            resolve();
                        } catch (err) {
                            cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, false, this.nextUpdate());
                        }
                    }
                    //if global config not available in cache, fetch from storage entity
                    else {
                        this.loadFromStorageEntity(client, this._webUrl, cache, reject).then(globalSettings => {
                            this._settings = globalSettings;
                            this._loaded = true;
                            if (resolve) {
                                resolve();
                            }
                        }).catch((err) => {
                            this._loaded = false;
                            if (reject) {
                                reject(err);
                            }
                            cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, false, this.nextUpdate());
                        });
                    }
                }
            }
        }
    }

    //Get local configuration data
    private async getLocalConfigData(client: SPHttpClient) {
        let value = await client.fetch(this._webUrl + `/_api/web/GetFileByServerRelativeUrl('${this._serverRelativeUrl}/Shared%20Documents/Config.json')/$value`, SPHttpClient.configurations.v1, {});
        return value;
    }

    private setSettings(data: any, cache: SessionStorageCache, resolve: Function) {
        this._settings = data;
        this._loaded = true;
        cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, JSON.stringify(this.alwaysReadGlobalConfigStatus), this.nextUpdate());
        cache.add(this.id() + "_" + this._serverRelativeUrl, JSON.stringify(this._settings), this.nextUpdate());
        if (resolve) {
            resolve();
        }
    }

    //Method to load configuration from storage entity
    private async loadFromStorageEntity(client: SPHttpClient, webUrl: string, cache: SessionStorageCache, reject: Function): Promise<any> {
        /* tslint:disable-next-line */
        let result = await client.fetch(webUrl + `/_api/web/GetStorageEntity('${this.id()}')`, SPHttpClient.configurations.v1, {});
        try {
            let data = await result.json();
            try {
                let parsedData = (data.Value != undefined && data.Value != "undefined" && data.Value != null) ? JSON.parse(data.Value) : {};
                this._loaded = true;
                if (data.Value != undefined) {
                    if ((parsedData[this._alwaysReadGlobalConfigFlagName] != undefined && parsedData[this._alwaysReadGlobalConfigFlagName] != "undefined")) {
                        this.doesAlwaysReadGlobalConfigCacheExist = true;
                    } else {
                        this.doesAlwaysReadGlobalConfigCacheExist = false;
                    }
                    cache.add(this.id(), data.Value, this.nextUpdate());
                } else if (data.Value == undefined) {
                    this.doesAlwaysReadGlobalConfigCacheExist = false;
                    this._globalFileNotFound = true;
                }
                let alwaysReadGlobalConfigFlag = (data.Value == undefined) ? false : (parsedData[this._alwaysReadGlobalConfigFlagName] == undefined || parsedData[this._alwaysReadGlobalConfigFlagName] == "undefined") ? false : parsedData[this._alwaysReadGlobalConfigFlagName];
                cache.add(`${this.id()}_${this._alwaysReadGlobalConfigFlagName}`, JSON.stringify(alwaysReadGlobalConfigFlag), this.nextUpdate());
                return parsedData;
            }
            catch (error) {
                Log.error(LOG_SOURCE + "HW configuration failed to load: ", error, this._serviceScope);
                if (reject) {
                    reject(error);
                }
            }
        } catch (error) {
            if (reject) {
                reject(error);
            }
        }
    }

    public settings(): T {
        if (this._loaded) {
            return this._settings;
        } else {
            throw new Error('Service not properly loaded');
        }
    }

    public abstract id(): string;

    public abstract nextUpdate(): Date;
}
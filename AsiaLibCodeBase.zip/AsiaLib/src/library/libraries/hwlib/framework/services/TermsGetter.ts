import { JsomLoader } from "../../../../index";

export interface ITermSetConfig {
    id: string;
    columnName: string;
}

export interface ITermItem {
    name: string;
    id: string;
    description: string;
    key: string;
    url: string;
    isExpanded: boolean;
    displayForAll: boolean;
    level?: number;
}

export class TermItem implements ITermItem {
    constructor(public name: string, public url: string = "") {
        this.links = new Array<ITermItem>();
        this.items = new Array<ITermItem>();
    }
    public id: string;
    public description: string;
    public key: string;
    public links: Array<ITermItem>;
    public items: Array<ITermItem>;
    public isExpanded: boolean;
    public displayForAll: boolean;
    public level?: number;
}

export class Terms {
    constructor() {
        this.links = new Array<ITermItem>();
    }
    public links: Array<ITermItem>;
}

export class TermsGetter {

    constructor(public config: ITermSetConfig) {

    }

    /**
     * Method to load termset, custom properties of termset and terms in it
     */
    public load(callback: (m: any) => any, failCallback: (err: string) => void) {
        JsomLoader.LoadJsom().then(() => {
            JsomLoader.LoadAdditionalJsomScript('/_layouts/15/SP.taxonomy.js', 'SP').then(() => {

                const c: ITermSetConfig = this.config;
                const ctx: SP.ClientContext = window.location.pathname.indexOf('.aspx') > -1 ?
                    SP.ClientContext.get_current() :
                    new SP.ClientContext(window.location.pathname); // workaround for bug reported in https://github.com/SharePoint/sp-dev-docs/issues/1415

                const taxonomySession: SP.Taxonomy.TaxonomySession = SP.Taxonomy.TaxonomySession.getTaxonomySession(ctx),
                    termStore: SP.Taxonomy.TermStore = taxonomySession.getDefaultSiteCollectionTermStore(),
                    termSet: SP.Taxonomy.TermSet = termStore.getTermSet(new SP.Guid(c.id)),
                    terms: SP.Taxonomy.TermCollection = termSet.getAllTerms();

                ctx.load(termSet);
                ctx.load(terms, 'Include(Id, Name, PathOfTerm, Description, LocalCustomProperties, CustomProperties)');
                ctx.executeQueryAsync(
                    (sender: any, args: any) => {
                        //TermSet object with Termset: name and rank and All Terms
                        const TermSetObj: { termSet: { name: string, rank: string }, terms: { links: Array<any> } } = { termSet: { name: c.columnName, rank: termSet.get_customProperties()['AVA.Rank'] }, terms: { links: [] } };
                        const requestedTerms: { links: Array<any> } = { links: [] };
                        const enumerator: IEnumerator<SP.Taxonomy.Term> = terms.getEnumerator();
                        const allItems: Array<any> = [];
                        const allTerms: Array<SP.Taxonomy.Term> = [];

                        while (enumerator.moveNext()) {
                            allTerms.push(enumerator.get_current());
                        }

                        enumerator.reset();

                        while (enumerator.moveNext()) {
                            const currentTerm = enumerator.get_current();
                            const currentTermPath: string[] = currentTerm.get_pathOfTerm().split(';');
                            let requestedTerm: ITermItem;
                            requestedTerm = new TermItem(currentTermPath[currentTermPath.length - 1]);

                            requestedTerm.name = currentTerm.get_name(); //set this in case we don't have labels or find any.
                            requestedTerm.id = currentTerm.get_id().toString();
                            requestedTerm.key = c.columnName;
                            requestedTerm.description = currentTerm.get_description();
                            requestedTerm.isExpanded = true;
                            if (currentTerm.get_customProperties()['AVA.DisplayForAll'] !== undefined) {
                                requestedTerm.displayForAll = currentTerm.get_customProperties()['AVA.DisplayForAll'].toLowerCase() == 'yes';
                            } else {
                                requestedTerm.displayForAll = false;
                            }

                            allItems.push(requestedTerm);

                        }
                        enumerator.reset();

                        while (enumerator.moveNext()) {
                            const currentTerm: SP.Taxonomy.Term = enumerator.get_current();
                            const currentTermPath: string[] = currentTerm.get_pathOfTerm().split(';');

                            // find the corresponding item
                            const item = allItems.filter((f) => {
                                return f.id === currentTerm.get_id().toString();
                            })[0];

                            if (item !== undefined) {
                                if (currentTermPath.length === 1) {
                                    // top level item
                                    requestedTerms.links.push(item);
                                } else {
                                    // find parent;
                                    const parentTerm = this.getParentTerm(currentTerm, allTerms);
                                    const parentItem = allItems.filter((s) => {
                                        return s.id == parentTerm.get_id().toString();
                                    })[0];
                                    if (parentItem !== undefined) {
                                        parentItem.links.push(item);
                                    }
                                }
                            }
                        }
                        // do the callback dance
                        TermSetObj.terms = requestedTerms;
                        callback(TermSetObj);
                    },
                    (sender: any, args: any) => {
                        failCallback('Failed to execute Taxonomy query');
                        return;
                    });

            });
        });
    }

    /**
     * Common method to get all terms from a termset
     * @param callback 
     * @param failCallback 
     */
    public getAllTaxonomyTerms(callback: (m: any) => any, failCallback?: (err: string) => void) {
        let allLevels: any = [];
        JsomLoader.LoadJsom().then(() => {
            JsomLoader.LoadAdditionalJsomScript('/_layouts/15/SP.taxonomy.js', 'SP').then(() => {

                const c: ITermSetConfig = this.config;
                const ctx: SP.ClientContext = window.location.pathname.indexOf('.aspx') > -1 ?
                    SP.ClientContext.get_current() :
                    new SP.ClientContext(window.location.pathname); // workaround for bug reported in https://github.com/SharePoint/sp-dev-docs/issues/1415

                const taxonomySession: SP.Taxonomy.TaxonomySession = SP.Taxonomy.TaxonomySession.getTaxonomySession(ctx),
                    termStore: SP.Taxonomy.TermStore = taxonomySession.getDefaultSiteCollectionTermStore(),
                    termSet: SP.Taxonomy.TermSet = termStore.getTermSet(new SP.Guid(c.id)),
                    terms: SP.Taxonomy.TermCollection = termSet.getAllTerms();

                ctx.load(terms, 'Include(Id, Name, PathOfTerm, Description, LocalCustomProperties, CustomProperties)');
                ctx.executeQueryAsync(
                    (sender: any, args: any) => {
                        const termsObj = { items: [], maxLevel: 0 };
                        const enumerator: IEnumerator<SP.Taxonomy.Term> = terms.getEnumerator();
                        const allItems: Array<any> = [];
                        const allTerms: Array<SP.Taxonomy.Term> = [];

                        while (enumerator.moveNext()) {
                            allTerms.push(enumerator.get_current());
                        }

                        enumerator.reset();

                        while (enumerator.moveNext()) {
                            const currentTerm = enumerator.get_current();
                            const currentTermPath: string[] = currentTerm.get_pathOfTerm().split(';');
                            let requestedTerm: ITermItem;
                            requestedTerm = new TermItem(currentTermPath[currentTermPath.length - 1]);

                            requestedTerm.name = currentTerm.get_name(); //set this in case we don't have labels or find any.
                            requestedTerm.id = currentTerm.get_id().toString();
                            requestedTerm.key = c.columnName;
                            requestedTerm.description = currentTerm.get_description();
                            requestedTerm.level = currentTerm.get_pathOfTerm().split(';').length;
                            if (allLevels.indexOf(requestedTerm.level) == -1)
                                allLevels.push(requestedTerm.level);

                            allItems.push(requestedTerm);

                        }
                        enumerator.reset();

                        while (enumerator.moveNext()) {
                            const currentTerm: SP.Taxonomy.Term = enumerator.get_current();
                            const currentTermPath: string[] = currentTerm.get_pathOfTerm().split(';');

                            // find the corresponding item
                            const item = allItems.filter((f) => {
                                return f.id === currentTerm.get_id().toString();
                            })[0];

                            if (item !== undefined) {
                                if (currentTermPath.length === 1) {
                                    // top level item
                                    termsObj.items.push(item);
                                } else {
                                    // find parent;
                                    const parentTerm = this.getParentTerm(currentTerm, allTerms);
                                    const parentItem = allItems.filter((s) => {
                                        return s.id == parentTerm.get_id().toString();
                                    })[0];
                                    if (parentItem !== undefined) {
                                        parentItem.items.push(item);
                                    }
                                }
                            }
                        }
                        termsObj.maxLevel = Math.max( ...allLevels);
                        // do the callback dance
                        callback(termsObj);
                    },
                    (sender: any, args: any) => {
                        failCallback('Failed to execute Taxonomy query');
                        return;
                    });

            });
        });
    }

    /**
     * Get the parent term of the passed term
     * @param term Term whose parent term is to be found
     * @param terms All terms to look from for the parent term
     */
    private getParentTerm(term: SP.Taxonomy.Term, terms: SP.Taxonomy.Term[]): SP.Taxonomy.Term {
        const pathOfTerm = term.get_pathOfTerm();
        const parentPath = pathOfTerm.substr(0, pathOfTerm.lastIndexOf(';'));
        return terms.filter(t => {
            return t.get_pathOfTerm() === parentPath;
        })[0];
    }
}
import { AppInsightsService } from '../../framework/services/AppInsightsService';
import { ICache } from '../../hwlibcore/cache/ICache';
import { LocalStorageCache } from '../../hwlibcore/cache/LocalStorageCache';
import { Utilities, Intervals } from '../../hwlibcore/sp/Utilities';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient } from '@microsoft/sp-http';
import { ServiceScope } from '@microsoft/sp-core-library';
import { PageContext } from '@microsoft/sp-page-context';
import { JsomLoader } from '../../hwlibcore/sp/JsomLoader';
import { UrlUtilites } from '../../hwlibcore/sp/UrlUtilities';

export interface IUserProfile {
    AccountName: string;
    DirectReports: string[];
    DisplayName: string;
    Email: string;
    ExtendedManagers: string[];
    ExtendedReports: string[];
    IsFollowed: boolean;
    LatestPost: any;
    Peers: string[];
    PersonalUrl: string;
    PictureUrl: string;
    Title: string;
    UserProfileProperties: IUserProfileProperty[];
    UserUrl: string;
}
export interface IUserProfileProperty {
    Key: string;
    Value: string;
    ValueType: string;
}

const CACHE_NAME = `IUserProfile`;


export class UserProfileService {
    private static _cache: ICache = new LocalStorageCache();
    public static MyProfile(serviceScope: ServiceScope, context: WebPartContext): Promise<IUserProfile> {
        return new Promise<IUserProfile>((resolve, reject) => {
            if (this._cache.exists(CACHE_NAME)) {
                resolve(<IUserProfile>JSON.parse(this._cache.get(CACHE_NAME)));
            } else {
                const cache = this._cache;
                context.spHttpClient.get(
                    `${context.pageContext.web.absoluteUrl}/_api/SP.UserProfiles.PeopleManager/GetMyProperties`,
                    SPHttpClient.configurations.v1,
                    {}).then(response => {
                        response.json().then((data: IUserProfile) => {
                            cache.add(
                                CACHE_NAME,
                                JSON.stringify(data),
                                Utilities.dateAdd(new Date(), Intervals.Second, 30));
                            resolve(data);
                        });
                    }).catch(err => {
                        AppInsightsService.trackException(serviceScope, err);
                        reject(err);
                    });
            }
        });
    }

    public static MyProfilePageContext(serviceScope: ServiceScope, pageContext: PageContext): Promise<IUserProfile> {
        return this.myProfile(serviceScope, pageContext.site.absoluteUrl);
    }

    public static MyProfileServiceScope(serviceScope: ServiceScope): Promise<IUserProfile> {
        return this.myProfile(serviceScope, UrlUtilites.getCurrentAbsoluteSiteUrl());
    }

    private static myProfile(serviceScope: ServiceScope, absoluteUrl: string) {
        return new Promise<IUserProfile>((resolve, reject) => {
            if (this._cache.exists(CACHE_NAME)) {
                resolve(<IUserProfile>JSON.parse(this._cache.get(CACHE_NAME)));
            } else {
                const cache = this._cache;
                const client = new SPHttpClient(serviceScope as any);
                client.fetch(
                    `${absoluteUrl}/_api/SP.UserProfiles.PeopleManager/GetMyProperties`,
                    SPHttpClient.configurations.v1,
                    {}).then(response => {
                        response.json().then((data: IUserProfile) => {
                            cache.add(
                                CACHE_NAME,
                                JSON.stringify(data),
                                Utilities.dateAdd(new Date(), Intervals.Second, 30));
                            resolve(data);
                        });
                    }).catch(err => {
                        AppInsightsService.trackException(serviceScope, err);
                        reject(err);
                    });
            }
        });
    }



    public static GetPictureUrl(profile: IUserProfile, size: 'S' | 'M' | 'L'): string {
        return UserProfileService.GetPictureUrlByEmail(profile.Email, size);
    }
    public static GetPictureUrlByEmail(email: string, size: 'S' | 'M' | 'L'): string {
        return `/_layouts/15/userphoto.aspx?size=${size}&accountname=${email}`;
    }

    public static UpdateProfileProperty(absoluteUrl: string, propertyName: string, propertyValue: any): Promise<{}> {
        return JsomLoader.LoadJsom().then(() => {
            return JsomLoader.LoadAdditionalJsomScript('/_layouts/15/sp.userprofiles.js', 'SP').then(() => {
                return new Promise<{}>((resolve, reject) => {
                    const clientContext = new SP.ClientContext(absoluteUrl);
                    const peopleManager = new SP.UserProfiles.PeopleManager(clientContext);
                    const userProfileProperties = peopleManager.getMyProperties();
                    clientContext.load(userProfileProperties, 'AccountName');
                    clientContext.executeQueryAsync((s: any, e: any) => {
                        const currentUserAccountName = userProfileProperties.get_accountName();
                        // INFO: cast to any, since the sharepoint.d.ts is not updated with the setSingleValueProfileProperty method
                        if (Array.isArray(propertyValue)) {
                            (<any>peopleManager).setMultiValuedProfileProperty(currentUserAccountName, propertyName, propertyValue);
                        } else {
                            (<any>peopleManager).setSingleValueProfileProperty(currentUserAccountName, propertyName, propertyValue);
                        }
                        clientContext.executeQueryAsync((s1: any, e1: any) => {
                            const cache = this._cache;
                            cache.delete(CACHE_NAME);
                            resolve(undefined);
                        }, (s2: any, e2: any) => {
                            reject('Request failed. ' + e2.get_message() + '\n' + e2.get_stackTrace());
                        });
                    }, (s3: any, e3: any) => {
                        reject('Request failed. ' + e3.get_message() + '\n' + e3.get_stackTrace());
                    });
                });
            });
        });
    }
}

import * as DOMPurify from 'dompurify';
export class SecureMarkupService {

    /**
     * Method to convert input HTML to secure HTML using DOMPurify
     * @param inputHtml HTML given in handlebar or code editor
     */
    public static GetSecureOutputUsingDOMPurify(inputHtml: string): string {
        let config = { ADD_TAGS: ['#comment', 'iframe'], ADD_ATTR: ['target'], FORCE_BODY: true };
        if (DOMPurify.isSupported) {
            let sanitizedHTML = DOMPurify.sanitize(inputHtml, config);
            return sanitizedHTML;
        } else {
            throw new Error("Unsupported browser");
        }
    }
}
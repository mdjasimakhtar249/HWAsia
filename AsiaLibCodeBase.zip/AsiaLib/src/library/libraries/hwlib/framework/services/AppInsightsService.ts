import { ServiceScope, ServiceKey } from '@microsoft/sp-core-library';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import { IAppInsightsSettings, IHWConfiguration } from "./IHWConfiguration";
import { PageContext } from "@microsoft/sp-page-context";
import { IStorageEntityBaseService } from "./storageEntityBaseService";
import { HWConfigServiceKey } from "./configurationService";
import { Log } from '@microsoft/sp-core-library';
import * as Common from "@microsoft/applicationinsights-common";
import { SeverityLevel } from '@microsoft/applicationinsights-common';

export interface IAppInsightsService {
    initialize(key: string, settings: IAppInsightsSettings, accountId: string);
    appInsights: ApplicationInsights;
}

const LOG_SOURCE: string = "HW: AppInsightsService";

export class AppInsightsService implements IAppInsightsService {
    private initialized: boolean;
    public static readonly ServiceKey: ServiceKey<IAppInsightsService> = ServiceKey.create<IAppInsightsService>('DEEJS:AppInsightsService', AppInsightsService);
    public appInsights: ApplicationInsights;
    /**
    * Constructor for AppInsightsService class
    * @param serviceScope 
    */
    constructor(serviceScope: ServiceScope) {
        this.initialized = false;
    }

    /**
     * Method to initialize the app insights object
     * @param key App insights instrumentation key
     * @param settings App insights settings 
     * @param accountId Account id
     */
    public initialize(key: string, settings: IAppInsightsSettings, accountId: string) {

        if (!this.initialized) {
            if (settings == undefined) {
                settings = {};
            }

            this.appInsights = new ApplicationInsights({
                config: {
                    instrumentationKey: key,
                    autoTrackPageVisitTime: settings.autoTrackPageVisitTime || true,
                    enableDebug: settings.enableDebug || false,
                    disableAjaxTracking: settings.disableAjaxTracking || true,
                    maxAjaxCallsPerView: settings.maxAjaxCallsPerView || 0,
                    samplingPercentage: settings.samplingPercentage || 100,
                    accountId: settings.doNotTrackUsers ? undefined : accountId
                }
            });
            this.appInsights.loadAppInsights();
        }
        this.initialized = true;
    }

    /**
     * Method to log metrics to app insights only if an app insights key is found in the configuration object
     * @param name Metric name
     * @param average Metric average
     * @param sampleCount Metric sample count
     * @param min Metric minimum
     * @param max Metric maximum
     * @param properties Other properties for metric
     */
    public static trackMetric(serviceScope: ServiceScope, name: string, average: number, sampleCount?: number, min?: number, max?: number, properties?: { [name: string]: string }) {
        try {
            let appInsightObj: ApplicationInsights = serviceScope.consume(AppInsightsService.ServiceKey).appInsights;
            if (appInsightObj != undefined && appInsightObj != null) {
                let metric: Common.IMetricTelemetry = {
                    name: name,
                    average: average,
                    sampleCount: sampleCount,
                    min: min,
                    max: max,
                };
                appInsightObj.trackMetric(metric, properties);
            }
        }
        catch (ex) {
            Log.error(LOG_SOURCE, ex, serviceScope);
        }
    }

    /**
     * Method to log event to app insights only if an app insights key is found in the configuration object
     * @param name Event name
     * @param properties Event properties
     * @param measurements Event measurements
     */
    public static trackEvent(serviceScope: ServiceScope, name: string, properties?: { [name: string]: string }, measurements?: { [name: string]: number }) {
        try {
            let appInsightObj: ApplicationInsights = serviceScope.consume(AppInsightsService.ServiceKey).appInsights;
            if (appInsightObj != undefined && appInsightObj != null) {
                let event: Common.IEventTelemetry = { name: name };
                // invoke trackMetric method if measurements value exist
                if (measurements != undefined && Object.keys(measurements).length > 0) {
                    for (let i = 0; i < Object.keys(measurements).length; i++) {
                        appInsightObj.trackMetric({ name: name + "." + Object.keys(measurements)[i], average: Object.values(measurements)[i] });
                    }
                }
                appInsightObj.trackEvent(event, properties);
            }
        }
        catch (ex) {
            Log.error(LOG_SOURCE, ex, serviceScope);
        }
    }

    /**
     * Method to log exceptions to app insights only if an app insights key is found in the configuration object
     * @param exception Error object to be logged
     * @param handledAt Handled at
     * @param properties Exception properties
     * @param measurements Exception measurements
     * @param severityLevel Exception security level
     */
    public static trackException(serviceScope: ServiceScope, exception: Error, handledAt?: string, properties?: { [name: string]: string }, measurements?: { [name: string]: number }, severityLevel?: SeverityLevel | number | string) {
        try {
            let appInsightObj: ApplicationInsights = serviceScope.consume(AppInsightsService.ServiceKey).appInsights;
            if (appInsightObj != undefined && appInsightObj != null) {
                if (typeof (severityLevel) == "string") {
                    severityLevel = parseInt(severityLevel);
                }
                let exceptionObj: Common.IExceptionTelemetry = {
                    exception: exception,
                    severityLevel: severityLevel
                };
                // invoke trackMetric method if measurements value exist
                if (measurements != undefined && Object.keys(measurements).length > 0) {
                    for (let i = 0; i < Object.keys(measurements).length; i++) {
                        appInsightObj.trackMetric({ name: name + "." + Object.keys(measurements)[i], average: Object.values(measurements)[i] });
                    }
                }
                appInsightObj.trackException(exceptionObj);
            }
        }
        catch (ex) {
            Log.error(LOG_SOURCE, ex, serviceScope);
        }
    }
    /** Method to track  page views in app insights   
     * @param serviceScope the service scope
     * @param pageView curent pageView    
     */
    public static trackPageView(serviceScope: ServiceScope, pageView?: Common.IPageViewTelemetry) {
        try {
            let appInsightObj: ApplicationInsights = serviceScope.consume(AppInsightsService.ServiceKey).appInsights;
            if (appInsightObj != undefined && appInsightObj != null) {
                appInsightObj.trackPageView(pageView);
            }
        }
        catch (ex) {
            Log.error(LOG_SOURCE, ex, serviceScope);
        }
    }

    /**
     * Method to manually trigger an immediate send of all telemetry still in the buffer.
     * @param serviceScope 
     */
    public static flush(serviceScope: ServiceScope) {
        try {
            let appInsightObj: ApplicationInsights = serviceScope.consume(AppInsightsService.ServiceKey).appInsights;
            if (appInsightObj != undefined && appInsightObj != null) {
                appInsightObj.flush();
            }
        } catch (ex) {
            Log.error(LOG_SOURCE, ex, serviceScope);
        }
    }

    /**
     * Method to use in Application customizers to invoke the service and set up AppInsights
     * @param serviceScope the service scope
     * @param pageContext the current page context
     */
    public static InitializeTelemetry(serviceScope: ServiceScope, pageContext: PageContext): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            serviceScope.whenFinished(() => {
                // load settings            
                const settings: IStorageEntityBaseService<IHWConfiguration> = serviceScope.consume(HWConfigServiceKey);
                settings.load().then(() => {
                    // initialize AppInsights
                    const svc: IAppInsightsService = serviceScope.consume(AppInsightsService.ServiceKey);
                    svc.initialize(
                        settings.settings().appInsightsKey!,
                        settings.settings().appInsightsSettings!,
                        pageContext.user.loginName
                    );
                    resolve();
                });
            });
        });
    }
}
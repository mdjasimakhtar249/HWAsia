export interface IBootstrapProvider {
    provider: string;
    providerScript?: string;
    providerSettings?: string;
}
export interface ITopbarConfiguration extends IBootstrapProvider {
    flyout: IFlyoutConfiguration;
    search: ISearchBoxConfiguration;
    renderer: IBootstrapProvider;
    hideHeaderSites?: string[];
    hideFeedbackButtons?: boolean;
    displayAlerts?: boolean;
    showSearchBar?: boolean;
}
export interface IFooterConfiguration extends IBootstrapProvider {
}
export interface IFlyoutConfiguration extends IBootstrapProvider {
    addFeatureEnabled?: boolean;
}
export interface ISearchVerticalSetting extends IBootstrapProvider {
    title: string;
}

export interface ISearchBoxConfiguration extends IBootstrapProvider {
    verticals: ISearchVerticalSetting[];
}

export interface IProtectedSettingsConfiguration {
    enableCodeEditor: boolean;
}

export interface IAppInsightsSettings {
    doNotTrackUsers?: boolean;
    autoTrackPageVisitTime?: boolean;
    enableDebug?: boolean;
    verboseLogging?: boolean;
    samplingPercentage?: number;
    disableAjaxTracking?: boolean;
    maxAjaxCallsPerView?: number;
}
export interface IHWConfiguration {
    cdn: string;
    template: string;
    appInsightsKey?: string;
    appInsightsSettings?: IAppInsightsSettings;
    aadAppId?: string;
    topbar?: ITopbarConfiguration;
    footer?: IFooterConfiguration;
    devMode?: boolean;
    services?: any; // add any config here 
    protectedSettings?: IProtectedSettingsConfiguration[];
    alwaysReadGlobalConfig?: boolean;
    templateFolderName: string;
}

import { ServiceScope } from '@microsoft/sp-core-library';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
import {
  IPropertyPaneDropdownOption,
  PropertyPaneCheckbox
} from '@microsoft/sp-property-pane';

import {
  SPHttpClient,
  ISPHttpClientOptions,
  SPHttpClientResponse
} from '@microsoft/sp-http';

import { AppInsightsService } from '../../framework/services/AppInsightsService';

export interface IListsService {
  getListNames(defaultKey: string, listTemplate: string, siteCollectionUrl?: string): Promise<IPropertyPaneDropdownOption[]>;
  getListColumnNames(listId: string, siteCollectionUrl?: string, filterQuery?: string): Promise<IColumnObject>;
  getFilesFromFolder(siteAbsoluteUrl: string, folderServerRelativeUrl: string, defaultKey: string): Promise<IPropertyPaneDropdownOption[]>;
  checkUserPermissions(serverRelativeUrl: string);
  checkIfListExist(listName: string): Promise<boolean>;
  getListItemEntityTypeName(listName: string): Promise<string>;
  getListData(listName: string, filter: string): Promise<any>;
  addListItem(listName: string, data: any): Promise<any>;
  updateListItem(listName: string, itemID: string, data: any): Promise<any>;
  deleteListItem(listName: string, itemID: string): Promise<any>;
}

export interface IArrayHelper {
  sortByKey(array: Object[], key: string): Object[];
}
export class ArrayHelper implements IArrayHelper {
  constructor() {
  }

  //return a new array that is sorted by the object key of an array of objects
  public sortByKey(array: Object[], key: string) {
    return array.sort((a: any, b: any) => {
      var x = a[key]; var y = b[key];
      return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
  }
}

export interface IColumnObject {
  dynamicProps: Array<object>;
  columnInternalNames: Array<object>;
}

export interface IListItem {
  Title: string;
  Description: string;
  Id: number;
}

const headerObj = {
  'Accept': 'application/json;odata=nometadata',
  'odata-version': ''
};

/**
 * Class that has all list related methods
 */
export class ListsService implements IListsService {
  public columnObject: IColumnObject = {
    dynamicProps: [],
    columnInternalNames: []
  };

  private _arrayHelper: ArrayHelper = new ArrayHelper();

  public constructor(private context: IWebPartContext, private serviceScope: ServiceScope) {

  }

  /**
   * Get lists from the web of any specific template or get all by passing empty string as listTemplate
   * @param defaultKey 
   * @param listTemplate List or library template
   */
  public getListNames(defaultKey: string, listTemplate: string, siteCollectionUrl?: string): Promise<IPropertyPaneDropdownOption[]> {
    let filterQuery = "";
    try {
      if (listTemplate != "") {
        filterQuery = "$filter=(BaseTemplate eq " + listTemplate + ")and(Hidden ne true)";
      }
      else {
        filterQuery = "$filter=Hidden ne true";
      }
      let url = (siteCollectionUrl == "" || siteCollectionUrl == undefined) ? this.context.pageContext.web.absoluteUrl : siteCollectionUrl;
      return this.context.spHttpClient.get(url + `/_api/Lists/?$select=Id,Title&${filterQuery}&$orderby Title`, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          var options: Array<IPropertyPaneDropdownOption> = new Array<IPropertyPaneDropdownOption>();

          return response.json().then((data) => {
            options.push({ key: "SelectList", text: defaultKey });
            data.value.forEach((list: any) => {
              options.push({ key: list.Id, text: list.Title });
            });
            return options;
          });
        });
    }
    catch (err) {
      AppInsightsService.trackException(this.serviceScope, err);
      throw err;
    }
  }

  /**
   * Get columns from the selected list
   * @param listId Id of the list from which the columns need to be fetched
   * @param filterQuery Filter query for GET request e.g, "Hidden eq false and ReadOnlyField eq false"
   */
  public getListColumnNames(listId: string, siteCollectionUrl?: string, filterQuery: string = ""): Promise<IColumnObject> {
    try {
      let url = (siteCollectionUrl == "" || siteCollectionUrl == undefined) ? this.context.pageContext.web.absoluteUrl : siteCollectionUrl;
      return this.context.spHttpClient.get(url + `/_api/web/lists(guid'` + listId + `')/fields?$select=Id,Title,InternalName&$filter=${filterQuery}`, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          return response.json().then((data) => {
            data.value = this._arrayHelper.sortByKey(data.value, 'Title');
            //Create checkboxes for all the columns returned
            data.value.forEach((column: any) => {
              this.columnObject.dynamicProps.push(
                PropertyPaneCheckbox(column.Id,
                  {
                    checked: false,
                    text: column.Title,
                  })
              );
              this.columnObject.columnInternalNames.push({ type: column['@odata.type'], key: column.Title, value: column.InternalName });
            });
            return this.columnObject;
          });
        });
    }
    catch (err) {
      AppInsightsService.trackException(this.serviceScope, err);
      throw err;
    }
  }

  /**
   * Get files from a folder whose server relative url is passed
   * @param siteAbsoluteUrl Site url from which the files need to be fetched
   * @param folderServerRelativeUrl Folder server relative url from which the files need to be fetched
   * @param defaultKey
   */
  public getFilesFromFolder(siteAbsoluteUrl: string, folderServerRelativeUrl: string, defaultKey: string = ""): Promise<IPropertyPaneDropdownOption[]> {
    try {
      return this.context.spHttpClient.get(`${siteAbsoluteUrl}/_api/web/GetFolderByServerRelativeUrl('${folderServerRelativeUrl}')/Files`, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          var options: Array<IPropertyPaneDropdownOption> = new Array<IPropertyPaneDropdownOption>();
          return response.json().then((data) => {
            if (defaultKey != null) {
              options.push({ key: "SelectTemplate", text: defaultKey });
            }
            data.value.forEach((template: { Name: any; }) => {
              options.push({ key: template.Name, text: template.Name });
            });
            return options;
          });
        });
    }
    catch (err) {
      AppInsightsService.trackException(this.serviceScope, err);
      throw err;
    }
  }

  /**
   * Method to check if user has write access to the passed folder
   * @param serverRelativeUrl Server relative url for the folder
   */
  public checkUserPermissions(serverRelativeUrl: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + `/_api/web/GetFolderByServerRelativeUrl('${serverRelativeUrl}')/ListItemAllFields/effectiveBasePermissions`, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          response.json().then((responseJSON: any) => {
            let perms = new SP.BasePermissions;
            perms.fromJson(responseJSON);
            //True if user has permission to edit folder else false
            resolve(perms.has(SP.PermissionKind.editListItems));
          });
        }).catch((err) => {
          AppInsightsService.trackException(this.serviceScope, err);
          reject(err);
        });
    });
  }

  /**
   * Method to check if list passed as parameter exists in the current site
   * @param listName Name of the list
   */
  public checkIfListExist(listName: string): Promise<boolean> {
    try {
      return this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + `/_api/web/lists/GetByTitle('${listName}')`, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          if (response.status == 404)
            return false;
          else
            return true;
        });
    }
    catch (err) {
      AppInsightsService.trackException(this.serviceScope, err);
      throw err;
    }
  }

  /// <summary>
  // Get Data From Sharepoint List
  /// <param name="listName">Name Of SP List</param>
  /// <param name="filter">Filter to be passed to Api Url </param>
  /// <summary>
  public getListData(listName: string, filter: string): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      this.context.spHttpClient.get(this.context.pageContext.web.absoluteUrl + "/_api/web/lists/GetByTitle('" + listName + "')/Items" + filter, SPHttpClient.configurations.v1).then(listData => {
        return listData.json().then((listDataJson) => {
          resolve(listDataJson);
        });
      }).catch(err => {
        reject(err);
        AppInsightsService.trackException(this.serviceScope, err);
      });
    });
  }

  /// <summary>
  /// Method To Add List Item to SP List Using PnP
  /// <param name="listName">Sharepoint List Name where Add Opertaion Is To Be Performed</param>
  /// <param name="data">List Item Data To Be Updated/param>
  /// <summary>
  public addListItem(listName: string, data: any): Promise<any> {
    let httpClientOptions: ISPHttpClientOptions = {};
    return new Promise<{}>((resolve, reject: (error: any) => void): void => {
      let listItemEntityTypeName: string | undefined = undefined;

      this.getListItemEntityTypeName(listName)
        .then((itemEntityTypeName: string): Promise<any> => {
          listItemEntityTypeName = itemEntityTypeName;

          let newListItem: string = JSON.stringify({
            '__metadata': { 'type': listItemEntityTypeName },
            'Title': `${this.context.pageContext.legacyPageContext.userId}`,
            'UserDashboardDetails': JSON.stringify(data),
            'DashboardUserId': this.context.pageContext.legacyPageContext.userId
          });

          httpClientOptions.headers = {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=verbose',
            'odata-version': ''
          };
          httpClientOptions.body = newListItem;
          const client: SPHttpClient = this.context.spHttpClient;

          return client.post(this.context.pageContext.web.serverRelativeUrl + `/_api/web/lists/getbytitle('${listName}')/items`,
            SPHttpClient.configurations.v1,
            httpClientOptions
          );
        })
        .then((response: SPHttpClientResponse): void => {
          if (response.ok) {
            resolve(response);
          }
          else {
            reject(response.statusText);
          }
        }, (error: any): void => {
          reject(error);
        });
    });
  }

  /// <summary>
  /// Method To Update List Item in SP List Using PnP
  /// <param name="listName">Sharepoint List Name where Update Opertaion Is To Be Performed</param>
  /// <param name="itemID">List ItemID To Be Updated/param>
  /// <param name="data">List Item Data To Be Updated/param>
  /// <summary>
  public updateListItem(listName: string, itemID: string, data: any): Promise<any> {
    let httpClientOptions: ISPHttpClientOptions = {};
    return new Promise<{}>((resolve, reject: (error: any) => void): void => {
      let listItemEntityTypeName: string | undefined = undefined;
      let etag: string | undefined | null = undefined;
      const client: SPHttpClient = this.context.spHttpClient;
      this.getListItemEntityTypeName(listName)
        .then((itemEntityTypeName: string): Promise<SPHttpClientResponse> => {
          listItemEntityTypeName = itemEntityTypeName;

          httpClientOptions.headers = headerObj;


          return client.get(this.context.pageContext.web.serverRelativeUrl + `/_api/web/lists/getByTitle('${listName}')/items(${itemID})?$select=UserDashboardDetails,ID`,
            SPHttpClient.configurations.v1,
            httpClientOptions
          );
        })
        .then((response: SPHttpClientResponse): Promise<SPHttpClientResponse> => {
          etag = response.headers.get('ETag');
          const body: string = JSON.stringify({
            '__metadata': {
              'type': listItemEntityTypeName
            },
            'UserDashboardDetails': JSON.stringify(data)
          });
          let checkHeaderObj: any = httpClientOptions.headers;
          if (checkHeaderObj != undefined) {
            checkHeaderObj = {
              'Accept': 'application/json;odata=nometadata',
              'Content-type': 'application/json;odata=verbose',
              'odata-version': '3.0',
              'IF-MATCH': etag,
              'X-HTTP-Method': 'MERGE'
            };
          }
          httpClientOptions.headers = checkHeaderObj;
          httpClientOptions.body = body;

          return client.post(this.context.pageContext.web.serverRelativeUrl + `/_api/web/lists/getbytitle('${listName}')/items(${itemID})`,
            SPHttpClient.configurations.v1,
            httpClientOptions
          );
        })
        .then((response: SPHttpClientResponse): void => {
          if (response.ok) {
            resolve(response);
          }
          else {
            reject(response.statusText);
          }
        }, (error: any): void => {
          AppInsightsService.trackException(this.serviceScope, error);
          reject(error);
        });
    });
  }

  /// <summary>
  /// Method To Delete List Item in SP List Using PnP
  /// <param name="listName">Sharepoint List Name where Delete Opertaion Is To Be Performed</param>
  /// <param name="itemID">List ItemID To Be Deleted/param>
  /// <summary>
  public deleteListItem(listName: string, itemID: string): Promise<any> {
    let httpClientOptions: ISPHttpClientOptions = {};
    return new Promise<{}>((resolve, reject: (error: any) => void): void => {
      let etag: string | undefined | null = undefined;
      const client: SPHttpClient = this.context.spHttpClient;
      this.getListItemEntityTypeName(listName)
        .then((itemEntityTypeName: string): Promise<SPHttpClientResponse> => {
          httpClientOptions.headers = headerObj;

          return client.get(this.context.pageContext.web.serverRelativeUrl + `/_api/web/lists/getByTitle('${listName}')/items(${itemID})?$select=UserDashboardDetails,ID`,
            SPHttpClient.configurations.v1,
            httpClientOptions
          );
        })
        .then((response: SPHttpClientResponse): Promise<IListItem> => {
          etag = response.headers.get('ETag');
          return response.json();
        })
        .then((listItem: IListItem): Promise<SPHttpClientResponse> => {

          let checkHeaderObj: any = httpClientOptions.headers;
          if (checkHeaderObj != undefined) {
            checkHeaderObj = {
              'Accept': 'application/json;odata=nometadata',
              'Content-type': 'application/json;odata=verbose',
              'odata-version': '3.0',
              'IF-MATCH': etag,
              'X-HTTP-Method': 'DELETE'
            };
          }
          httpClientOptions.headers = checkHeaderObj;

          return client.post(this.context.pageContext.web.serverRelativeUrl + `/_api/web/lists/getbytitle('${listName}')/items(${listItem.Id})`,
            SPHttpClient.configurations.v1,
            httpClientOptions
          );
        })
        .then((response: SPHttpClientResponse): void => {
          if (response.ok) {
            //resolve(); /////TEST
            resolve(response);
          }
          else {
            reject(response.statusText);
          }
        }, (error: any): void => {
          AppInsightsService.trackException(this.serviceScope, error);
          reject(error);
        });
    });
  }

  /**
     * Get the list item entity type name for a list
     * @param {string} listName Title of the list
     * @returns {Promise<string>} List item entity type name for the list
     */
  public getListItemEntityTypeName(listName: string): Promise<string> {
    let httpClientOptions: ISPHttpClientOptions = {};
    headerObj["odata-version"] = '3.0';
    httpClientOptions.headers = headerObj;

    return new Promise<string>((resolve: (listItemEntityTypeName: string) => void, reject: (error: any) => void): void => {
      const client: SPHttpClient = this.context.spHttpClient;
      client.post(this.context.pageContext.web.serverRelativeUrl + `/_api/web/lists/getByTitle('${listName}')?$select=ListItemEntityTypeFullName`,
        SPHttpClient.configurations.v1,
        httpClientOptions
      )
        .then((response: SPHttpClientResponse): Promise<{ ListItemEntityTypeFullName: string }> => {
          return response.json();
        })
        .then((response: { ListItemEntityTypeFullName: string }): void => {
          resolve(response.ListItemEntityTypeFullName);
        }, (error: any): void => {
          reject(error);
        });
    });
  }
}
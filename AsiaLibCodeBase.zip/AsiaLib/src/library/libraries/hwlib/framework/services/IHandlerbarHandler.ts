import * as Handlebars from 'handlebars';

export interface IHandlerbarHandler {
    /**
     * Allows to register Handlebars customizations like helpers or partials in the current Web Part Handlebars isolated namespace
     * @param hbs the current Web Part Handlebars namespace
     */

    register?: (hbs: typeof Handlebars) => void;
}


export interface IHandlerbarHandlerConfig {
    // Id of the component (guid - library manifest id)
    componentId : string;
    //  Name of the component (string - Classname)
    componentName : string;
}


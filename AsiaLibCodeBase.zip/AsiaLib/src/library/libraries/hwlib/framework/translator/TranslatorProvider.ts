
import { IHttpClientOptions, HttpClient, HttpClientResponse } from '@microsoft/sp-http';
import { AppInsightsService } from '../services/AppInsightsService';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { ServiceScope } from '@microsoft/sp-core-library';
import { Utilities, Intervals } from '../../hwlibcore/sp/Utilities';
import { ICache } from '../../hwlibcore/cache/ICache';

export class TranslatorProvider {
    private translateAPIUrl: string = "";

    constructor(private context: WebPartContext, private serviceScope: ServiceScope) {
    }

    /**
     * Gets the set of languages supported for operations of Translator Text API.
     */

    public getAllLanguages(): Promise<any> {
        return new Promise((resolve, reject) => {
            this.translateAPIUrl = "https://api.cognitive.microsofttranslator.com/languages?api-version=3.0&scope=translation";
            try {
                AppInsightsService.trackEvent(this.serviceScope, 'Ava:GetLanguagesTranslatorWebPart');
                let requestHeaders = new Headers();
                const requestGetOptions: IHttpClientOptions = {
                    method: "GET",
                    headers: requestHeaders
                };
                this.context.httpClient.get(
                    this.translateAPIUrl,
                    HttpClient.configurations.v1,
                    requestGetOptions)
                    .then((response: HttpClientResponse) => {
                        if (response.status == 200) {
                            response.json().then((alllanguages: any) => {
                                resolve(alllanguages);
                            }).catch(err => {
                                AppInsightsService.trackException(this.serviceScope, err.message);
                                reject(err);
                            });
                        } else {
                            reject(`Error ${response.status} ${response.statusText} when fetching the language data.`);
                        }
                    }).catch(err => {
                        AppInsightsService.trackException(this.serviceScope, err);
                        reject(err);
                    });
            }
            catch (err) {
                AppInsightsService.trackException(this.serviceScope, err);
                throw err;
            }
        });
    }

    /**
     * API call to translates Text.
     * @param getSourceContent: takes inner html in a source language.
     * @param fromLanguage : by default it will be english or autodetected in case of "Auto Detect" toggle is on. 
     * @param toLanguage : specifies the language of the output text. The target language selected from Language dropdown.
     * @param translateTextApiKey : required authentication key to send request.     *
     */

    public getTranslatedText(getSourceContent: any[], fromLanguage: string, toLanguage: string, translateTextApiKey: string, region?: string, categoryId?: string): Promise<any> {
        AppInsightsService.trackEvent(this.serviceScope, 'Ava:TranslatesTextTranslatorWebPart', { 'fromLanguage': fromLanguage, 'toLanguage': toLanguage });
        categoryId = (categoryId != "" && categoryId != undefined) ? "&category=" + categoryId : "";
        let httpClientOptions: IHttpClientOptions = {};
        let requestBody: any[] = [];
        try {
            getSourceContent.forEach((element) => {
                requestBody.push({ "Text": element });
            });
            return new Promise((resolve, reject) => {
                this.translateAPIUrl = (fromLanguage == undefined || fromLanguage == "") ? "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=" + toLanguage + categoryId + "&textType=html&includeAlignment=true" : "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&from=" + fromLanguage + "&to=" + toLanguage + categoryId + "&textType=html&includeAlignment=true";
                httpClientOptions.headers = {
                    'Ocp-Apim-Subscription-Key': translateTextApiKey,
                    'Content-Type': 'application/json',
                };
                if (region != "" && region != undefined) {
                    httpClientOptions.headers['Ocp-Apim-Subscription-Region'] = region;
                }
                httpClientOptions.body = JSON.stringify(requestBody);
                this.context.httpClient.post(
                    this.translateAPIUrl,
                    HttpClient.configurations.v1,
                    httpClientOptions)
                    .then((response: HttpClientResponse) => {
                        if (response.status == 200) {
                            response.json().then((translatedText: any) => {
                                resolve(translatedText);
                            }).catch(err => {
                                AppInsightsService.trackException(this.serviceScope, err);
                                reject(err);
                            });
                        } else {
                            reject(`Error ${response.status} ${response.statusText} when fetching the language data.`);
                        }
                    }).catch(err => {
                        AppInsightsService.trackException(this.serviceScope, err);
                        reject(err);
                    });
            });
        }
        catch (error) {
            AppInsightsService.trackException(this.serviceScope, error);
            throw error;
        }
    }

    /**
   * Add langauge data in cache with respective CACHE_NAME.
   */
    public addToCache(localCache: ICache, CACHE_NAME: string, languagedata: any) {
        localCache.add(
            CACHE_NAME,
            JSON.stringify(languagedata),
            Utilities.dateAdd(new Date(), Intervals.Day, 1));
    }
}
import { IWebPartContext } from '@microsoft/sp-webpart-base';
import { ServiceScope } from '@microsoft/sp-core-library';

export interface ICollectionData {
    ProfileTipFieldKey: string;
    ProfileTipField: string;
    ProfileTipMessage: string;
    Priority: string;
    Weightage: string;
}
export interface IProfileTipCollectionData {
    ProfileTipFieldKey: string;
    ProfileTipField: string;
    ProfileTipMessage: string;
    Priority: string;
    Weightage: string;
}
export interface ICustomPropertyCollectionData {
    key: string;
    value: string;
}
export class WelcomeBarProvider {

    constructor(private context: IWebPartContext, private serviceScope: ServiceScope) {
    }

    /**
     * Calculate profile percentage based on below delve attributes.
     * @param profileTipItems: profile tip management collection data
     * @param userInfo: userProfile data
     * @param profilePic: profile picture url from graph/userprofile
     * @param defaultImageApplied: boolean value is true, if no user profile image is present. Default value is false.
     */
    public calculateUserProfile(profileTipItems: ICollectionData[], userInfo: any[], profilePic: any, defaultImageApplied: boolean) {
        let calculateWeight: number = 0;
        if (profilePic != "" && profilePic != undefined && defaultImageApplied == false && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "profile picture")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["SPS-Birthday"] != "" && userInfo[0]["SPS-Birthday"] != undefined && userInfo[0]["SPS-Birthday"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-birthday")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["CellPhone"] != "" && userInfo[0]["CellPhone"] != undefined && userInfo[0]["CellPhone"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "cellphone")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["AboutMe"] != "" && userInfo[0]["AboutMe"] != undefined && userInfo[0]["AboutMe"] != "<p>&nbsp;</p>" && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "aboutme")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["SPS-PastProjects"] != "" && userInfo[0]["SPS-PastProjects"] != undefined && userInfo[0]["SPS-PastProjects"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-pastprojects")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["SPS-Skills"] != "" && userInfo[0]["SPS-Skills"] != undefined && userInfo[0]["SPS-Skills"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-skills")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["SPS-Responsibility"] != "" && userInfo[0]["SPS-Responsibility"] != undefined && userInfo[0]["SPS-Responsibility"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-responsibility")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["SPS-School"] != "" && userInfo[0]["SPS-School"] != undefined && userInfo[0]["SPS-School"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "school")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        if (userInfo[0]["SPS-Interests"] != "" && userInfo[0]["SPS-Interests"] != undefined && userInfo[0]["SPS-Interests"].length > 0 && profileTipItems != undefined) {
            profileTipItems.filter(item => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-interests")
                    calculateWeight = calculateWeight + parseInt(item.Weightage);
            });
        }
        //Get custom name provided in User Profile Field and calculate weight if custom user profile property value is not blank
        if (userInfo[0]["custom"] != "" && userInfo[0]["custom"] != undefined && userInfo[0]["custom"].length > 0 && profileTipItems != undefined) {
            userInfo[0]["custom"].map((customKey:ICustomPropertyCollectionData) => {
                if (customKey.value != "" && customKey.value != undefined && customKey.value.length > 0 && profileTipItems != undefined) {
                    profileTipItems.filter(item => {
                        if (item.ProfileTipField.toLowerCase() == customKey.key.toLowerCase())
                            calculateWeight = calculateWeight + parseInt(item.Weightage);
                    });
                }
            });
        }
        return calculateWeight;
    }

    /**
     * set profile tip message based on user profile percentage
     * @param profileTipItems: profile tip management collection data
     * @param userProfileInfo: userProfile data
     * @param profilePic: profile picture url from graph/userprofile  
     * @param defaultImageApplied: boolean value is true, if no user profile image is present. Default value is false.
     */
    public filterProfileTipItems(profileTipItems: ICollectionData[], userProfileInfo: any[], profilePic: any, defaultImageApplied: boolean) {
        let tipMessage: string = "";
        let profileTipFound: boolean = false;
        if (profileTipItems) {
            profileTipItems.sort((a, b) => a.Priority < b.Priority ? -1 : a.Priority > b.Priority ? 1 : 0);
            profileTipItems.map((item) => {
                if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "profile picture" && profileTipFound == false) {
                    if (profilePic == "" || profilePic == undefined || defaultImageApplied == true) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-birthday" && profileTipFound == false) {
                    if (userProfileInfo[0]["SPS-Birthday"] == "" || userProfileInfo[0]["SPS-Birthday"] == undefined || userProfileInfo[0]["SPS-Birthday"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "cellphone" && profileTipFound == false) {
                    if (userProfileInfo[0]["CellPhone"] == "" || userProfileInfo[0]["CellPhone"] == undefined || userProfileInfo[0]["CellPhone"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "aboutme" && profileTipFound == false) {
                    if (userProfileInfo[0]["AboutMe"] == "" || userProfileInfo[0]["AboutMe"] == undefined || userProfileInfo[0]["AboutMe"] == "<p>&nbsp;</p>") {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-pastprojects" && profileTipFound == false) {
                    if (userProfileInfo[0]["SPS-PastProjects"] == "" || userProfileInfo[0]["SPS-PastProjects"] == undefined || userProfileInfo[0]["SPS-PastProjects"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-skills" && profileTipFound == false) {
                    if (userProfileInfo[0]["SPS-Skills"] == "" || userProfileInfo[0]["SPS-Skills"] == undefined || userProfileInfo[0]["SPS-Skills"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-responsibility" && profileTipFound == false) {
                    if (userProfileInfo[0]["SPS-Responsibility"] == "" || userProfileInfo[0]["SPS-Responsibility"] == undefined || userProfileInfo[0]["SPS-Responsibility"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-school" && profileTipFound == false) {
                    if (userProfileInfo[0]["SPS-School"] == "" || userProfileInfo[0]["SPS-School"] == undefined || userProfileInfo[0]["SPS-School"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                else if (item.ProfileTipFieldKey!=undefined && item.ProfileTipFieldKey.toLowerCase() == "sps-interests" && profileTipFound == false) {
                    if (userProfileInfo[0]["SPS-Interests"] == "" || userProfileInfo[0]["SPS-Interests"] == undefined || userProfileInfo[0]["SPS-Interests"].length == 0) {
                        tipMessage = item.ProfileTipMessage;
                        profileTipFound = true;
                    }
                }
                //Get custom name provided in User Profile Field and get tip message if custom user profile property value is blank
                else if (userProfileInfo[0]["custom"] != "" && userProfileInfo[0]["custom"] != undefined && userProfileInfo[0]["custom"].length > 0 && profileTipItems != undefined) {
                    userProfileInfo[0]["custom"].map((customKey:ICustomPropertyCollectionData)=> {
                        if (item.ProfileTipField.toLowerCase() == customKey.key.toLowerCase() && profileTipFound == false) {
                            if (customKey.value == "" || customKey.value == undefined || customKey.value.length == 0) {
                                tipMessage = item.ProfileTipMessage;
                                profileTipFound = true;
                            }
                        }
                    });
                }
            });
        }
        return tipMessage;
    }
}
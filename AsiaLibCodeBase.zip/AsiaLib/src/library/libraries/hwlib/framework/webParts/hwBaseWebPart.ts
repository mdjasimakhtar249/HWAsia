import { BaseClientSideWebPart, IWebPartPropertiesMetadata } from '@microsoft/sp-webpart-base';
import { IHandlebarsService, handlebarsServiceKey } from "../services/handleBarsService";
import { IStorageEntityBaseService } from "../services/storageEntityBaseService";
import { IHWConfiguration } from "../services/IHWConfiguration";
import { HWConfigService, HWConfigServiceKey } from "../services/configurationService";
import { BrowserUtilities } from '../../hwlibcore/sp/BrowserUtilities';
import { AppInsightsService } from '../../framework/services/AppInsightsService';
import { IReadonlyTheme, ThemeProvider, ThemeChangedEventArgs } from "@microsoft/sp-component-base";

/**
 * The base interface that all HW web part property interfaces should inherit from
 */
export interface IHWBaseProperties {
    template?: string;
    enableCodeEditor?: boolean;
}


export { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
/**
 * Base HW WebPart class, inheriting from defatult SPFx BaseClientSideWebPart
 */
export abstract class HWBaseWebPart<T extends IHWBaseProperties> extends BaseClientSideWebPart<T> {

    /** The deejs configuration */
    protected configService: IStorageEntityBaseService<IHWConfiguration>;
    protected handlebarsService: IHandlebarsService;
    protected themeProvider: ThemeProvider;
    protected themeVariant: IReadonlyTheme | undefined;

    /** 
     * Default constructor
     */
    constructor() {
        super();
        this.transformTemplate = this.transformTemplate.bind(this);
    }

    /**
     * OnInit method, that loads the required CSS files
     */
    protected onInit(): Promise<void> {
        this.context.serviceScope.whenFinished(() => {
            //this.configService = this.context.serviceScope.consume(HWConfigServiceKey);
            this.configService = new HWConfigService(this.context.serviceScope as any);

            this.handlebarsService = (this.context.serviceScope as any).consume(handlebarsServiceKey);
            // Consume the new ThemeProvider service
            this.themeProvider = this.context.serviceScope.consume(ThemeProvider.serviceKey);

            // If it exists, get the theme variant
            this.themeVariant = this.themeProvider.tryGetTheme();

            // Register a handler to be notified if the theme variant changes
            this.themeProvider.themeChangedEvent.add(this, this._handleThemeChangedEvent);
        });
        return this.configService.load().then(() => {
            // Get enableCodeEditor value from Config to enable or disable Code Editor
            if (this.configService["_settings"] != undefined && this.configService["_settings"] != null) {
                if (this.configService["_settings"].protectedSettings && this.configService["_settings"].protectedSettings != undefined && this.configService["_settings"].protectedSettings != null) {
                    this.configService["_settings"].protectedSettings!.map(v => {
                        this.properties.enableCodeEditor = v.enableCodeEditor == true ? true : false;
                    });
                }
                else {
                    this.properties.enableCodeEditor = true;
                }
                return super.onInit();
            }
        }).catch(err => {
            console.error(`Failed to load config: ${err}`);
            AppInsightsService.trackException(this.context.serviceScope as any, new Error(err));
            return super.onInit();
        });
    }

    /**
     * Below mentioned web part properties are called searchable property names or metadata which will be used by search servers for search indexing, link fix-up, etc on the data.
     * Add additional web part properties here if considered as a searchable property names.
     * For more information refer the documentation of IWebPartPropertiesMetadata interface.
     */
    protected get propertiesMetadata(): IWebPartPropertiesMetadata {
        return {
            'title': { isSearchablePlainText: true }
        };
    }

    /**
 * Update the current theme variant reference and re-render.
 *
 * @param args The new theme
 */
    private _handleThemeChangedEvent(args: ThemeChangedEventArgs): void {
        this.themeVariant = args.theme;
        this.render();
    }

    /**
     * Transforms data using HBS
     * @param templateUrl URL to HBS template
     * @param data Arbitrary data
     */
    public transformTemplate(templateUrl: string, data: any): Promise<string> {
        if (this.configService["_settings"] != undefined && this.configService["_settings"] != null) {
            return this.handlebarsService.transformTemplate(this.configService["_settings"].template + templateUrl, data);
        } else {
            return Promise.resolve("");
        }
    }
    /**
     * Returns true if hosted, such as in the mobile app etc
     */
    public isWebViewHosted(): boolean {
        return BrowserUtilities.isWebViewHosted();
    }
}
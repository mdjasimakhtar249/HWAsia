import { AppInsightsService } from '../../framework/services/AppInsightsService';
import { MSGraphClientV3 } from '@microsoft/sp-http';
import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface IMyTasksProps {  
  context: WebPartContext;
  webPartId: string;
  title: string;
  count: number;
}

export interface ITask {
  title: string;
  description: string;
  id: string;
  dueDate: Date;
  ifMatch: string;
  percentComplete: number;
}


export class TasksProvider {
  constructor(private props: IMyTasksProps) {
  }

  protected async loadData(): Promise<any> {
    return await new Promise((resolve, reject) => {
      this.props.context.serviceScope.whenFinished(() => {
        AppInsightsService.trackEvent(this.props.context.serviceScope as any, 'MyTasks', { 'action': 'loadData' });
        this.props.context.msGraphClientFactory.getClient('3').then((client: MSGraphClientV3) => {
          client.api(`me/planner/tasks?$top=${this.props.count}`).get((error, response, rawResponse) => {
            if (error != null) {
              resolve(error);
            } else {
              resolve(response);
            }
          });
        });
      });
    });
  }

  protected fetchTask(item: ITask): Promise<any> {
    const body: string =
      JSON.stringify({
        percentComplete: item.percentComplete
      });

    return new Promise((resolve, reject) => {
      this.props.context.serviceScope.whenFinished(() => {
        AppInsightsService.trackEvent(this.props.context.serviceScope as any, 'MyTasks', { 'action': 'loadData' });
        this.props.context.msGraphClientFactory.getClient('3').then((client: MSGraphClientV3) => {
          client.api(`planner/tasks/${item.id}`)
            .headers({ 'If-Match': item.ifMatch })
            .patch(body, (error, response, rawResponse) => {
              if (error != null) {
                resolve(error);
              } else {
                resolve(rawResponse);
              }
            });
        });
      });
    });
  }
}
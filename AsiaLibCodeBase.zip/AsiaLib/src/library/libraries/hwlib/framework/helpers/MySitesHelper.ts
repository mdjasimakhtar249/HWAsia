import { AppInsightsService } from '../services/AppInsightsService';
//Caching Related Imports
import { ICache } from '../../hwlibcore/cache/ICache';
import { LocalStorageCache } from '../../hwlibcore/cache/LocalStorageCache';
import { Utilities, Intervals } from '../../hwlibcore/sp/Utilities';
import { HWSPHomeHttpClient } from '../../hwlibcore/sp/data/HWSPHomeHttpClient';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient } from '@microsoft/sp-http';
//Local Cache Variable fro Frequent Sites
const CACHE_NAME_R = `AVA:HWMySitesRecent`;

export class MySitesHelper {
    public readonly columnNamesArr = { Array: [] };
    private _cache: ICache = new LocalStorageCache();
    private currentTabCount: number = 0;

    /**
     * Method to send get query for current page and store items in each tab collection.
     */
    public getSitesData(startCount: number, count: number, currentPage: number, tabName: string, context: WebPartContext): Promise<any> {
        let itemsRecentGlobal: any[] = [];
        let allItems: any[] = [];
        let recentSitesCollection: any, suggestedSitesCollection: any, followedSitesCollection: any[] = [];
        let frequentSites, recommendedSites, followingSites = "";
        return new Promise<any>((resolve, reject) => {
            try {
                if (tabName == "Frequent") {
                    frequentSites = '/_api/v2.1/insights/frequentSites?acronyms=true&top=' + count;
                    this.getRecentMySites(frequentSites, CACHE_NAME_R, count, currentPage, tabName, context).then(values => {
                        resolve(values);
                        if (values && values != [] && values.length != undefined) {
                            itemsRecentGlobal = values;
                            recentSitesCollection = itemsRecentGlobal.filter(item => {
                                if (itemsRecentGlobal.indexOf(item) < count!)
                                    return true;
                                else
                                    return false;
                            });
                        }
                        else {
                            recentSitesCollection = [];
                        }
                    }).catch(err => {
                        reject(err);
                    });
                }
                else if (tabName == "Recommended") {
                    recommendedSites = '/_api/v2.1/insights/suggestedSites?&top=' + count + '&acronyms=true&filterExternalContent=false';
                    this.getRecentMySites(recommendedSites, "", count, currentPage, tabName, context).then(values => {
                        resolve(values);
                        if (values && values != [] && values.length != undefined) {
                            let _flag = false;
                            let items = values.filter((item: any) => {
                                itemsRecentGlobal.forEach(_item => {
                                    if (_item.Url == item.Url) {
                                        _flag = true;
                                        return false;
                                    }
                                });
                                if (_flag == true) {
                                    _flag = false;
                                    return false;
                                }
                                else {
                                    return true;
                                }
                            });
                            suggestedSitesCollection = items.filter((item: any) => {
                                if (items.indexOf(item) < count!)
                                    return true;
                                else
                                    return false;
                            });
                        }
                        else {
                            suggestedSitesCollection = [];
                        }
                    }).catch(err => {
                        reject(err);
                    });
                }
                else if (tabName == "Following") {
                    followingSites = '/_api/v2.1/favorites/followedSites?&top=' + count + '&mostRecentFirst=true&acronyms=true&fillSiteData=true';
                    this.getRecentMySites(followingSites, "", count, currentPage, tabName, context).then(values => {
                        resolve(values);
                        if (values && values != [] && values.length != undefined) {
                            followedSitesCollection = values;
                        }
                        else {
                            followedSitesCollection = [];
                        }
                    }).catch(err => {
                        reject(err);
                    });
                }
                allItems.push(recentSitesCollection, suggestedSitesCollection, followedSitesCollection);
                return allItems;
            }
            catch (ex) {
                AppInsightsService.trackException(context.serviceScope as any, ex.message, "", {}, {}, 2);
                reject(ex);
            }
        });
    }

    /**
     * Get query send to fetch items for all tabs.
     */
    private getRecentMySites(query: string, cacheName: string, itemCount: number, currentPage: number, tabName: string, context: WebPartContext): Promise<any> {
        const cache = this._cache;
        return new Promise<any>((resolve, reject) => {
            try {
                if (cache.exists(cacheName) && currentPage == 0 && tabName == "Frequent") {
                    let totalItems = JSON.parse(cache.get(cacheName));
                    if (totalItems.length == itemCount && totalItems.length != undefined && totalItems != undefined)
                        resolve(JSON.parse(cache.get(cacheName)));
                    else {
                        let client = new SPHttpClient(context.serviceScope);
                        client.fetch(context.pageContext.web.absoluteUrl + query, SPHttpClient.configurations.v1, {})
                            .then(response => {
                                return response.json();
                            }).then(jsonResult => {
                                if (!jsonResult.value || jsonResult.value.length == 0) {
                                    resolve(jsonResult);
                                    return [];
                                }
                                else {
                                    jsonResult["value"].map((item: any, key: any) => {
                                        jsonResult["value"][key].Title = jsonResult["value"][key].title;
                                        jsonResult["value"][key].Url = jsonResult["value"][key].webUrl;
                                        jsonResult["value"][key].BannerImageUrl = jsonResult["value"][key].resourceVisualization.previewImageUrl === undefined ? `${jsonResult["value"][key].webUrl}/_api/siteiconmanager/getsitelogo?type='1'`
                                            : jsonResult["value"][key].resourceVisualization.previewImageUrl;
                                    });
                                    if (currentPage == 0 && tabName == "Frequent")
                                        this.addToCache(cache, cacheName, jsonResult);
                                    resolve(jsonResult["value"]);
                                }
                            })
                            .catch(err => {
                                reject(err);
                                this.callException(err, context);
                            });
                    }
                }
                else {
                    let client = new SPHttpClient(context.serviceScope);
                    client.fetch(context.pageContext.web.absoluteUrl + query, SPHttpClient.configurations.v1, {})
                        .then(response => {
                            return response.json();
                        }).then(jsonResult => {
                            if (!jsonResult.value || jsonResult.value.length == 0) {
                                resolve(jsonResult);
                                return [];
                            }
                            else {
                                jsonResult["value"].map((item: any, key: any) => {
                                    jsonResult["value"][key].Title = jsonResult["value"][key].title;
                                    jsonResult["value"][key].Url = jsonResult["value"][key].webUrl;
                                    jsonResult["value"][key].BannerImageUrl = jsonResult["value"][key].resourceVisualization.previewImageUrl === undefined ? `${jsonResult["value"][key].webUrl}/_api/siteiconmanager/getsitelogo?type='1'`
                                        : jsonResult["value"][key].resourceVisualization.previewImageUrl;
                                });
                                if (currentPage == 0 && tabName == "Frequent")
                                    this.addToCache(cache, cacheName, jsonResult);
                                resolve(jsonResult["value"]);
                            }
                        })
                        .catch(err => {
                            reject(err);
                            this.callException(err, context);
                        });
                }
            }
            catch (ex) {
                AppInsightsService.trackException(context.serviceScope as any, ex.message, "", {}, {}, 2);
                reject(ex);
            }
        });
    }

    /*
    *API call to get my sites result using microsoft service
    */
    private addToCache(cache: ICache, cacheName: string, jsonResult: any) {
        cache.add(
            cacheName,
            JSON.stringify(jsonResult["value"]),
            Utilities.dateAdd(new Date(), Intervals.Hour, 1));
    }
    private callException(err: any, context: any) {
        AppInsightsService.trackException(context.serviceScope, err.message, "", {}, {}, 2);
    }

    private getServiceScope(context: WebPartContext) {
        return new HWSPHomeHttpClient(context.serviceScope as any);
    }

    /**   
     * Set Previous and Next button enable and disable based on current tab count.    
     */
    public setPreviousNextStatus(buttonFlag: string, currentTabCount: number, isEnabledNext: boolean, isEnabledPrevious: boolean, currentPage: number, itemCount: number) {
        let result: any[] = [];
        if (currentTabCount == 0 || this.currentTabCount == undefined) {
            isEnabledNext = false;
            isEnabledPrevious = false;
        }
        else if (itemCount! <= this.currentTabCount && currentPage == 0) {
            isEnabledNext = true;
            isEnabledPrevious = false;
        }
        else if ((buttonFlag == "Next" || buttonFlag == "Previous") && itemCount == this.currentTabCount && currentPage != 0) {
            isEnabledPrevious = true;
            isEnabledNext = true;
        }
        else if (buttonFlag == "Next" && this.currentTabCount < itemCount!) {
            isEnabledNext = false;
            isEnabledPrevious = true;
        }
        result.push(currentPage, currentTabCount, isEnabledNext, isEnabledPrevious);
        return result;
    }

    /**
     *  Get current tab count based on current open tab.    
     */
    public getCurrentTabCount(currentTab: string, recentSitesCollectionLength: number, followedSitesCollectionLength: number, suggestedSitesCollectionLength: number) {
        if (currentTab == "Frequent")
            this.currentTabCount = recentSitesCollectionLength;
        else if (currentTab == "Recommended")
            this.currentTabCount = suggestedSitesCollectionLength;
        else if (currentTab == "Following")
            this.currentTabCount = followedSitesCollectionLength;
        return this.currentTabCount;
    }

    /**
     * CallBack function to get data for the current page.
     */
    public loadSites(currentPage: number, count: number, callback: any, tabName: string, context: WebPartContext, clickedButtonName: string, isEnabledNext: boolean, isEnabledPrevious: boolean): Promise<any> {
        let result: any[] = [];
        return new Promise((resolve, reject) => {
            let startCount = currentPage * count;
            this.getSitesData(startCount, count, currentPage, tabName, context).then(mySitesData => {
                if (mySitesData.length != 0 && mySitesData.length <= count) {
                    callback(mySitesData, tabName);
                    result = this.setPreviousNextStatus(clickedButtonName, mySitesData.length, isEnabledNext, isEnabledPrevious, currentPage, count);
                    resolve(result);
                }
                else {
                    currentPage = currentPage - 1;
                    result.push(currentPage, mySitesData.length, false, isEnabledPrevious);
                    resolve(result);
                }

            }).catch(error => {
                AppInsightsService.trackException(context.serviceScope as any, error);
                throw error;
            });
        }).catch(error => {
            AppInsightsService.trackException(context.serviceScope as any, error);
            throw error;
        });
    }
}
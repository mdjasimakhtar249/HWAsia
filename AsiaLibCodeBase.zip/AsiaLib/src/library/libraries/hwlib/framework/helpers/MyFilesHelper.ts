// import { MSGraphClient } from '@microsoft/sp-http';
import { MSGraphClientV3 } from '@microsoft/sp-http';
//Caching Related Imports
import { Utilities, Intervals } from '../../hwlibcore/sp/Utilities';
import { ICache } from '../../hwlibcore/cache/ICache';
import { LocalStorageCache } from '../../hwlibcore/cache/LocalStorageCache';
import { AppInsightsService } from '../services/AppInsightsService';
import { WebPartContext } from '@microsoft/sp-webpart-base';

//Local Cache Variable
const LOCAL_CACHE_FILES = 'HW_MyFiles-Pinned';

export interface IFolderItem {
  Folder: string;
  Url: string;
}

export class MyFilesHelper {

  private _cache: ICache = new LocalStorageCache();
  /**
     * Get items from OneDrive
     */
  public getMyFiles(query: string, nextItemUrlsArray: any, context: WebPartContext, itemCount: number, currentPage: number): Promise<any> {
    if (query == "" && nextItemUrlsArray.length == 0) {
      query = `me/drive/root/children?top=${itemCount.toLocaleString()}`;
    }
    return new Promise<any>((resolve, reject) => {
      this.getRecentMyFiles(query, LOCAL_CACHE_FILES, itemCount, currentPage, context).then(_recentDocs => {
        let myFolderItems: IFolderItem[] = [];
        if (nextItemUrlsArray.indexOf(query) == -1)
          nextItemUrlsArray.push(query);
        let myFolders = { items: myFolderItems, oneDriveUrl: "", nextItemLink: "", previousItemLink: "", nextItemLinksArray: nextItemUrlsArray };
        myFolders.nextItemLink = _recentDocs["@odata.nextLink"];
        myFolders.previousItemLink = nextItemUrlsArray[currentPage - 1];
        _recentDocs.value.map((r: any) => {
          if (r.folder != undefined)
            myFolders.items.push({ Folder: r.name, Url: r.webUrl });
          else
            myFolders.nextItemLink = "";
        });
        myFolders.oneDriveUrl = _recentDocs.value[0] != undefined ? _recentDocs.value[0].webUrl.substring(0, _recentDocs.value[0].webUrl.indexOf("_com") + 4) : "";
        resolve(myFolders);
      }).catch((error) => {
        AppInsightsService.trackException(context.serviceScope as any, error.message);
        reject(error);
      });
    });
  }

  /**
   * Add first page elements in cache with "HW_MyFiles-Pinned" name.
   */
  private addToCache(localCache: ICache, CACHE_NAME: string, Filesdata: any) {
    localCache.add(
      CACHE_NAME,
      JSON.stringify(Filesdata),
      Utilities.dateAdd(new Date(), Intervals.Day, 1));
  }

  /**
   * Function call to get items from cache or thorugh API call.   
   */
  private getRecentMyFiles(query: string, CACHE_NAME: any, itemCount: number, currentPage: number, context: WebPartContext): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      try {
        let totalItems: string;
        if (this._cache.exists(CACHE_NAME) && currentPage == 0) {
          totalItems = JSON.parse(this._cache.get(CACHE_NAME));
          if (totalItems.length == itemCount && totalItems.length != undefined && totalItems != undefined) {
            resolve(JSON.parse(this._cache.get(CACHE_NAME)));
          }
          else {
            const localCache = this._cache;
            this.getDataFromOfficeApp(context, query).then(Filesdata => {
              if (currentPage == 0)
                this.addToCache(localCache, CACHE_NAME, Filesdata);
              resolve(Filesdata);
            });
          }
        }
        else {
          const localCache = this._cache;
          this.getDataFromOfficeApp(context, query).then(Filesdata => {
            if (currentPage == 0)
              this.addToCache(localCache, CACHE_NAME, Filesdata);
            resolve(Filesdata);
          });
        }
      }
      catch (err) {
        AppInsightsService.trackException(context.serviceScope as any, err);
      }
    });
  }

  /**
   * REST API call to fetch user files from one drive.
   */
  protected getDataFromOfficeApp(context: WebPartContext, webUrl: string): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      context.msGraphClientFactory
        .getClient('3')
        .then((client: MSGraphClientV3): void => {
          client
            .api(webUrl)
            .get((error, response, rawResponse) => {
              if (error != null) {
                resolve(error);
              }
              else {

                resolve(response);
              }
            });
        }, err => reject(err));
    });
  }

  /**   
     * Set Previous and Next button enable and disable based on current tab count.    
     */
  public setPreviousNextStatus(buttonFlag: string, currentItemCount: number, nextLink: string, isEnabledNext: boolean, isEnabledPrevious: boolean, currentPage: number, itemCount: number) {
    let result: any[] = [];
    if (itemCount <= currentItemCount && currentPage == 0) {
      isEnabledNext = true;
      isEnabledPrevious = false;
    }
    else if ((buttonFlag == "Next" || buttonFlag == "Previous") && itemCount == currentItemCount && currentPage != 0 && nextLink != undefined) {
      isEnabledPrevious = true;
      isEnabledNext = true;
    }
    else if (buttonFlag == "Next" && (nextLink == "" || nextLink == undefined)) {
      isEnabledNext = false;
      isEnabledPrevious = true;
    }
    result.push(currentPage, isEnabledNext, isEnabledPrevious);
    return result;
  }

  /**
     * Call Helper class function to get files from One Drive     
     */
  public loadFiles(query: string, nextItemUrlsArray: any, context: WebPartContext, count: number, currentPage: number, callback: any, clickedButtonName: string, isEnabledNext: boolean, isEnabledPrevious: boolean): Promise<any> {
    let result: any[] = [];
    return new Promise((resolve, reject) => {
      this.getMyFiles(query, nextItemUrlsArray, context, count, currentPage).then(queryresult => {
        if (queryresult.items.length != 0) {
          callback(queryresult);
          result = this.setPreviousNextStatus(clickedButtonName, queryresult.items.length, queryresult.nextItemLink, isEnabledNext, isEnabledPrevious, currentPage, count);
          resolve(result);
        }
        else {
          currentPage = currentPage - 1;
          result.push(currentPage, false, isEnabledPrevious);
          resolve(result);
        }
      }).catch(error => {
        AppInsightsService.trackException(context.serviceScope as any, error);
        throw error;
      });
    }).catch(error => {
      AppInsightsService.trackException(context.serviceScope as any, error);
      throw error;
    });
  }
}
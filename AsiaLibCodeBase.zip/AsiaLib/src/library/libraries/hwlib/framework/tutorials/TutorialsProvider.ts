import { ServiceScope } from '@microsoft/sp-core-library';
import { SPHttpClient } from '@microsoft/sp-http';
import { AppInsightsService } from '../../framework/services/AppInsightsService';
import { PageContext } from '@microsoft/sp-page-context';

export interface ITutorialProperties {
    url: string;
}

export interface ITutorialsProvider {
    getTutorials(listName: string);
}
export interface ITutorial {
    TutorialControlID: string;
    TutorialDescription: string;
    TutorialElement: string;
    TutorialTourOrder: number;
    TutorialDesign: string;
}
//this provider can be used to get data from List based on Design
export class ListBasedTutorialsProvider implements ITutorialsProvider {
    //@ts-ignore
    constructor(private config: ITutorialProperties, private context: PageContext, private serviceScope: ServiceScope) {

    }

    public getTutorials(listName: string): Promise<ITutorial[]> {        
        AppInsightsService.trackEvent(this.serviceScope, "Ava:TutorialsWebpart");
        return new Promise((resolve, reject) => {
            let allTutorials: ITutorial[] = new Array();
            let client = new SPHttpClient(this.serviceScope as any);
            client.fetch(this.config.url + `/_api/web/lists/GetByTitle('${listName}')/Items?$select=TutorialControlID,TutorialDescription,TutorialElement,TutorialTourOrder,TutorialDesign&$filter=TutorialDefaultDesign eq 1&$orderby= TutorialTourOrder asc`, SPHttpClient.configurations.v1, {})
                .then(response => {
                    return response.json();
                }).then(json => {
                    allTutorials = json.value;
                    resolve(allTutorials);
                }).catch(error => {
                    AppInsightsService.trackException(this.serviceScope, error);
                    reject(error);
                });
        });
    }
}
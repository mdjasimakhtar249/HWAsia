import { ServiceScope } from '@microsoft/sp-core-library';
import { AppInsightsService } from '../../framework/services/AppInsightsService';
import { ICache } from '../../hwlibcore/cache/ICache';
import { LocalStorageCache } from '../../hwlibcore/cache/LocalStorageCache';
import { Utilities, Intervals } from '../../hwlibcore/sp/Utilities';
import { SPTaxonomyHelpers } from '../../hwlibcore/sp/SPTaxonomyHelpers';

export class TargetTaxonomy {
    private static _cache: ICache = new LocalStorageCache();

    public static TargetTermSetHierarchy(serviceScope: ServiceScope): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            const currentInstance = this;
            if (this._cache.exists('AVA.TargetTaxonomyHierarchy')) {
                resolve(<any>JSON.parse(this._cache.get('AVA.TargetTaxonomyHierarchy')));
            } else {
                const cache = currentInstance._cache;
                currentInstance.getTerms('3abb17d3-55cd-4028-812a-7a88f809c0fa').then((terms) => {
                    const termHierarchy = this.createTermHierarchy(terms);
                    const tree: any[] = new Array();
                    const treeTerms = this.getTreeTerms(termHierarchy.children, 4, tree);
                    cache.add('AVA.TargetTaxonomyHierarchy', JSON.stringify(treeTerms), Utilities.dateAdd(new Date(), Intervals.Hour, 24));
                    resolve(treeTerms);
                }, (err) => {
                    AppInsightsService.trackException(serviceScope, err);
                    reject(err);
                });
            }
        });
    }

    public static getTerms(termSetID: string): Promise<SP.Taxonomy.TermCollection> {
        return new Promise<SP.Taxonomy.TermCollection>((resolve, reject) => {
            new SPTaxonomyHelpers().load().then(() => {
                const ctx: SP.ClientContext = SP.ClientContext.get_current(),
                    taxonomySession: SP.Taxonomy.TaxonomySession = SP.Taxonomy.TaxonomySession.getTaxonomySession(ctx),
                    termStore: SP.Taxonomy.TermStore = taxonomySession.getDefaultSiteCollectionTermStore(),
                    termSet: SP.Taxonomy.TermSet = termStore.getTermSet(new SP.Guid(termSetID)),
                    terms: SP.Taxonomy.TermCollection = termSet.getAllTerms();

                ctx.load(terms, 'Include(IsRoot, Labels, Id, IsAvailableForTagging, IsDeprecated, Name, PathOfTerm, Parent, Parent.Id, TermSet.Name)');
                ctx.executeQueryAsync((s: any, e: any) => {
                    resolve(terms);
                }, (s: any, e: any) => {
                    console.log('Request failed. ' + e.get_message() + '\n' + e.get_stackTrace());
                    reject('Request failed. ' + e.get_message() + '\n' + e.get_stackTrace());
                });
            });
        });
    }

    public static createTermHierarchy(terms: SP.Taxonomy.TermCollection) {
        const termEnumerator = terms.getEnumerator(),
            tree = {
                term: terms,
                children: []
            };
        while (termEnumerator.moveNext()) {
            const currentTerm = termEnumerator.get_current();
            const currentTermPath = currentTerm.get_pathOfTerm().split(';');
            var children: any = tree.children;
            // Loop through each part of the path
            for (var i = 0; i < currentTermPath.length; i++) {
                var foundNode = false;
                for (var j = 0; j < children.length; j++) {
                    if (children[j].name === currentTermPath[i]) {
                        foundNode = true;
                        break;
                    }
                }
                // Select the node, otherwise create a new one
                const term = foundNode ? children[j] : { name: currentTermPath[i], children: [] };
                // If we're a child element, add the term properties
                if (i === currentTermPath.length - 1) {
                    term.term = currentTerm;
                    term.title = currentTerm.get_name();
                    term.IsAvailableForTagging = currentTerm.get_isAvailableForTagging();
                    term.guid = currentTerm.get_id().toString();
                }
                // If the node did exist, let's look there next iteration
                if (foundNode) {
                    children = term.children;
                } else { // If the segment of path does not exist, create it
                    children.push(term);

                    // Reset the children pointer to add there next iteration
                    if (i !== currentTermPath.length - 1) {
                        children = term.children;
                    }
                }
            }
        }
        return tree;
    }

    public static getTreeTerms(arrOrgterms: any, level: any, tree: any) {
        for (var i = 0; i < arrOrgterms.length; i++) {
            const orgTerm = {
                name: arrOrgterms[i].title ? arrOrgterms[i].title : arrOrgterms[i].name,
                IsAvailableForTagging: arrOrgterms[i].IsAvailableForTagging,
                level: arrOrgterms[i].term ? arrOrgterms[i].term.get_pathOfTerm().split(';').length : -1,
                children: []
            };
            tree.push(orgTerm);
            if (arrOrgterms[i].children.length > 0) {
                if (arrOrgterms[i].term && arrOrgterms[i].term.get_pathOfTerm().split(';').length < level) {
                    this.getTreeTerms(arrOrgterms[i].children, level, tree[i].children);
                }
            }
        }
        return tree;
    }
}
export class FieldUrlValue {
    public Description: string;
    public Url: string;
}
export enum AppSource {
    global,
    personal
}

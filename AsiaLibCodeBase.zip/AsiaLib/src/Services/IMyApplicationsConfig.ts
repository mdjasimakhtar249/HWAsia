export default interface IMyApplicationsConfig {
    url: string;
    templateUrl: string;
    defaultOnlyShowMandatoryApps: boolean;
}
import { FieldUrlValue } from "./MyApplicationsDefinitions";
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { UserProfileService } from "../library";
import { sp } from "@pnp/sp/presets/all";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { Web } from "@pnp/sp/webs";

//Interface for companyLinks
export interface AllAppsLinks {
  ID: string;
  title: String;
  url: FieldUrlValue;
  mandatory: Boolean;
  priority: Number;
  category: String;
  image: string;
  description: String;
  addtoMyLinks: boolean;
  sequence: number;
}

export interface AllApps {
  allAppsArray: AllAppsLinks[];
  userProfileLink: String;
}

export class MyApplications {
  constructor(
    private webpartContext: WebPartContext,
    private companyLinksListUrl,
    private companyListTitle,
    private userProfilePropertyName
  ) {
    this.context = webpartContext;
    this.companyLinksListUrl = companyLinksListUrl;
    this.companyListTitle = companyListTitle;
    this.userProfileProperty = userProfilePropertyName;
  }

  private context: WebPartContext;
  private userProfileProperty: string;
  private allAppsArray: AllAppsLinks[];
  private companyLinks: AllAppsLinks[];
  private myLinks: AllAppsLinks[] = [];
  private getMyLinksFromUserProfile: any = "";
  private allmyLinks: any[] = [];
  private customItem: AllAppsLinks;
  private defaultImageIcon: string;
  private image: any;
  private web = Web(this.companyLinksListUrl);

  /**
   * Method to set defaultImageLink
   */
  public async setDefaultImageLink(link: string) {
    this.defaultImageIcon = link;
  }

  /**
   * Public Method to return apps from all apps sharepoint list provided in ASIA Config
   */
  public async companylinks(): Promise<AllAppsLinks[]> {
    const loggedInUser = this.context.pageContext.user.email;
    let listItems;
    sp.setup({
      spfxContext: this.context as any,
    });
    /* const getUserExists = await this.web.lists
      .getByTitle(this.userProfileProperty)
      .items.expand("User")
      .select("User/EMail", "Title", "ID")
      .filter(`User/EMail eq '${loggedInUser}'`)
      .orderBy("Created", false)
      .top(1) // append descending
      .get()
      .then((data) => {
        return data.length;
      })
      .catch((error) => {
        JSON.stringify(error);
      });
    console.log(getUserExists);*/
    // if (getUserExists !== 0) {
    const listAllItems = await this.web.lists
      .getByTitle(this.companyListTitle)
      .items.getAll();

    listItems = listAllItems.filter((item) => {
      return item.FileSystemObjectType == 0;
    });
    //}
    /*else {
      const listAllItems = await this.web.lists
        .getByTitle(this.companyListTitle)
        .items.orderBy("Created", false)
        .top(5)
        .get();
      listItems = listAllItems.filter((item) => {
        return item.FileSystemObjectType == 0;
      });
    }*/
    try {
      this.allAppsArray = (<any[]>listItems).map((value) => {
        if (value["AvaAppImage"] == null) {
          this.image = this.defaultImageIcon;
        } else {
          this.image =
            JSON.parse(value["AvaAppImage"]).serverUrl +
            JSON.parse(value["AvaAppImage"]).serverRelativeUrl;
        }
        return {
          ID: value["Id"],
          title: value["Title"],
          url: value["AvaAppUrl"]
            ? value["AvaAppUrl"]
            : { Url: "", Description: "" },
          mandatory: value["AvaAppMandatory"],
          priority: value["AvaAppPriority"],
          category: value["AvaAppCategory"],
          image: this.image,
          description: value["AvaAppDescription"],
          addtoMyLinks: false,
          sequence: null,
        };
      });
    } catch (error) {
      throw error;
    }
    return this.allAppsArray;
  }

  /**
   * Private Method to return apps from user profile
   * propertity referring - AvaPersonalQuickLinks
   */
  public async checkUserExists() {
    const loggedInUser = this.context.pageContext.user.email;
    const getUserExists = await this.web.lists
      .getByTitle(this.userProfileProperty)
      .items.expand("User")
      .select("User/EMail", "Title", "ID")
      .filter(`User/EMail eq '${loggedInUser}'`)
      .get()
      .then((data) => {
        return data.length;
      });
    return getUserExists;
  }
  public async getTopUSerLinks(): Promise<any> {
    let format = [];
    const listAllItems = await this.web.lists
      .getByTitle(this.companyListTitle)
      .items.orderBy("Created", false)
      .top(5)
      .get();
    listAllItems?.map((data) => {
      if (data.ID) format.push(data.ID);
    });
    return format.join("||");
  }
  private async getUserProfilePropertyString(): Promise<any> {
    const loggedInUser = this.context.pageContext.user.email;
    let reqPropertyValue: any = "";
    let finalValue: any = "";
    let finalList = [];
    sp.setup({
      spfxContext: this.context as any,
    });

    const ifUserExists = await this.checkUserExists();
    if (ifUserExists === 0) {
      finalValue = await this.getTopUSerLinks();
    } else {
      const listAllItems = await this.web.lists
        .getByTitle(this.userProfileProperty)
        .items.expand("User")
        .select("User/EMail", "Title", "ID", "MyApps")
        .filter(`User/EMail eq '${loggedInUser}'`)
        .orderBy("Created", false) // append descending
        .get()
        .then((data) => {
          console.log(data[0].MyApps);
          //finalValue = data[0].Title;
          const Ary = JSON.parse(data[0].MyApps);
          Ary.map((item) => {
            finalList.push(item.ID);
          });
          finalValue = finalList.join("||");
        })
        .catch((error) => {
          JSON.stringify(error);
        });
    }

    /*const listItems = listAllItems.filter((item) => {
      return item.FileSystemObjectType == 0;
    });*/
    //console.log(listAllItems);
    return finalValue;
  }

  /**
   * Public Method to update apps in user profile property
   * propertity referring - AvaPersonalQuickLinks
   */
  public async updateUserProfileProperty(
    companyFavouriteLinks: AllAppsLinks[]
  ) {
    const loggedInUser = this.context.pageContext.user.email;
    let idList: any[] = [];
    let MyAppsList: any[] = [];
    companyFavouriteLinks.map((item) => {
      if (item.ID != null) {
        idList.push(item.ID);
        MyAppsList.push({
          ID: item.ID,
          Title: item.title,
          Url: item.url.Url,
        });
      } else {
        idList.push(item.title + "|" + item.url.Url);
        MyAppsList.push({
          ID: item.ID,
          Title: item.title,
          Url: item.url.Url,
        });
      }
    });
    let favLinksToBeUpdated = idList.join("||");
    //////List Change Recently
    const IDList = await sp.web.lists
      .getByTitle(this.userProfilePropertyName)
      .items.expand("User")
      .select("User/EMail", "ID", "Title")
      .filter(`User/EMail eq '${loggedInUser}'`)
      .get()
      .then((data) => {
        return data;
      });
    const ID = IDList.length > 0 ? IDList[0].ID : null;
    console.log(idList);
    if (ID !== null) {
      await sp.web.lists
        .getByTitle(this.userProfilePropertyName)
        .items.getById(ID)
        .update({
          Title: idList.join("||"),
          MyApps: JSON.stringify(MyAppsList),
        })
        .then((data) => {
          console.log(data);
        })
        .catch((error) => {
          JSON.stringify(error);
        });
    } else {
      const user = await sp.web.currentUser.get();

      await sp.web.lists
        .getByTitle(this.userProfilePropertyName)
        .items.add({
          Title: idList.join("||"),
          UserId: user.Id,
          MyApps: JSON.stringify(MyAppsList),
        }) //`{"value": "${}"}` })
        .then((data) => {
          console.log(data);
        })
        .catch((error) => {
          JSON.stringify(error);
        });
    }
  }

  /**
   * Public Method to return apps from user profile
   * propertity referring - AvaPersonalQuickLinks
   */
  public async getUserProfilePropertyValue(): Promise<String> {
    let generateAppsVar = await this.getUserProfilePropertyString();
    return generateAppsVar;
  }

  /**
   * Public Method to return company links which matches to the user profile property links for heart fill feature
   * propertity referring - AvaPersonalQuickLinks
   */
  public async comapnyLinksForHeartFill(
    companyLinks: AllAppsLinks[]
  ): Promise<AllAppsLinks[]> {
    this.companyLinks = companyLinks;
    const ifUserexists = await this.checkUserExists();
    if (ifUserexists === 0) {
      this.getMyLinksFromUserProfile = await this.getTopUSerLinks();
    } else {
      this.getMyLinksFromUserProfile =
        await this.getUserProfilePropertyString();
    }
    this.allmyLinks = this.getMyLinksFromUserProfile.split("||");
    this.companyLinks.map((items) => {
      this.allmyLinks.map((item) => {
        if (item == items.ID) {
          items.addtoMyLinks = true;
        }
      });
    });
    return this.companyLinks;
  }

  /**
   * Public Method to return apps from user profile property with split operations for retaining index values after drag and drop and crud operations
   * propertity referring - AvaPersonalQuickLinks
   */
  public async getMyLinks(
    companyLinks: AllAppsLinks[]
  ): Promise<AllAppsLinks[]> {
    this.companyLinks = companyLinks;
    this.getMyLinksFromUserProfile = await this.getUserProfilePropertyString();
    this.allmyLinks = this.getMyLinksFromUserProfile.split("||");
    let tempList = [];
    this.myLinks = [];
    if (
      this.companyLinks == null ||
      this.companyLinks == undefined ||
      this.companyLinks.length == 0
    ) {
      this.allmyLinks.map((customLink) => {
        if (customLink.includes("|") && tempList.indexOf(customLink) === -1) {
          tempList.push(customLink);
        }
      });
    } else {
      this.allmyLinks.map((customLink) => {
        this.companyLinks.map((companyLink) => {
          if (customLink == companyLink.ID) {
            companyLink.addtoMyLinks = true;
            tempList.push(companyLink);
          } else if (
            customLink.includes("|") &&
            tempList.indexOf(customLink) === -1
          ) {
            tempList.push(customLink);
          }
        });
      });
    }

    tempList.map((item) => {
      if (typeof item == "string") {
        this.customItem = {
          ID: null,
          title: item.split("|")[0],
          url: { Description: null, Url: item.split("|")[1] },
          image: this.defaultImageIcon,
          sequence: null,
          mandatory: null,
          priority: null,
          category: null,
          description: null,
          addtoMyLinks: true,
        };
        this.myLinks.push(this.customItem);
      } else this.myLinks.push(item);
    });
    return this.myLinks;
  }
}

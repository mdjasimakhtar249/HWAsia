define([], function () {
    return {
        
        "MyLinks": "I miei link",
        "CompanyLinks": "Galleria link",
        "AddFromGallery": "+ dalla galleria",
        "AddCustomLink": "Nuovo link",
        "DragTheLinksToReorder" : "Trascina i link per riordinarli",
        "CustomLinkTitle": "Titolo Link",
        "CustomLinkUrl": "URL Link",
        "AddCustomLinkbutton": "Aggiungi Link",
        "RemoveLink" : "Rimuovi Link?",
        "Areyousureyouwanttoremovethislink" : "Sei sicuro di voler rimuovere questo link?",
        "RemoveLinkButton" : "Rimuovi",
        "CancelLinkButton" : "Annulla",
        "SearchLink" : "Cerca un link",      
        "MaxLimitMessage" : "Hai raggiunto il massimo numero di link.",
        "CustomLinkLimitMessage" : "Non è possibile aggiungere più di 10 link.",
        "ManageLinks" : "Gestisci link",
        "ViewLinks" : "Vedi link",
        "InvalidLinkMessage" : "Titolo link non valido",
        "DuplicateLinkMessage": "Esiste già un link con questo titolo",
        "InvalidURL": "URL non valido",
        "AllLinksCategory": "Tutti i link",

        //ACE Card strings
        
        "ACECardPrimaryText" : "Clicca qui per accedere ai tuoi link",
        "ACECardButtonText" : "links",
    }
});

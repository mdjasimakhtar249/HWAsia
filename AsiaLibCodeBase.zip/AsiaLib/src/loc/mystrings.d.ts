declare interface ImyAppsV2WebpartStrings {
   
    MyLinks: string;
    CompanyLinks: string;
    AddFromGallery: string;
    AddCustomLink: string;
    DragTheLinksToReorder: string;
    CustomLinkTitle: string;
    CustomLinkUrl: string;
    AddCustomLinkbutton: string;
    RemoveLink : string;
    Areyousureyouwanttoremovethislink : string;
    RemoveLinkButton : string;
    CancelLinkButton : string;
    SearchLink : string;
    MaxLimitMessage : string;
    CustomLinkLimitMessage : string;
    ManageLinks : string;
    ViewLinks : string;
    InvalidLinkMessage : string;
    DuplicateLinkMessage: string;
    InvalidURL: string;
    AllLinksCategory: string;

    //ACE Card strings

    ACECardPrimaryText : string;
    ACECardButtonText : string;
}

declare module 'myAppsV2WebpartStrings' {
    const strings: ImyAppsV2WebpartStrings;
    export = strings;
}

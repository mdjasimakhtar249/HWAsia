declare interface IMyAppsAdaptiveCardExtensionStrings {
  PropertyPaneDescription: string;
  TitleFieldLabel: string;
  Title: string;
  SubTitle: string;
  PrimaryText: string;
  Description: string;
  QuickViewButton: string;
  ButtonStyle: string;
  ButtonText: string;
  PrimaryTextLabel: string;
}

declare module 'MyAppsAdaptiveCardExtensionStrings' {
  const strings: IMyAppsAdaptiveCardExtensionStrings;
  export = strings;
}

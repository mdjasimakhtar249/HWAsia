define([], function () {
  return {
    "PropertyPaneDescription": "",
    "TitleFieldLabel": "Card title",
    "Title": "Adaptive Card Extension",
    "SubTitle": "Quick view",
    "PrimaryText": "SPFx Adaptive Card Extension",
    "Description": "Your very own quicklinks list!",
    "QuickViewButton": "Quick view",
    "ButtonStyle": "Button Style",
    "ButtonText": "Button Text",
    "PrimaryTextLabel": "Primary Text"
  }
});
import {
  IPrimaryTextCardParameters,
  IExternalLinkCardAction,
  IQuickViewCardAction,
  ICardButton,
  BaseBasicCardView,
  IBasicCardParameters,
} from "@microsoft/sp-adaptive-card-extension-base";
import type { ActionStyle } from "adaptivecards/lib/schema";
import * as strings from "myAppsV2WebpartStrings";
import {
  IMyAppsAdaptiveCardExtensionProps,
  IMyAppsAdaptiveCardExtensionState,
  QUICK_VIEW_REGISTRY_ID,
} from "../MyAppsAdaptiveCardExtension";

export class CardView extends BaseBasicCardView<
  IMyAppsAdaptiveCardExtensionProps,
  IMyAppsAdaptiveCardExtensionState
> {
  public get cardButtons():
    | [ICardButton]
    | [ICardButton, ICardButton]
    | undefined {
    if (this.state.loaded) {
      const buttonStyle =
        this.properties.buttonStyle === "Primary" ? "positive" : "default";
      let buttonText;
      if (
        this.properties.buttonText !== undefined &&
        this.properties.buttonText.replace(/\s/g, "") !== ""
      )
        buttonText = this.properties.buttonText.replace(
          "{count}",
          this.state.userLinks.length.toString()
        );
      else
        buttonText =
          this.state.userLinks.length + " " + strings.ACECardButtonText;
      return [
        {
          title: buttonText,
          style: buttonStyle as ActionStyle,
          action: {
            type: "QuickView",
            parameters: {
              view: QUICK_VIEW_REGISTRY_ID,
            },
          },
        },
      ];
    }
  }

  public get data(): IBasicCardParameters {
    let primaryText;
    if (
      this.properties.primaryText !== undefined &&
      this.properties.primaryText.replace(/\s/g, "") !== ""
    )
      primaryText = this.properties.primaryText.replace(
        "{count}",
        this.state.userLinks.length.toString()
      );
    else primaryText = strings.ACECardPrimaryText;
    return {
      primaryText: this.state.loaded ? primaryText : "",
      title: this.properties.title,
    };
  }

  public get onCardSelection():
    | IQuickViewCardAction
    | IExternalLinkCardAction
    | undefined {
    return {
      type: "QuickView",
      parameters: {
        view: QUICK_VIEW_REGISTRY_ID,
      },
    };
  }
}

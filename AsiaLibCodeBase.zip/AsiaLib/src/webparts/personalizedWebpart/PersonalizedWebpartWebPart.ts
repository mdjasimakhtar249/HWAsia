import * as React from "react";
import { Version } from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  IPropertyPaneDropdownOption,
  PropertyPaneChoiceGroup,
  PropertyPaneDropdown,
  PropertyPaneTextField,
} from "@microsoft/sp-property-pane";
import * as strings from "PersonalizedWebpartWebPartStrings";
import {
  IApplicationsProps,
  PersonalizedWebpart,
} from "./components/PersonalizedWebpart";

import {
  IHWBaseProperties,
  HWBaseWebPart,
  HWStyles,
  UserProfileService,
} from "../../library";
import { ReactElement } from "react";
import * as ListService from "../../library";
import { SPHttpClient } from "@microsoft/sp-http";
import { WebPartTitle } from "@pnp/spfx-controls-react/lib/WebPartTitle";
import * as ReactDOM from "react-dom";
// import * as SharedStrings from 'SharedStrings';
import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IReadonlyTheme } from "@microsoft/sp-component-base";
import {
  PropertyFieldCodeEditor,
  PropertyFieldCodeEditorLanguages,
} from "@pnp/spfx-property-controls/lib/PropertyFieldCodeEditor";
import { MyApplications } from "../../Services/MyApplications";
export interface IPersonalizedWebPartProps extends IHWBaseProperties {
  context: WebPartContext;
  webpartContext: WebPartContext;
  designChoice: string;
  handlebarTemplate: string;
  handlebarTemplateData: string;
  handlebarCustomTemplate?: string;
  title: string;
  collectionData: IHandlebarProperties[];
}

export interface IHandlebarProperties {
  Name: string;
  Value: string;
}

class PersonalizedWebPart extends HWBaseWebPart<IPersonalizedWebPartProps> {
  private _isDarkTheme: boolean = false;
  private _templateOptions: IPropertyPaneDropdownOption[];
  private TemplateFolderName = "MyAppsV2";
  private _serverRelativeUrl: string = "";
  private templateUrl: string = "";
  private templatesPath: any;
  private maxSelectedCompanyLinks: any;
  private companyLinksListUrl: string;
  private companyListTitle: string;
  private defaultImageLink: string;
  private isMyAppsExists: any;
  private userProfilePropertyName: string;
  private userProfilePropertyStatus: boolean = true;
  private client: SPHttpClient;
  private dynamichtmlvar: any;
  public transformTemplate: any;
  protected appElement: ReactElement<IApplicationsProps>;
  protected errorStatus: boolean = false;
  private linkColor: string;
  private linkHoverColor: string;

  protected async onInit(): Promise<void> {
    await super.onInit();
    this.client = new SPHttpClient(this.context.serviceScope as any);
    this._serverRelativeUrl = this.context.pageContext.site.serverRelativeUrl;
    await this.loadTemplatesPathandConfiguraion();
    await this.userProfilePropertyCheck();
    return;
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }
    this._isDarkTheme = !!currentTheme.isInverted;
    const { semanticColors } = currentTheme;
    this.linkColor = semanticColors.link;
    this.linkHoverColor = semanticColors.linkHovered;
    this.domElement.style.setProperty("--bodyText", semanticColors.bodyText);
    this.domElement.style.setProperty("--link", semanticColors.link);
    this.domElement.style.setProperty(
      "--linkHovered",
      semanticColors.linkHovered
    );
  }

  public async userProfilePropertyCheck(): Promise<boolean> {
    ///List Based Code
    /* let profileProperties: any;
    return new Promise<void>((resolve, reject) => {
      UserProfileService.MyProfile(this.context.serviceScope, this.context)
        .then((myProfile) => {
          const properties = myProfile.UserProfileProperties.filter(
            (property) => {
              return this.userProfilePropertyName === property.Key;
            }
          );
          if (properties.length === 0) this.userProfilePropertyStatus = false;
          resolve();
        })
        .catch((err) => {
          reject(err);
        });
    });*/
    let dataService = new ListService.ListsService(
      this.context,
      this.context.serviceScope
    );
    let check = await dataService.checkIfListExist(
      this.userProfilePropertyName
    );
    return check ? true : false;
  }

  protected async onPropertyPaneConfigurationStart(): Promise<void> {
    this.context.statusRenderer.displayLoadingIndicator(
      this.domElement,
      strings.LoadingMessage
    );
    let dataService = new ListService.ListsService(
      this.context,
      this.context.serviceScope
    );

    //Get all templates to populate dropdown
    dataService
      .getFilesFromFolder(
        this.templatesPath.configSite,
        this.templatesPath.templatesFolderPath,
        strings.TemplateFieldLabel
      )
      .then((templates: IPropertyPaneDropdownOption[]) => {
        this._templateOptions = templates;
        this._templateOptions[0].text = strings.SelectTemplateLabel;
        this.context.propertyPane.refresh();
        this.context.statusRenderer.clearLoadingIndicator(this.domElement);
        this.render();
      });
  }

  private renderWebPartTitle() {
    let webpartTitleElement = React.createElement(WebPartTitle, {
      className: HWStyles.default.hwInheritSection,
      title: this.properties.title,
      displayMode: this.displayMode,
      updateProperty: (value: string) => {
        this.properties.title = value;
      },
    });
    ReactDOM.render(
      webpartTitleElement,
      this.context.domElement.querySelector(
        `#_${this.context.instanceId}_WebpartTitle`
      )
    );
  }

  public async render(): Promise<void> {
    this.domElement.innerHTML = `<div>
              <div id="_${this.context.instanceId}_WebpartTitle"></div>
              <div id="_${this.context.instanceId}"></div>
        </div>`;
    this.renderWebPartTitle();
    this.callElements();
  }

  private async loadTemplatesPathandConfiguraion() {
    this.configService.load().then(() => {
      const isMyAppsExists = this.configService.settings().services.myapps;
      if (isMyAppsExists != null && isMyAppsExists != undefined) {
        const userProfilePropertyName =
          this.configService.settings().services.myapps.userProfilePropertyName;
        const defaultImageLink =
          this.configService.settings().services.myapps.defaultImageLink;
        const templateUrl = this.configService
          .settings()
          .template.toLowerCase();
        const templatesPath = this.handlebarsService.getTemplatesPath(
          templateUrl,
          "/" + this.TemplateFolderName
        );
        const companyLinksListUrl =
          this.configService.settings().services.myapps.companyLinksSiteUrl;
        const companyListTitle =
          this.configService.settings().services.myapps.listTitle;

        this.userProfilePropertyName =
          userProfilePropertyName === undefined ? "" : userProfilePropertyName;
        this.defaultImageLink =
          defaultImageLink === undefined ? "" : defaultImageLink;
        this.templateUrl = templateUrl === undefined ? "" : templateUrl;
        this.templatesPath = templatesPath === undefined ? "" : templatesPath;
        this.companyLinksListUrl =
          companyLinksListUrl === undefined ? "" : companyLinksListUrl;
        this.companyListTitle =
          companyListTitle === undefined ? "" : companyListTitle;
        if (
          userProfilePropertyName === undefined ||
          defaultImageLink === undefined ||
          companyLinksListUrl === undefined ||
          companyListTitle === undefined ||
          userProfilePropertyName === null ||
          defaultImageLink === null ||
          companyLinksListUrl === null ||
          companyListTitle === null
        )
          this.errorStatus = true;
        if (this.configService.settings().services.myapps === undefined) {
          this.maxSelectedCompanyLinks = 50;
        } else {
          this.maxSelectedCompanyLinks =
            this.configService.settings().services.myapps.maxSelectedCompanyLinks;
        }
      } else {
        this.isMyAppsExists = "";
        this.userProfilePropertyName = "";
        this.defaultImageLink = "";
        this.templateUrl = "";
        this.templatesPath = "";
        this.companyLinksListUrl = "";
        this.companyListTitle = "";
        this.errorStatus = true;
      }
      return;
    });
  }

  private callElements(): void {
    this.appElement = React.createElement<IApplicationsProps>(
      PersonalizedWebpart,
      {
        title: this.properties.title,
        count: this.maxSelectedCompanyLinks,
        companyLinksListUrl: this.companyLinksListUrl,
        userProfilePropertyName: this.userProfilePropertyName,
        companyListTitle: this.companyListTitle,
        defaultImageLink: this.defaultImageLink,
        designChoice: this.properties.designChoice,
        handlebarTemplate: this.properties.handlebarTemplate,
        handlebarCustomTemplate: this.properties.handlebarCustomTemplate,
        enableCodeEditor: this.properties.enableCodeEditor,
        dynamichtml: this.dynamichtmlvar,
        transformTemplate: this.transformTemplate,
        templateFolderName: this.TemplateFolderName,
        context: this.context,
        callback: this.callBackFromApplicationsElement,
        errorStatus: this.errorStatus,
        userProfilePropertyStatus: this.userProfilePropertyStatus,
        linkColor: this.linkColor,
        linkHoverColor: this.linkHoverColor,
        language: this.context.pageContext.cultureInfo.currentUICultureName,
      }
    );
    ReactDOM.render(
      this.appElement,
      this.context.domElement.querySelector(`#_${this.context.instanceId}`)
    );
  }

  private callBackFromApplicationsElement = () => {};

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    let template: any = [];
    let htmlCode: any = [];

    if (this.properties.designChoice === "templatekey") {
      template = PropertyPaneDropdown("handlebarTemplate", {
        label: strings.SelectTemplateLabel,
        options: this._templateOptions,
        selectedKey: strings.SelectTemplateKey,
      });
    }

    if (
      this.properties.designChoice === "handlebar" &&
      this.properties.enableCodeEditor
    ) {
      htmlCode = PropertyFieldCodeEditor("handlebarCustomTemplate", {
        label: "Custom HTML",
        panelTitle: "Custom HTML",
        initialValue: this.properties.handlebarCustomTemplate,
        onPropertyChange: this.onPropertyPaneFieldChanged,
        properties: this.properties,
        disabled: false,
        key: "codeEditorFieldId",
        language: PropertyFieldCodeEditorLanguages.HTML,
        options: {
          wrap: true,
          fontSize: 14,
        },
      });
    }

    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.Settings,
              groupFields: [
                PropertyPaneTextField("title", {
                  label: strings.TitleFieldLabel,
                  value: this.properties.title,
                }),
              ],
            },
            {
              groupName: "Design",
              groupFields: [
                PropertyPaneChoiceGroup("designChoice", {
                  label: "Select layout",
                  options: [
                    {
                      key: "templatekey",
                      text: "Select",
                      disabled:
                        this._templateOptions &&
                        this._templateOptions.length <= 1,
                      iconProps: {
                        officeFabricIconFontName: "Dropdown",
                      },
                    },
                    {
                      key: "handlebar",
                      text: "Custom",
                      iconProps: {
                        officeFabricIconFontName: "Design",
                      },
                      disabled: !this.properties.enableCodeEditor,
                    },
                  ],
                }),
                template,
                htmlCode,
              ],
            },
          ],
        },
      ],
    };
  }
}
export default PersonalizedWebPart;

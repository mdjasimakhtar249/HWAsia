declare interface IPersonalizedWebpartWebPartStrings {
  SelectTemplate: string;
  SelectTemplateLabel: string;
  SelectTemplateKey: string;
  PropertyPaneDescription: string;
  Settings: string;
  DescriptionFieldLabel: string;
  TemplateFieldLabel: string;
  GenericHTML: string;
  Description: string;
  Configure: string;
  LoadingMessage: string;
  TitleFieldLabel: string;
  SizeFieldlabel: string;
  SmallSizeLabel: string;
  MediumSizeLabel: string;
  LargeSizeLabel: string;
  MaxCompanyLinks: string;
  Layout: string;
  HandleBarLabel: string;
  HandleBarButtonLabelandHeader: string;
  FieldName: string;
  ComboBoxValidationLabel: string;
  FieldValue: string;
}

declare module "PersonalizedWebpartWebPartStrings" {
  const strings: IPersonalizedWebpartWebPartStrings;
  export = strings;
}
